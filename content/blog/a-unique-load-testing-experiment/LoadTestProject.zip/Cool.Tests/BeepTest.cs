﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Cool.Tests
{
  [TestClass]
  public class Load
  {
    [TestMethod]
    public void BeepTest()
    {
      int frequency = new Random().Next(1000, 5000);
      Console.Beep(frequency, 50);
    }
  }
}
