c:
cd\program files\microsoft team foundation server 2010 power tools

tfpt query "firstteamproject\public\all tasks" /server:http://vstfs:8080/tfs/DevConnections
pause

tfpt query /format:"id" "firstteamproject\public\all tasks" /server:http://vstfs:8080/tfs/DevConnections
pause

tfpt query /format:"id" "firstteamproject\public\all tasks" /server:http://vstfs:8080/tfs/DevConnections | tfpt workitem /update /server:http://vstfs:8080/tfs/DevConnections @ /fields:"Priority=1"
pause

tfpt query "firstteamproject\public\all tasks" /server:http://vstfs:8080/tfs/DevConnections > c:\demo\demo2\results.txt
notepad c:\demo\demo2\results.txt
