c:
cd\program files\microsoft team foundation server 2010 power tools

tfpt query "FirstTeamProject\public\all tasks" /server:http://vstfs:8080/tfs/DevConnections
pause

tfpt query "FirstTeamProject\public\all tasks" /server:http://vstfs:8080/tfs/DevConnections > c:\demo\demo2\tasks.txt
notepad c:\demo\demo2\tasks.txt
