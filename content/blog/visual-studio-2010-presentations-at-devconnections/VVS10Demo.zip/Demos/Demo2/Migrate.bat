"C:\Program Files\Microsoft Visual Studio 10.0\Common7\IDE\VSSConverter.exe" Migrate C:\Demo\Demo2\MigrationSettings.xml
pause