c:
cd\program files\microsoft visual studio 10.0\common7\ide

witadmin /?
pause
