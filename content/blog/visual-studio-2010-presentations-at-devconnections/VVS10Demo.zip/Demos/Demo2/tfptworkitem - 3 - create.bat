c:
cd\program files\microsoft team foundation server 2010 power tools

tfpt workitem /new FirstTeamProject\Bug /server:http://vstfs:8080/tfs/DevConnections /fields:"Title=Blue Screen;Assigned To=Dave"
pause

tfpt query "firstteamproject\public\all bugs" /server:http://vstfs:8080/tfs/DevConnections
pause