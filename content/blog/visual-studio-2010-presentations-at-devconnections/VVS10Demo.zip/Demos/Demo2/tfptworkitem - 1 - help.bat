c:
cd\program files\microsoft team foundation server 2010 power tools

tfpt /?
pause

tfpt query /?
pause

tfpt workitem /?
pause

tfpt createteamproject /?
pause