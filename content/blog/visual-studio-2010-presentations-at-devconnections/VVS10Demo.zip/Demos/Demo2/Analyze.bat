"C:\Program Files\Microsoft Visual Studio 10.0\Common7\IDE\VSSConverter.exe" Analyze C:\Demo\Demo2\AnalysisSettings.xml
pause