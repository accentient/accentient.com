@ECHO OFF
REM Batch file to create SCC folder structure for a given Team Project

SET TeamProject=Target
SET TFS=vstfs
SET TPC=DevConnections
SET Comment=Created by a cool automated script

ECHO Create folder Structure
ECHO.

C:
CD\
RD /s /q "C:\Workspaces"
MD "C:\Workspaces"
MD "C:\Workspaces\%TeamProject%"
MD "C:\Workspaces\%TeamProject%\Code"
MD "C:\Workspaces\%TeamProject%\Code\Dev"
MD "C:\Workspaces\%TeamProject%\Code\Prod"
MD "C:\Workspaces\%TeamProject%\Documents"
MD "C:\Workspaces\%TeamProject%\Tools"
CD "C:\Workspaces\%TeamProject%"
PAUSE

ECHO.
ECHO Drop existing workspace
ECHO.
"C:\Program Files\Microsoft Visual Studio 10.0\Common7\IDE\TF.EXE" workspace /delete /noprompt /collection:http://%TFS%:8080/tfs/%TPC% "%TeamProject%"

PAUSE

ECHO.
ECHO Create workspace mapping
ECHO.
"C:\Program Files\Microsoft Visual Studio 10.0\Common7\IDE\TF.EXE" workspace /new /noprompt /computer:%TFS% /comment:"%Comment%" /collection:http://%TFS%:8080/tfs/%TPC% "%TeamProject%"
"C:\Program Files\Microsoft Visual Studio 10.0\Common7\IDE\TF.EXE" workfold /collection:http://%TFS%:8080/tfs/%TPC% /workspace:"%TeamProject%" /unmap $/
"C:\Program Files\Microsoft Visual Studio 10.0\Common7\IDE\TF.EXE" workfold /collection:http://%TFS%:8080/tfs/%TPC% /workspace:"%TeamProject%" /map $/"%TeamProject%" "C:\Workspaces\%TeamProject%"

PAUSE

ECHO.
ECHO Adding folders to version control
ECHO.

"C:\Program Files\Microsoft Visual Studio 10.0\Common7\IDE\TF.EXE" add C:\Workspaces\%TeamProject%\Code /recursive /noprompt
"C:\Program Files\Microsoft Visual Studio 10.0\Common7\IDE\TF.EXE" add C:\Workspaces\%TeamProject%\Documents /recursive /noprompt
"C:\Program Files\Microsoft Visual Studio 10.0\Common7\IDE\TF.EXE" add C:\Workspaces\%TeamProject%\Tools /recursive /noprompt

ECHO.
ECHO Check in
ECHO.

pause

"C:\Program Files\Microsoft Visual Studio 10.0\Common7\IDE\TF.EXE" checkin /comment:"%Comment%" /noprompt /recursive "C:\Workspaces\%TeamProject%"

PAUSE
