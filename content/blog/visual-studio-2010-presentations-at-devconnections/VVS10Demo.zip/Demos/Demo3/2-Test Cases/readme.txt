Visual Studio 2010 Test Case Import Utilities 
http://tcmimport.codeplex.com/
