﻿//  Copyright (c) Microsoft Corporation.  All rights reserved.

namespace Microsoft.VisualStudio.TestTools.TestCaseMigrator
{
    using System.Windows;
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for MigrationProgress.xaml
    /// </summary>
    internal partial class MigrationProgressView : ContentControl
    {
        #region Fields
        
        MigrationProgressPart m_part;
        
        #endregion

        #region Constructor
        
        public MigrationProgressView(MigrationProgressPart part)
        {
            InitializeComponent();
            m_part = part;
            DataContext = part;
        }
        
        #endregion

        #region private methods
        
        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            string workSheetName = null;
            if (sender == ErrorLink)
            {
                workSheetName = ExcelReporter.ErrorSheetName;
            }
            else if (sender == WarningLink)
            {
                workSheetName = ExcelReporter.WarningSheetName;
            }
            else if (sender == PassedLink)
            {
                workSheetName = ExcelReporter.SuccessSheetName;
            }

            m_part.ShowReport(workSheetName);
        }

        private void StopButton_Click(object sender, RoutedEventArgs e)
        {
            m_part.StopMigration();
        }
        
        #endregion
    }
}
