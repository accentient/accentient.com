﻿//  Copyright (c) Microsoft Corporation.  All rights reserved.

namespace Microsoft.VisualStudio.TestTools.TestCaseMigrator
{
    /// <summary>
    /// Enumerator that shows the different WizardStates possible in the Wizard. 
    /// It is used by Wizard to distinguish one Wizard page from another.
    /// </summary>
    internal enum WizardPage
    {
        Welcome,
        SelectDataSource,
        SelectDestinationServer,
        SettingsFile,
        FieldsSelection,
        FieldMapping,
        DataMapping,
        MiscSettings,
        ConfirmSettings,
        MigrationProgress
    }
}
