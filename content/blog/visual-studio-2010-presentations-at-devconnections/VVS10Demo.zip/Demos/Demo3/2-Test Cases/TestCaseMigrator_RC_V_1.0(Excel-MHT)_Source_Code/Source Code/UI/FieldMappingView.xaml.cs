﻿//  Copyright (c) Microsoft Corporation.  All rights reserved.

namespace Microsoft.VisualStudio.TestTools.TestCaseMigrator
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for MapColumns.xaml
    /// </summary>
    internal partial class FieldMappingView : ContentControl
    {
        #region Constructor
        
        public FieldMappingView(FieldMappingPart part)
        {
            InitializeComponent();
            DataContext = part;
        }
       
        #endregion

        #region private methods
        
        private void WIFieldComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox wiFieldBox = sender as ComboBox;
            FieldMappingRow row = wiFieldBox.DataContext as FieldMappingRow;
            if (wiFieldBox.SelectedItem != null)
            {
                row.TFSField = wiFieldBox.SelectedItem.ToString();
            }
        }
        
        #endregion
    }
}
