﻿//  Copyright (c) Microsoft Corporation.  All rights reserved.

namespace Microsoft.VisualStudio.TestTools.TestCaseMigrator
{
    using System;
    using System.Windows;
    using System.Windows.Controls;
    using Microsoft.Win32;

    /// <summary>
    /// Interaction logic for FieldsSelectionView.xaml
    /// </summary>
    internal partial class FieldsSelectionView : ContentControl
    {
        #region Fields
        
        private FieldsSelectionPart m_part;
        
        #endregion

        #region Constructor
        
        public FieldsSelectionView(FieldsSelectionPart fieldsSelectionPart)
        {
            m_part = fieldsSelectionPart;
            DataContext = fieldsSelectionPart;
            InitializeComponent();
        }

        #endregion
        
        #region private methods
        
        private void MHTFileBrowse_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            Nullable<bool> result;
            dlg.Filter = "MHT files (*.doc,*.docx,*.mht)|*.doc;*.docx;*.mht|All files(*.*)|*.*";
            // Show open file dialog box
            try
            {
                result = dlg.ShowDialog();
            }
            catch (AccessViolationException)
            {
                MessageHelper.ShowError("Unable to load the open dialog",
                                        "Some error has ocurred which prevented in opening the dialog",
                                        "Please try to launh open dialog again");
                return;
            }

            // Process open file dialog box results
            if (result == true)
            {
                m_part.SourcePath = dlg.FileName;
            }
        }

        private void AddNewFieldNameButton_Click(object sender, RoutedEventArgs e)
        {

            if (!string.IsNullOrEmpty(NewFieldNameInputBox.Text))
            {
                string newField = NewFieldNameInputBox.Text.Trim();

                if (m_part.AddFieldName(newField))
                {
                    NewFieldNameInputBox.Text = string.Empty;
                }
                else
                {
                    MessageHelper.ShowError("Unable to add field name",
                                            "Given field name could not be found in the sample mht file",
                                            "Please make sure that the field name is present in the sample mht file");
                }
            }
        }

        private void DeleteFieldNameButton_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button != null && button.DataContext != null)
            {
                SourceField field = (SourceField)button.DataContext;
                m_part.Fields.Remove(field);
            }
        }

        private void Preview_Click(object sender, RoutedEventArgs e)
        {
            m_part.Preview();
        }

        #endregion
    }
}
