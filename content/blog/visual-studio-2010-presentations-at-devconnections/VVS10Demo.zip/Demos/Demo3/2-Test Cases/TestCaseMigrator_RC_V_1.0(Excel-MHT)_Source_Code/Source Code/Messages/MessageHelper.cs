﻿//  Copyright (c) Microsoft Corporation.  All rights reserved.

namespace Microsoft.VisualStudio.TestTools.TestCaseMigrator
{
    /// <summary>
    /// Delegate Definition used by Message helper to show Messages
    /// </summary>
    /// <param name="args"></param>
    internal delegate void ShowMessageDelegate(MessageEventArgs args);


    internal static class MessageHelper
    {
        #region Properties

        /// <summary>
        /// Delegate for showing messges
        /// </summary>
        public static ShowMessageDelegate ShowMessageWindow
        {
            get;
            set;
        }

        #endregion

        #region Error Messages

        /// <summary>
        /// Shows error Message with title only
        /// </summary>
        /// <param name="title"></param>
        public static void ShowError(string title)
        {
            ShowError(title, null, null);
        }

        /// <summary>
        /// Shows error message with title and likelycause
        /// </summary>
        /// <param name="title"></param>
        /// <param name="likelyCause"></param>
        public static void ShowError(string title, string likelyCause)
        {
            ShowError(title, likelyCause, null);
        }

        /// <summary>
        /// Shows error message with title, likely cause and potential Solution
        /// </summary>
        /// <param name="title"></param>
        /// <param name="likelyCause"></param>
        /// <param name="potentialSolution"></param>
        public static void ShowError(string title, string likelyCause, string potentialSolution)
        {
            if (ShowMessageWindow != null)
            {
                MessageEventArgs args = new MessageEventArgs(MessageCategory.Error,
                                                            title,
                                                            likelyCause,
                                                            potentialSolution,
                                                            null,
                                                            null,
                                                            Resources.CloseButtonLabel,
                                                            null);
                ShowMessageWindow(args);
            }
        }

        public static void ShowError(MessageEventArgs args)
        {
            if (ShowMessageWindow != null)
            {
                ShowMessageWindow(args);
            }
        }

        #endregion

        #region Information Messages

        /// <summary>
        /// Shows information with title and information details with OK button
        /// </summary>
        /// <param name="title">Title of the information</param>
        /// <param name="likelyCause">Detail information</param>
        public static void ShowInfo(string title, string likelyCause)
        {
            if (ShowMessageWindow != null)
            {
                MessageEventArgs args = new MessageEventArgs(MessageCategory.Information,
                                                             title,
                                                             likelyCause,
                                                             null,
                                                             null,
                                                             null,
                                                             Resources.OKButtonLabel,
                                                             null);
                ShowMessageWindow(args);
            }
        }

        #endregion

    }
}
