﻿//  Copyright (c) Microsoft Corporation.  All rights reserved.

namespace Microsoft.VisualStudio.TestTools.TestCaseMigrator
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.IO;

    internal class ExcelStorageInfo : NotifyPropertyChange, IDataStorageInfo
    {
        #region Fields
        
        private bool m_isMultiLineSense;
        private string m_endParameterizationDelimeter;
        private string m_startParameterizationDelimeter; 
        private string m_sourceFilePath;
        private string m_worksheetName;
        private string m_headerRow;
        
        #endregion

        #region Constructor

        public ExcelStorageInfo(string source)
        {
            if (string.IsNullOrEmpty(source))
            {
                throw new ArgumentNullException("source", "source is null");
            }
            if (!File.Exists(source) || (Path.GetExtension(source) != ".xls" && Path.GetExtension(source) != ".xlsx"))
            {
                throw new ArgumentException("source is not valid", "source");
            }
            Source = source;
            HeaderRow = "1";
        }

        #endregion

        #region Properties
        
        /// <summary>
        /// Percentage of parsing done for excel source
        /// </summary>
        public double ProgressPercentage
        {
            get;
            set;
        }

        /// <summary>
        /// Excel Workbook Path
        /// </summary>
        public string Source
        {
            get
            {
                return m_sourceFilePath;
            }
            private set
            {
                m_sourceFilePath = value;
                NotifyPropertyChanged("Source");
            }
        }

        /// <summary>
        /// Start delimeter for source parameters
        /// </summary>
        public string StartParameterizationDelimeter
        {
            get
            {
                return m_startParameterizationDelimeter;
            }
            set
            {
                m_startParameterizationDelimeter = value;
                NotifyPropertyChanged("StartParameterizationDelimeter");
            }
        }

        /// <summary>
        /// End Delimeter for Source Paramateres
        /// </summary>
        public string EndParameterizationDelimeter
        {
            get
            {
                return m_endParameterizationDelimeter;
            }
            set
            {
                m_endParameterizationDelimeter = value;
                NotifyPropertyChanged("EndParameterizationDelimeter");
            }
        }

        /// <summary>
        /// Are multi steps present in single excel cell
        /// </summary>
        public bool IsMultilineSense
        {
            get
            {
                return m_isMultiLineSense;
            }
            set
            {
                m_isMultiLineSense = value;
                NotifyPropertyChanged("IsMultiLineSense");
            }
        }

        /// <summary>
        /// Field Names found in Excel Source
        /// </summary>
        public IList<SourceField> FieldNames
        {
            get;
            set;
        }

        /// <summary>
        /// Worksheet to parse
        /// </summary>
        public string WorkSheetName
        {
            get
            {
                return m_worksheetName;
            }
            set
            {
                m_worksheetName = value;
                NotifyPropertyChanged("WorkSheetName");
            }
        }

        /// <summary>
        /// Excel Row containing Field names
        /// </summary>
        public string HeaderRow
        {
            get
            {
                return m_headerRow;
            }
            set
            {
                m_headerRow = value;
                NotifyPropertyChanged("HeaderRow");
            }

        }

        /// <summary>
        /// List of Excel Sheets to be shown on a selection of an excel file path
        /// </summary>
        public ObservableCollection<string> WorkSheets
        {
            get;
            private set;
        }

        #endregion
    }
}
