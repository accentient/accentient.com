﻿//  Copyright (c) Microsoft Corporation.  All rights reserved.

namespace Microsoft.VisualStudio.TestTools.TestCaseMigrator
{
    using System.Windows;
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for ConfirmSettings.xaml
    /// </summary>
    internal partial class ConfirmSettingsView : ContentControl
    {
        #region Fields
        
        ConfirmSettingsPart m_part;
        
        #endregion

        #region Constructor
        
        public ConfirmSettingsView(ConfirmSettingsPart part)
        {
            m_part = part;
            InitializeComponent();
            DataContext = part;
        }
        
        #endregion

        #region Private methods

        private void Hyperlink_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            Clipboard.SetText(m_part.Info.CommandUsed);
        }
        
        #endregion
    }
}
