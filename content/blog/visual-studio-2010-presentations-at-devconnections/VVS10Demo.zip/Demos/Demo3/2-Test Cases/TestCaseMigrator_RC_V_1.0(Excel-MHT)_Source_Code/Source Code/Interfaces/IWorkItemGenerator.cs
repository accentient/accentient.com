﻿//  Copyright (c) Microsoft Corporation.  All rights reserved.

namespace Microsoft.VisualStudio.TestTools.TestCaseMigrator
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;


    /// <summary>
    /// Reponsible for all TFS related activities
    /// </summary>
    public interface IWorkItemGenerator : IDisposable, INotifyPropertyChanged
    {
        /// <summary>
        /// TFS Server Collection URL
        /// </summary>
        string Server { get; }


        /// <summary>
        /// Team Project Name
        /// </summary>
        string Project { get; }


        /// <summary>
        /// WorkItem Category 
        /// </summary>
        WorkItemCategory WorkItemCategory { get;  set; }


        /// <summary>
        /// Gets the name of all workitem types in a Workitem Category
        /// </summary>
        /// <param name="wiCategaory"></param>
        /// <returns></returns>
        IList<string> WorkItemTypeNames { get; }


        /// <summary>
        /// Returns the name of the default workitem type in a workitem category
        /// </summary>
        /// <param name="wiCategaory"></param>
        /// <returns></returns>
        string DefaultWorkItemTypeName { get; }


        /// <summary>
        /// Slected WorkItem Type's Name
        /// </summary>
        string WorkItemTypeName { get; set; }


        /// <summary>
        /// Whether to add 'Test Step Title' and 'Test Step Expected Result' FIeld. Required for Excel migration.
        /// </summary>
        bool AddTestStepsField { get;  set; }


        /// <summary>
        /// Hashtable of WorkItemFields by FieldName
        /// </summary>
        IDictionary<string, IWorkItemField> TfsNameToFieldMapping { get; }


        /// <summary>
        /// Mapping from source field name to 'IWorkItemField'
        /// </summary>
        IDictionary<string, IWorkItemField> SourceNameToFieldMapping { get; set; }


        /// <summary>
        /// Creates 'IWorkItem'(TFS WorkItem Wrapper) object from Source Workitem
        /// </summary>
        /// <param name="dsWorkItem"></param>
        /// <returns></returns>
        IWorkItem CreateWorkItem(SourceWorkItem dsWorkItem);


        /// <summary>
        /// Saves TFS Workitem and return Result WorkItem(Passed/Failed/Warning) depending upon result of migration.
        /// </summary>
        /// <param name="workItem"></param>
        /// <param name="dataSourceWorkItem"></param>
        /// <returns></returns>
        SourceWorkItem SaveWorkItem(IWorkItem workItem, SourceWorkItem dataSourceWorkItem);
    }
}
