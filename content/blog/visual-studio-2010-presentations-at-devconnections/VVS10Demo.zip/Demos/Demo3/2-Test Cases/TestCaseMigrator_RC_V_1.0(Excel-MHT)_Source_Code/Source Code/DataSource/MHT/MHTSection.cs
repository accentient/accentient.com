﻿//  Copyright (c) Microsoft Corporation.  All rights reserved.

namespace Microsoft.VisualStudio.TestTools.TestCaseMigrator
{
    internal enum MHTSection
    {
        Title,
        History,
        Steps,
        Default,
        Skip
    }
}
