﻿//  Copyright (c) Microsoft Corporation.  All rights reserved.

namespace Microsoft.VisualStudio.TestTools.TestCaseMigrator
{
    using System.Collections.Generic;

    /// <summary>
    /// Encapsulates Field name with the attribute whether this field is deletable or not?
    /// </summary>
    public class SourceField : NotifyPropertyChange
    {
        public string FieldName
        {
            get;
            private set;
        }

        public bool CanDelete
        {
            get;
            private set;
        }

        public SourceField(string fieldName, bool canDelete)
        {
            FieldName = fieldName;
            CanDelete = canDelete;
        }
    }

    /// <summary>
    /// Internal Data Structre that represents TFS Test Step Field
    /// </summary>
    internal struct SourceTestStep
    {
        public string title;
        public string expectedResult;
        public List<string> attachments;

        public SourceTestStep(string title, string expectedResult, List<string> attachments)
        {
            this.title = title;
            this.expectedResult = expectedResult;
            this.attachments = attachments;
        }
    }

    /// <summary>
    /// Internal Data Structure that represents a single entiity to be imported into TFS server as a workitem
    /// </summary>
    public class SourceWorkItem
    {
        public string SourcePath
        {
            get;
            set;
        }

        /// <summary>
        /// A HashTable of mapping between Field to Value
        /// </summary>
        public Dictionary<string, object> FieldValuePairs
        {
            get;
            protected set;
        }

        public SourceWorkItem()
        {
            FieldValuePairs = new Dictionary<string, object>();
        }
    }

    /// <summary>
    /// Internal Data Structure for TFS Workitem with an error
    /// It is a failed Data Source WorkItem which is failed to migrate with an error.
    /// </summary>
    internal class FailedSourceWorkItem : SourceWorkItem
    {
        /// <summary>
        /// The error which is caused while migration
        /// </summary>
        public string Error
        {
            get;
            set;
        }

        public FailedSourceWorkItem(SourceWorkItem dsWorkItem, string error)
        {
            FieldValuePairs = dsWorkItem.FieldValuePairs;
            SourcePath = dsWorkItem.SourcePath;
            this.Error = error;
        }
    }

    /// <summary>
    /// Internal Data Structure for TFS Workitem with a warning
    /// It is a passed Data Source WorkItem which has different value from the Data Source in some of its field
    /// </summary>
    internal class WarningSourceWorkItem : PassedSourceWorkItem
    {
        /// <summary>
        /// The error which is caused while migration
        /// </summary>
        public string Warning
        {
            get;
            set;
        }

        public WarningSourceWorkItem(SourceWorkItem dsWorkItem, int id, string warning)
            : base(dsWorkItem, id)
        {
            this.Warning = warning;
        }
    }

    /// <summary>
    /// The Data Source WorkItem which is successfully migrated to TFS.
    /// It has additional ID information which is the ID of corresponding migrated workitem in TFS
    /// </summary>
    internal class PassedSourceWorkItem : SourceWorkItem
    {
        /// <summary>
        /// The ID of successfully migrated workitem in the TFS
        /// </summary>
        public int ID
        {
            get;
            set;
        }

        public PassedSourceWorkItem(SourceWorkItem dsWorkItem, int id)
        {
            FieldValuePairs = dsWorkItem.FieldValuePairs;
            SourcePath = dsWorkItem.SourcePath;
            this.ID = id;
        }
    }

}
