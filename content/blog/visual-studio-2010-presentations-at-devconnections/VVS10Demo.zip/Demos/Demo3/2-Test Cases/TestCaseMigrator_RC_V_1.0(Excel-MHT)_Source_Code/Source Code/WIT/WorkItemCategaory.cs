﻿//  Copyright (c) Microsoft Corporation.  All rights reserved.

namespace Microsoft.VisualStudio.TestTools.TestCaseMigrator
{
    /// <summary>
    /// Enumerator for different type of Work Items. 
    /// It is used by TFS Writer to know which workitem it has to write into the TFS.
    /// </summary>
    public enum WorkItemCategory
    {
        TestCase
    }
}
