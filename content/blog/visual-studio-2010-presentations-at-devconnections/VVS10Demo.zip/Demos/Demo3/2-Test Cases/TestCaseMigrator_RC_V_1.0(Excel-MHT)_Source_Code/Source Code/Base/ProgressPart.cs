﻿//  Copyright (c) Microsoft Corporation.  All rights reserved.

namespace Microsoft.VisualStudio.TestTools.TestCaseMigrator
{
    /// <summary>
    /// back end part of Progress View
    /// </summary>
    class ProgressPart : NotifyPropertyChange
    {
        #region Fields

        private string m_text;
        private string m_title;
        private double m_progressValue;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor to intialize Title, Text and Progress Status 
        /// </summary>
        /// <param name="title"></param>
        /// <param name="text"></param>
        public ProgressPart(string title, string text)
        {
            // Removing Wait Cursor
            using (new AutoWaitCursor())
            { }

            ProgressValue = 0;
            Title = title;
            Text = text;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Title of the Progress Overlay Part
        /// </summary>
        public string Title
        {
            get
            {
                return m_title;
            }
            set
            {
                m_title = value;
                NotifyPropertyChanged("Title");
            }
        }

        public string Text
        {
            get
            {
                return m_text;
            }
            set
            {
                m_text = value;
                NotifyPropertyChanged("Text");
            }
        }

        /// <summary>
        /// This is the percentage of work completed.
        /// </summary>
        public double ProgressValue
        {
            get
            {
                return m_progressValue;
            }
            set
            {
                m_progressValue = value;
                NotifyPropertyChanged("ProgressValue");
            }
        }

        #endregion
    }
}
