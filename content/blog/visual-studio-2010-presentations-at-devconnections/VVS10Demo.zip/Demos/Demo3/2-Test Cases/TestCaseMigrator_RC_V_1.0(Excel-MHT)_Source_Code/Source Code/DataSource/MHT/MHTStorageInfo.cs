﻿//  Copyright (c) Microsoft Corporation.  All rights reserved.

namespace Microsoft.VisualStudio.TestTools.TestCaseMigrator
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    
    internal class MHTStorageInfo : NotifyPropertyChange, IDataStorageInfo
    {
        #region Fields

        private string m_source;
        private string m_startParameterizationDelimeter;
        private string m_endParameterizationDelimeter;
        private bool m_isMultiLineSense;

        #endregion

        #region Constants

        private const string MHTExtension = ".mht";

        #endregion

        #region Properties

        /// <summary>
        /// MHT File Path
        /// </summary>
        public string Source
        {
            get
            {
                return m_source;
            }
            private set
            {
                m_source = value;
                NotifyPropertyChanged("Source");
            }
        }

        public string StartParameterizationDelimeter
        {
            get
            {
                return m_startParameterizationDelimeter;
            }
            set
            {
                m_startParameterizationDelimeter = value;
                NotifyPropertyChanged("StartParameterizationDelimeter");
            }
        }

        public string EndParameterizationDelimeter
        {
            get
            {
                return m_endParameterizationDelimeter;
            }
            set
            {
                m_endParameterizationDelimeter = value;
                NotifyPropertyChanged("EndParameterizationDelimeter");
            }
        }

        public bool IsMultilineSense
        {
            get
            {
                return m_isMultiLineSense;
            }
            set
            {
                m_isMultiLineSense = value;
                NotifyPropertyChanged("MultiLineSense");
            }
        }

        public IList<SourceField> FieldNames
        {
            get;
            set;
        }

        /// <summary>
        /// List of allowed field names for this MHT File
        /// </summary>
        public IList<string> PossibleFieldNames
        {
            get;
            set;
        }

        /// <summary>
        /// Is First Line of MHT file Title?
        /// </summary>
        public bool IsFirstLineTitle
        {
            get;
            set;
        }

        /// <summary>
        /// whether to take file name as title?
        /// </summary>
        public bool IsFileNameTitle
        {
            get;
            set;
        }

        /// <summary>
        /// this is field name mapped to TFS title field
        /// </summary>
        public string TitleField
        {
            get;
            set;
        }

        /// <summary>
        /// Field Name of Steps Field
        /// </summary>
        public string StepsField
        {
            get;
            set;
        }

        #endregion

        #region Constructor

        public MHTStorageInfo(string mhtSource)
        {
            if (mhtSource == null)
            {
                throw new ArgumentNullException("mhtSource", "mhtSource is null");
            }

            if (!File.Exists(mhtSource) ||
                (Path.GetExtension(mhtSource) != MHTExtension && Path.GetExtension(mhtSource) != ".doc" && Path.GetExtension(mhtSource) != ".docx"))
            {
                throw new ArgumentException("mhtSource is not valid", "mhtSource");
            }

            Source = mhtSource;
            FieldNames = new List<SourceField>();
        }

        #endregion
    }
}