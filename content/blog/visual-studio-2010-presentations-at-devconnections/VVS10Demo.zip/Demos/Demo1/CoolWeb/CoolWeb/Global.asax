﻿<%@ Application Codebehind="Global.asax.cs" Inherits="CoolWeb.Global" Language="C#" %>
