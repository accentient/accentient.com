﻿Before running this application:

 1. Read through all the source code to know what it will do. It contains code that can destroy artifacts in your team project.
 2. Have TFS/VSO team project already provisioned.
 3. Have enabled Alternate Credentials (VSO) - this article explains how: http://bit.ly/1H2ctKi

To configure this application to your environment:

 1. Open App.config and change the default values accordingly.
 2. Run the app and respond to the questions to create areas, sprints, product backlog, etc.

Notes

 * If you receive a TF54000 "Cannot update data because the server clock may have been set incorrectly" message, you should just retry again in a few seconds.
 * If you specify a Product Owner in the App.config file, make sure it's the friendly name and that person exists in the team project.
