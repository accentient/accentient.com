﻿using System;
using System.IO;

namespace Unbind
{
  class Program
  {
    static void RemoveBindings(string[] files,StreamWriter Log)
    {
      foreach (string file in files)
      {
        try
        {
          Log.WriteLine(file);
          string line;
          bool startDeleting = false;
          StreamReader SR = new StreamReader(file);
          StreamWriter SW = new StreamWriter(file + ".new.txt", false);
          while ((line = SR.ReadLine()) != null)
          {
            if (line.ToLower().Contains("globalsection(teamfoundationversioncontrol)"))
            {
              startDeleting = true;
              Log.WriteLine("  Removed: " + line.Trim());
            }
            else if (startDeleting && line.ToLower().Contains("endglobalsection"))
            {
              startDeleting = false;
              Log.WriteLine("  Removed: " + line.Trim());
            }
            else if (startDeleting)
            {
              Log.WriteLine("  Removed: " + line.Trim());
            }
            else if (line.ToLower().Contains("\tscc") || line.ToLower().Contains("<scc"))
            {
              Log.WriteLine("  Removed: " + line.Trim());
            }
            else
            {
              SW.WriteLine(line);
            }
          }
          SR.Close();
          SW.Close();
          File.Copy(file + ".new.txt", file, true);
          File.Delete(file + ".new.txt");
        }
        catch (Exception)
        {
        }
      }
    }

    static void Main(string[] args)
    {
      Console.WriteLine("Have you made a backup first? Y=continue");
      string prompt = Console.ReadLine();
      if (prompt.ToLower() != "y")
      {
        return;
      }

      // Looks in current directory and below for *.sln and *.proj files
      // For testing, I set the Project's startup folder properties to C:\FF\FabrikamFiber

      StreamWriter Log = new StreamWriter("log.txt", false);
      RemoveBindings(Directory.GetFiles(".", "*.sln", SearchOption.AllDirectories),Log);
      RemoveBindings(Directory.GetFiles(".", "*.*proj",SearchOption.AllDirectories),Log);
      Log.Close();
    }
  }
}
