using System;
using Microsoft.SqlServer.Server;
using System.Data.SqlTypes;
using System.Runtime.InteropServices;

namespace Demos.UDAF
{
	[SqlUserDefinedAggregate(Format.Native, 
		IsInvariantToDuplicates=false, 
		IsInvariantToNulls=true, 
		IsInvariantToOrder=true, 
		IsNullIfEmpty=true), Serializable(),
		StructLayout(LayoutKind.Sequential)]
	public class CharacterCount
	{
		int count = 0;
		
		public void Init()
		{
			count = 0;
		}

		public void Accumulate(SqlString value)
		{
			if (value == null)
				return;

			count += value.Value.Length;
		}

		public void Merge(CharacterCount ch)
		{
			count += ch.count;
		}

		public SqlInt32 Terminate()
		{
			return count;
		}
}
}
