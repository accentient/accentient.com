using System;
using System.Data;
using System.Data.SqlClient;
using Microsoft.SqlServer.Server;
using System.Transactions; // Add a reference to System.Transactions

public partial class Triggers
{

  [Microsoft.SqlServer.Server.SqlTrigger (Name="clrSimpleInsertTrigger", Target="TestTable", Event="FOR INSERT")]
  public static void clrSimpleInsertTrigger()
  {
    SqlContext.Pipe.Send("Thank you for the INSERT!");
  }

  [Microsoft.SqlServer.Server.SqlTrigger(Name = "clrSimpleUpdateTrigger", Target = "TestTable", Event = "FOR UPDATE")]
  public static void clrSimpleUpdateTrigger()
  {
    SqlTriggerContext tc = SqlContext.TriggerContext;
    SqlContext.Pipe.Send(tc.ColumnCount.ToString() + " Column(s)");
    SqlContext.Pipe.Send("TriggerAction: " + tc.TriggerAction.ToString());
    SqlContext.Pipe.Send("Updating Column 0? : " + tc.IsUpdatedColumn(0).ToString());
    SqlContext.Pipe.Send("Updating Column 1? : " + tc.IsUpdatedColumn(1).ToString());
  }

  [Microsoft.SqlServer.Server.SqlTrigger(Name = "clrSimpleRollbackTrigger", Target = "TestTable", Event = "FOR DELETE")]
  public static void clrSimpleRollbackTrigger()
  {
    Transaction.Current.Rollback(new ArgumentException("You cannot delete tables!"));
  }

  [Microsoft.SqlServer.Server.SqlTrigger(Name = "clrSimpleUpdateTrigger", Target = "TestTable", Event = "AFTER UPDATE")]
  public static void clrSimpleUpdateTrigger()
  {
    SqlTriggerContext tc = SqlContext.TriggerContext;
    SqlContext.Pipe.Send(tc.ColumnCount.ToString() + " Column(s)");
    SqlContext.Pipe.Send("TriggerAction: " + tc.TriggerAction.ToString());
    SqlContext.Pipe.Send("Updating Column 0? : " + tc.IsUpdatedColumn(0).ToString());
    SqlContext.Pipe.Send("Updating Column 1? : " + tc.IsUpdatedColumn(1).ToString());
  }

  [Microsoft.SqlServer.Server.SqlTrigger(Name = "clrSimpleUpdateTrigger", Target = "TestTable", Event = "INSTEAD OF UPDATE")]
  public static void clrSimpleUpdateTrigger()
  {
    SqlTriggerContext tc = SqlContext.TriggerContext;
    SqlContext.Pipe.Send(tc.ColumnCount.ToString() + " Column(s)");
    SqlContext.Pipe.Send("TriggerAction: " + tc.TriggerAction.ToString());
    SqlContext.Pipe.Send("Updating Column 0? : " + tc.IsUpdatedColumn(0).ToString());
    SqlContext.Pipe.Send("Updating Column 1? : " + tc.IsUpdatedColumn(1).ToString());
  }

  // Have to manually CREATE/DROP This trigger

  public static void clrCreateTableTrigger()
  {
    SqlTriggerContext trgContext = SqlContext.TriggerContext;
    if (trgContext.TriggerAction == TriggerAction.CreateTable)
    {
      SqlContext.Pipe.Send("Thank you for the new table!");
    }
  }

  // Have to manually CREATE/DROP This trigger

  public static void clrCreateViewTrigger()
  {
    SqlTriggerContext trgContext = SqlContext.TriggerContext;
    if (trgContext.TriggerAction == TriggerAction.CreateView)
    {
      SqlContext.Pipe.Send(trgContext.EventData.Value);
    }
  }

}
