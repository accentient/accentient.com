using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

public partial class UserDefinedFunctions
{
  [Microsoft.SqlServer.Server.SqlFunction]
  public static SqlString clrSimpleFunction()
  {
    return new SqlString("Hello World");
  }

  [Microsoft.SqlServer.Server.SqlFunction(DataAccess=DataAccessKind.None)]
  public static SqlString clrNoDataAccessFunction()
  {
    return new SqlString("Hello World");
  }

  [Microsoft.SqlServer.Server.SqlFunction]
	public static SqlString clrCoolEncrypt(SqlString Data)
	{
		char[] strArray = Data.ToString().ToCharArray();
		Array.Reverse(strArray);
		return new string(strArray);
	}

  [SqlFunction(FillRowMethodName = "clrGetStringsFillRow", TableDefinition = "Value nvarchar(60)")]
  public static System.Collections.IEnumerable clrGetStrings(SqlString str)
  {
    return str.Value.Split(',');
  }

  public static void clrGetStringsFillRow(object row, out string str)
  {
    str = (string)row;
  }

};

