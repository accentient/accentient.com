using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class Service : System.Web.Services.WebService
{

    [WebMethod]
    public string About() {
        return "Currency Conversion WS for testing. Supports USD, EUR, ILS. Based on Yahoo 17 Nov, 2005";
    }

  [WebMethod]
  public decimal Convert(decimal FromAmount, string FromCurrencyCode, string ToCurrencyCode)
  {

    if (FromCurrencyCode == "USD")
    {
      if (ToCurrencyCode == "USD")
      {
        return FromAmount;
      }
      else if (ToCurrencyCode == "EUR")
      {
        return FromAmount * 0.8558m;
      }
      else if (ToCurrencyCode == "ILS")
      {
        return FromAmount * 4.7250m;
      }
    }

    if (FromCurrencyCode == "EUR")
    {
      if (ToCurrencyCode == "EUR")
      {
        return FromAmount;
      }
      else if (ToCurrencyCode == "USD")
      {
        return FromAmount * 1.1687m;
      }
      else if (ToCurrencyCode == "ILS")
      {
        return FromAmount * 5.5202m;
      }
    }

    if (FromCurrencyCode == "ILS")
    {
      if (ToCurrencyCode == "ILS")
      {
        return FromAmount;
      }
      else if (ToCurrencyCode == "USD")
      {
        return FromAmount * 0.2117m;
      }
      else if (ToCurrencyCode == "EUR")
      {
        return FromAmount * 0.1812m;
      }
    }

    return 0;

  }
  
}
