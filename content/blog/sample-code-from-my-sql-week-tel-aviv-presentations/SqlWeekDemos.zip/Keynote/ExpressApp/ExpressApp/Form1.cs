using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ExpressApp
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    private void leadsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
    {
      this.Validate();
      this.leadsBindingSource.EndEdit();
      this.leadsTableAdapter.Update(this.salesDataSet.Leads);

    }

    private void Form1_Load(object sender, EventArgs e)
    {
      // TODO: This line of code loads data into the 'salesDataSet.Leads' table. You can move, or remove it, as needed.
      this.leadsTableAdapter.Fill(this.salesDataSet.Leads);

    }
  }
}