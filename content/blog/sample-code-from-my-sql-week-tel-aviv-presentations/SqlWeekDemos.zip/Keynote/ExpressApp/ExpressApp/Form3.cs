using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ExpressApp
{
  public partial class Form3 : Form
  {
    public Form3()
    {
      InitializeComponent();
    }

    private void Form3_Load(object sender, EventArgs e)
    {

      this.reportViewer1.RefreshReport();
    }
  }
}