namespace ExpressApp
{
  partial class Form4
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
      this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
      this.SalesDataSet = new ExpressApp.SalesDataSet();
      this.LeadsBindingSource = new System.Windows.Forms.BindingSource(this.components);
      this.LeadsTableAdapter = new ExpressApp.SalesDataSetTableAdapters.LeadsTableAdapter();
      ((System.ComponentModel.ISupportInitialize)(this.SalesDataSet)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.LeadsBindingSource)).BeginInit();
      this.SuspendLayout();
      // 
      // reportViewer1
      // 
      this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
      reportDataSource1.Name = "SalesDataSet_Leads";
      reportDataSource1.Value = this.LeadsBindingSource;
      this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
      this.reportViewer1.LocalReport.ReportEmbeddedResource = "ExpressApp.Report1.rdlc";
      this.reportViewer1.Location = new System.Drawing.Point(0, 0);
      this.reportViewer1.Name = "reportViewer1";
      this.reportViewer1.Size = new System.Drawing.Size(292, 273);
      this.reportViewer1.TabIndex = 0;
      // 
      // SalesDataSet
      // 
      this.SalesDataSet.DataSetName = "SalesDataSet";
      this.SalesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // LeadsBindingSource
      // 
      this.LeadsBindingSource.DataMember = "Leads";
      this.LeadsBindingSource.DataSource = this.SalesDataSet;
      // 
      // LeadsTableAdapter
      // 
      this.LeadsTableAdapter.ClearBeforeFill = true;
      // 
      // Form4
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.reportViewer1);
      this.Name = "Form4";
      this.Text = "Form4";
      this.Load += new System.EventHandler(this.Form4_Load);
      ((System.ComponentModel.ISupportInitialize)(this.SalesDataSet)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.LeadsBindingSource)).EndInit();
      this.ResumeLayout(false);

    }

    #endregion

    private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
    private System.Windows.Forms.BindingSource LeadsBindingSource;
    private SalesDataSet SalesDataSet;
    private ExpressApp.SalesDataSetTableAdapters.LeadsTableAdapter LeadsTableAdapter;
  }
}