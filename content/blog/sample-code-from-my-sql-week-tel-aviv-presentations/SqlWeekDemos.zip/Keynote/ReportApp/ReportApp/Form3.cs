using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ReportApp
{
  public partial class Form3 : Form
  {
    public Form3()
    {
      InitializeComponent();
    }

    private void testBindingNavigatorSaveItem_Click(object sender, EventArgs e)
    {
      this.Validate();
      this.testBindingSource.EndEdit();
      this.testTableAdapter.Update(this.myExpressDatabaseDataSet.Test);

    }

    private void Form3_Load(object sender, EventArgs e)
    {
      // TODO: This line of code loads data into the 'myExpressDatabaseDataSet.Test' table. You can move, or remove it, as needed.
      this.testTableAdapter.Fill(this.myExpressDatabaseDataSet.Test);

    }
  }
}