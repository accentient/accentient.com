namespace DeviceApp
{
  partial class frmResultSet
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;
    private System.Windows.Forms.MainMenu mainMenu1;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.mainMenu1 = new System.Windows.Forms.MainMenu();
      this.button1 = new System.Windows.Forms.Button();
      this.button2 = new System.Windows.Forms.Button();
      this.dataGrid1 = new System.Windows.Forms.DataGrid();
      this.button3 = new System.Windows.Forms.Button();
      this.panel1 = new System.Windows.Forms.Panel();
      this.webBrowser1 = new System.Windows.Forms.WebBrowser();
      this.panel1.SuspendLayout();
      this.SuspendLayout();
      // 
      // button1
      // 
      this.button1.Location = new System.Drawing.Point(4, 5);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(51, 20);
      this.button1.TabIndex = 0;
      this.button1.Text = "CE 2.0";
      this.button1.Click += new System.EventHandler(this.button1_Click);
      // 
      // button2
      // 
      this.button2.Location = new System.Drawing.Point(61, 5);
      this.button2.Name = "button2";
      this.button2.Size = new System.Drawing.Size(57, 20);
      this.button2.TabIndex = 1;
      this.button2.Text = "Reader";
      this.button2.Click += new System.EventHandler(this.button2_Click);
      // 
      // dataGrid1
      // 
      this.dataGrid1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
      this.dataGrid1.Location = new System.Drawing.Point(4, 31);
      this.dataGrid1.Name = "dataGrid1";
      this.dataGrid1.Size = new System.Drawing.Size(232, 100);
      this.dataGrid1.TabIndex = 2;
      // 
      // button3
      // 
      this.button3.Location = new System.Drawing.Point(124, 5);
      this.button3.Name = "button3";
      this.button3.Size = new System.Drawing.Size(112, 20);
      this.button3.TabIndex = 3;
      this.button3.Text = "SqlCeResultSet";
      this.button3.Click += new System.EventHandler(this.button3_Click);
      // 
      // panel1
      // 
      this.panel1.BackColor = System.Drawing.Color.Blue;
      this.panel1.Controls.Add(this.webBrowser1);
      this.panel1.Location = new System.Drawing.Point(4, 137);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(232, 128);
      // 
      // webBrowser1
      // 
      this.webBrowser1.Location = new System.Drawing.Point(3, 5);
      this.webBrowser1.Name = "webBrowser1";
      this.webBrowser1.Size = new System.Drawing.Size(226, 119);
      // 
      // frmResultSet
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
      this.ClientSize = new System.Drawing.Size(240, 268);
      this.Controls.Add(this.panel1);
      this.Controls.Add(this.button3);
      this.Controls.Add(this.dataGrid1);
      this.Controls.Add(this.button2);
      this.Controls.Add(this.button1);
      this.Menu = this.mainMenu1;
      this.Name = "frmResultSet";
      this.Text = "frmResultSet";
      this.panel1.ResumeLayout(false);
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.DataGrid dataGrid1;
    private System.Windows.Forms.Button button3;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.WebBrowser webBrowser1;
  }
}