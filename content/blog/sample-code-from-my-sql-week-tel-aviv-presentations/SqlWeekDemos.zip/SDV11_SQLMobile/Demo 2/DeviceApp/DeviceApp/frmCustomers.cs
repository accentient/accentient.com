using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DeviceApp
{
  public partial class frmCustomers : Form
  {
    public frmCustomers()
    {
      InitializeComponent();
    }

    private void frmCustomers_Load(object sender, EventArgs e)
    {
      if (SalesDataSetUtil.DesignerUtil.IsRunTime())
      {
        // TODO: Delete this line of code to remove the default AutoFill for 'salesDataSet.Customer'.
        this.customerTableAdapter.Fill(this.salesDataSet.Customer);
      }

    }
  }
}