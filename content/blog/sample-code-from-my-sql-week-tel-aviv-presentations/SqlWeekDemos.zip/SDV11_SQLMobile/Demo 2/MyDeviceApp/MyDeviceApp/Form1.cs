using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MyDeviceApp
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e)
    {
      if (SalesDataSetUtil.DesignerUtil.IsRunTime())
      {
        // TODO: Delete this line of code to remove the default AutoFill for 'salesDataSet.Product'.
        this.productTableAdapter.Fill(this.salesDataSet.Product);
      }
      if (SalesDataSetUtil.DesignerUtil.IsRunTime())
      {
        // TODO: Delete this line of code to remove the default AutoFill for 'salesDataSet.Customer'.
        this.customerTableAdapter.Fill(this.salesDataSet.Customer);
      }

    }
  }
}