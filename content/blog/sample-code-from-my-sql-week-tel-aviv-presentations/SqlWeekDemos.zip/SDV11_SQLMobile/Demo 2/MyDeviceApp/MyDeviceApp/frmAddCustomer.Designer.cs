namespace MyDeviceApp
{
  partial class frmAddCustomer
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;
    private System.Windows.Forms.MainMenu mainMenu1;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.mainMenu1 = new System.Windows.Forms.MainMenu();
      this.label1 = new System.Windows.Forms.Label();
      this.txtCustomer = new System.Windows.Forms.TextBox();
      this.btnAdd = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(4, 4);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(149, 20);
      this.label1.Text = "Add New Customer";
      // 
      // txtCustomer
      // 
      this.txtCustomer.Location = new System.Drawing.Point(4, 28);
      this.txtCustomer.Name = "txtCustomer";
      this.txtCustomer.Size = new System.Drawing.Size(220, 21);
      this.txtCustomer.TabIndex = 1;
      // 
      // btnAdd
      // 
      this.btnAdd.Location = new System.Drawing.Point(151, 56);
      this.btnAdd.Name = "btnAdd";
      this.btnAdd.Size = new System.Drawing.Size(72, 20);
      this.btnAdd.TabIndex = 2;
      this.btnAdd.Text = "Add!";
      this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
      // 
      // frmAddCustomer
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
      this.AutoScroll = true;
      this.ClientSize = new System.Drawing.Size(240, 268);
      this.Controls.Add(this.btnAdd);
      this.Controls.Add(this.txtCustomer);
      this.Controls.Add(this.label1);
      this.Menu = this.mainMenu1;
      this.Name = "frmAddCustomer";
      this.Text = "frmAddCustomer";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox txtCustomer;
    private System.Windows.Forms.Button btnAdd;
  }
}