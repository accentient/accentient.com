namespace MyDeviceApp
{
  partial class Form1
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;
    private System.Windows.Forms.MainMenu mainMenu1;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Windows.Forms.DataGridTextBoxColumn iDDataGridColumnStyleDataGridTextBoxColumn;
      System.Windows.Forms.DataGridTextBoxColumn nameDataGridColumnStyleDataGridTextBoxColumn;
      System.Windows.Forms.DataGridTextBoxColumn iDDataGridColumnStyleDataGridTextBoxColumn1;
      System.Windows.Forms.DataGridTextBoxColumn customerIDDataGridColumnStyleDataGridTextBoxColumn;
      System.Windows.Forms.DataGridTextBoxColumn nameDataGridColumnStyleDataGridTextBoxColumn1;
      this.mainMenu1 = new System.Windows.Forms.MainMenu();
      this.salesDataSet = new MyDeviceApp.SalesDataSet();
      this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
      this.customerTableAdapter = new MyDeviceApp.SalesDataSetTableAdapters.CustomerTableAdapter();
      this.customerDataGrid = new System.Windows.Forms.DataGrid();
      this.customerTableStyleDataGridTableStyle = new System.Windows.Forms.DataGridTableStyle();
      this.customer_ProductBindingSource = new System.Windows.Forms.BindingSource(this.components);
      this.productTableAdapter = new MyDeviceApp.SalesDataSetTableAdapters.ProductTableAdapter();
      this.productDataGrid = new System.Windows.Forms.DataGrid();
      this.productTableStyleDataGridTableStyle = new System.Windows.Forms.DataGridTableStyle();
      iDDataGridColumnStyleDataGridTextBoxColumn = new System.Windows.Forms.DataGridTextBoxColumn();
      nameDataGridColumnStyleDataGridTextBoxColumn = new System.Windows.Forms.DataGridTextBoxColumn();
      iDDataGridColumnStyleDataGridTextBoxColumn1 = new System.Windows.Forms.DataGridTextBoxColumn();
      customerIDDataGridColumnStyleDataGridTextBoxColumn = new System.Windows.Forms.DataGridTextBoxColumn();
      nameDataGridColumnStyleDataGridTextBoxColumn1 = new System.Windows.Forms.DataGridTextBoxColumn();
      this.SuspendLayout();
      // 
      // salesDataSet
      // 
      this.salesDataSet.DataSetName = "SalesDataSet";
      this.salesDataSet.Prefix = "";
      this.salesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // customerBindingSource
      // 
      this.customerBindingSource.DataMember = "Customer";
      this.customerBindingSource.DataSource = this.salesDataSet;
      // 
      // customerTableAdapter
      // 
      this.customerTableAdapter.ClearBeforeFill = true;
      // 
      // customerDataGrid
      // 
      this.customerDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
      this.customerDataGrid.DataSource = this.customerBindingSource;
      this.customerDataGrid.Location = new System.Drawing.Point(6, 10);
      this.customerDataGrid.Name = "customerDataGrid";
      this.customerDataGrid.Size = new System.Drawing.Size(223, 74);
      this.customerDataGrid.TabIndex = 0;
      this.customerDataGrid.TableStyles.Add(this.customerTableStyleDataGridTableStyle);
      // 
      // customerTableStyleDataGridTableStyle
      // 
      this.customerTableStyleDataGridTableStyle.GridColumnStyles.Add(iDDataGridColumnStyleDataGridTextBoxColumn);
      this.customerTableStyleDataGridTableStyle.GridColumnStyles.Add(nameDataGridColumnStyleDataGridTextBoxColumn);
      this.customerTableStyleDataGridTableStyle.MappingName = "Customer";
      // 
      // iDDataGridColumnStyleDataGridTextBoxColumn
      // 
      iDDataGridColumnStyleDataGridTextBoxColumn.HeaderText = "ID";
      iDDataGridColumnStyleDataGridTextBoxColumn.MappingName = "ID";
      // 
      // nameDataGridColumnStyleDataGridTextBoxColumn
      // 
      nameDataGridColumnStyleDataGridTextBoxColumn.HeaderText = "Name";
      nameDataGridColumnStyleDataGridTextBoxColumn.MappingName = "Name";
      // 
      // customer_ProductBindingSource
      // 
      this.customer_ProductBindingSource.DataMember = "Customer_Product";
      this.customer_ProductBindingSource.DataSource = this.customerBindingSource;
      // 
      // productTableAdapter
      // 
      this.productTableAdapter.ClearBeforeFill = true;
      // 
      // productDataGrid
      // 
      this.productDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
      this.productDataGrid.DataSource = this.customer_ProductBindingSource;
      this.productDataGrid.Location = new System.Drawing.Point(7, 96);
      this.productDataGrid.Name = "productDataGrid";
      this.productDataGrid.Size = new System.Drawing.Size(223, 157);
      this.productDataGrid.TabIndex = 1;
      this.productDataGrid.TableStyles.Add(this.productTableStyleDataGridTableStyle);
      // 
      // productTableStyleDataGridTableStyle
      // 
      this.productTableStyleDataGridTableStyle.GridColumnStyles.Add(iDDataGridColumnStyleDataGridTextBoxColumn1);
      this.productTableStyleDataGridTableStyle.GridColumnStyles.Add(customerIDDataGridColumnStyleDataGridTextBoxColumn);
      this.productTableStyleDataGridTableStyle.GridColumnStyles.Add(nameDataGridColumnStyleDataGridTextBoxColumn1);
      this.productTableStyleDataGridTableStyle.MappingName = "Product";
      // 
      // iDDataGridColumnStyleDataGridTextBoxColumn1
      // 
      iDDataGridColumnStyleDataGridTextBoxColumn1.HeaderText = "ID";
      iDDataGridColumnStyleDataGridTextBoxColumn1.MappingName = "ID";
      // 
      // customerIDDataGridColumnStyleDataGridTextBoxColumn
      // 
      customerIDDataGridColumnStyleDataGridTextBoxColumn.HeaderText = "CustomerID";
      customerIDDataGridColumnStyleDataGridTextBoxColumn.MappingName = "CustomerID";
      // 
      // nameDataGridColumnStyleDataGridTextBoxColumn1
      // 
      nameDataGridColumnStyleDataGridTextBoxColumn1.HeaderText = "Name";
      nameDataGridColumnStyleDataGridTextBoxColumn1.MappingName = "Name";
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
      this.AutoScroll = true;
      this.ClientSize = new System.Drawing.Size(240, 268);
      this.Controls.Add(this.productDataGrid);
      this.Controls.Add(this.customerDataGrid);
      this.Menu = this.mainMenu1;
      this.Name = "Form1";
      this.Text = "Form1";
      this.Load += new System.EventHandler(this.Form1_Load);
      this.ResumeLayout(false);

    }

    #endregion

    private SalesDataSet salesDataSet;
    private System.Windows.Forms.BindingSource customerBindingSource;
    private MyDeviceApp.SalesDataSetTableAdapters.CustomerTableAdapter customerTableAdapter;
    private System.Windows.Forms.DataGrid customerDataGrid;
    private System.Windows.Forms.DataGridTableStyle customerTableStyleDataGridTableStyle;
    private System.Windows.Forms.BindingSource customer_ProductBindingSource;
    private MyDeviceApp.SalesDataSetTableAdapters.ProductTableAdapter productTableAdapter;
    private System.Windows.Forms.DataGrid productDataGrid;
    private System.Windows.Forms.DataGridTableStyle productTableStyleDataGridTableStyle;
  }
}

