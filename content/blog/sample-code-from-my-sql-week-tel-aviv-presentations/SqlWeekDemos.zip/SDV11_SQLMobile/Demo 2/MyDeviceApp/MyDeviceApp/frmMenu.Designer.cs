namespace MyDeviceApp
{
  partial class frmMenu
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;
    private System.Windows.Forms.MainMenu mainMenu1;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.mainMenu1 = new System.Windows.Forms.MainMenu();
      this.menuItem1 = new System.Windows.Forms.MenuItem();
      this.menuItem2 = new System.Windows.Forms.MenuItem();
      this.menuItem3 = new System.Windows.Forms.MenuItem();
      this.menuItem4 = new System.Windows.Forms.MenuItem();
      this.menuItem5 = new System.Windows.Forms.MenuItem();
      this.menuItem6 = new System.Windows.Forms.MenuItem();
      this.menuItem7 = new System.Windows.Forms.MenuItem();
      this.menuItem8 = new System.Windows.Forms.MenuItem();
      this.menuItem9 = new System.Windows.Forms.MenuItem();
      this.SuspendLayout();
      // 
      // mainMenu1
      // 
      this.mainMenu1.MenuItems.Add(this.menuItem1);
      // 
      // menuItem1
      // 
      this.menuItem1.MenuItems.Add(this.menuItem2);
      this.menuItem1.MenuItems.Add(this.menuItem3);
      this.menuItem1.MenuItems.Add(this.menuItem4);
      this.menuItem1.MenuItems.Add(this.menuItem8);
      this.menuItem1.MenuItems.Add(this.menuItem9);
      this.menuItem1.MenuItems.Add(this.menuItem5);
      this.menuItem1.MenuItems.Add(this.menuItem6);
      this.menuItem1.MenuItems.Add(this.menuItem7);
      this.menuItem1.Text = "&Start";
      // 
      // menuItem2
      // 
      this.menuItem2.Text = "&Add Customer";
      this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
      // 
      // menuItem3
      // 
      this.menuItem3.Text = "&View Customers";
      this.menuItem3.Click += new System.EventHandler(this.menuItem3_Click);
      // 
      // menuItem4
      // 
      this.menuItem4.Text = "-";
      // 
      // menuItem5
      // 
      this.menuItem5.Text = "About &MyDeviceApp";
      this.menuItem5.Click += new System.EventHandler(this.menuItem5_Click);
      // 
      // menuItem6
      // 
      this.menuItem6.Text = "-";
      // 
      // menuItem7
      // 
      this.menuItem7.Text = "E&xit Program";
      this.menuItem7.Click += new System.EventHandler(this.menuItem7_Click);
      // 
      // menuItem8
      // 
      this.menuItem8.Text = "&SqlCeResultSet";
      this.menuItem8.Click += new System.EventHandler(this.menuItem8_Click);
      // 
      // menuItem9
      // 
      this.menuItem9.Text = "-";
      // 
      // frmMenu
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
      this.AutoScroll = true;
      this.ClientSize = new System.Drawing.Size(240, 268);
      this.Menu = this.mainMenu1;
      this.Name = "frmMenu";
      this.Text = "Menu";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.MenuItem menuItem1;
    private System.Windows.Forms.MenuItem menuItem2;
    private System.Windows.Forms.MenuItem menuItem3;
    private System.Windows.Forms.MenuItem menuItem4;
    private System.Windows.Forms.MenuItem menuItem5;
    private System.Windows.Forms.MenuItem menuItem6;
    private System.Windows.Forms.MenuItem menuItem7;
    private System.Windows.Forms.MenuItem menuItem8;
    private System.Windows.Forms.MenuItem menuItem9;
  }
}