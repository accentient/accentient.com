namespace MyDeviceApp
{
  partial class frmSqlCeResultSet
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;
    private System.Windows.Forms.MainMenu mainMenu1;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.mainMenu1 = new System.Windows.Forms.MainMenu();
      this.dataGrid1 = new System.Windows.Forms.DataGrid();
      this.webBrowser1 = new System.Windows.Forms.WebBrowser();
      this.button1 = new System.Windows.Forms.Button();
      this.button2 = new System.Windows.Forms.Button();
      this.button3 = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // dataGrid1
      // 
      this.dataGrid1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
      this.dataGrid1.Location = new System.Drawing.Point(0, 37);
      this.dataGrid1.Name = "dataGrid1";
      this.dataGrid1.Size = new System.Drawing.Size(243, 115);
      this.dataGrid1.TabIndex = 0;
      // 
      // webBrowser1
      // 
      this.webBrowser1.Location = new System.Drawing.Point(0, 159);
      this.webBrowser1.Name = "webBrowser1";
      this.webBrowser1.Size = new System.Drawing.Size(240, 87);
      // 
      // button1
      // 
      this.button1.Location = new System.Drawing.Point(4, 4);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(72, 20);
      this.button1.TabIndex = 2;
      this.button1.Text = "CE 2.0";
      this.button1.Click += new System.EventHandler(this.button1_Click);
      // 
      // button2
      // 
      this.button2.Location = new System.Drawing.Point(82, 4);
      this.button2.Name = "button2";
      this.button2.Size = new System.Drawing.Size(72, 20);
      this.button2.TabIndex = 3;
      this.button2.Text = "Reader";
      // 
      // button3
      // 
      this.button3.Location = new System.Drawing.Point(160, 4);
      this.button3.Name = "button3";
      this.button3.Size = new System.Drawing.Size(72, 20);
      this.button3.TabIndex = 4;
      this.button3.Text = "SqlCeRS";
      this.button3.Click += new System.EventHandler(this.button3_Click);
      // 
      // frmSqlCeResultSet
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
      this.AutoScroll = true;
      this.ClientSize = new System.Drawing.Size(240, 268);
      this.Controls.Add(this.button3);
      this.Controls.Add(this.button2);
      this.Controls.Add(this.button1);
      this.Controls.Add(this.webBrowser1);
      this.Controls.Add(this.dataGrid1);
      this.Menu = this.mainMenu1;
      this.Name = "frmSqlCeResultSet";
      this.Text = "frmSqlCeResultSet";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.DataGrid dataGrid1;
    private System.Windows.Forms.WebBrowser webBrowser1;
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.Button button3;
  }
}