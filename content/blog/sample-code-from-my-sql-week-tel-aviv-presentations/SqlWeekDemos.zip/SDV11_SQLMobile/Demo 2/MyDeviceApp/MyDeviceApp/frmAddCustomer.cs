using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlServerCe;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MyDeviceApp
{
  public partial class frmAddCustomer : Form
  {
    public frmAddCustomer()
    {
      InitializeComponent();
    }

    private void btnAdd_Click(object sender, EventArgs e)
    {
      string connStr = "Data Source ="
        + (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)
        + ("\\Sales.sdf;"
        + ("Password =" + "\"P@ssw0rd\";")));
      SqlCeConnection conn = new SqlCeConnection(connStr);
      conn.Open();
      SqlCeCommand cmd = conn.CreateCommand();
      cmd.CommandText = "INSERT Customer (Name) VALUES (@Name)";
      cmd.Parameters.AddWithValue("@Name", txtCustomer.Text);
      cmd.ExecuteNonQuery();
      conn.Close();
      this.Close();

    }
  }
}