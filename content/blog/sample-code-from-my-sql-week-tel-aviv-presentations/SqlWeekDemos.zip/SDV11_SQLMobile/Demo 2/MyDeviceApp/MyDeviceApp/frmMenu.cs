using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlServerCe;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MyDeviceApp
{
  public partial class frmMenu : Form
  {
    public frmMenu()
    {
      InitializeComponent();
    }

    private void menuItem7_Click(object sender, EventArgs e)
    {
      Application.Exit();
    }

    private void menuItem3_Click(object sender, EventArgs e)
    {
      frmCustomers newForm = new frmCustomers();
      newForm.Show();
    }

    private void menuItem2_Click(object sender, EventArgs e)
    {
      frmAddCustomer newForm = new frmAddCustomer();
      newForm.Show();
    }

    private void menuItem5_Click(object sender, EventArgs e)
    {
      string connStr = "Data Source ="
        + (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)
        + ("\\Sales.sdf;"
        + ("Password =" + "\"P@ssw0rd\";")));

      SqlCeEngine eng = new SqlCeEngine(connStr);
      MessageBox.Show(eng.LocalConnectionString);

      // Reclaim space in the database file
      eng.Shrink();
      MessageBox.Show("Shrink Complete!");

      // Recalculate the checksums of every page in the database file and verify that the checksums match their expected values. Call Repair if false!
      bool verify = eng.Verify();
      MessageBox.Show("Verify Complete: " + verify.ToString());

      if (!verify)
      {
        // Repair the database
        eng.Repair(connStr, RepairOption.RecoverCorruptedRows);
        MessageBox.Show("Repair Complete");

        // Recalculate the checksums of every page in the database file and verify that the checksums match their expected values. Call Repair if false!
        verify = eng.Verify();
        MessageBox.Show("Verify Complete: " + verify.ToString());
      }

      // Same as Shrink, but can change database settings
      // eng.Compact(connStr);
      // MessageBox.Show("Compact Complete!");

      SqlCeConnection conn = new SqlCeConnection(connStr);
      MessageBox.Show(conn.Database, "Database");
      MessageBox.Show(conn.ServerVersion, "ServerVersion");
      MessageBox.Show(conn.State.ToString(), "State");
      conn.Open();
      MessageBox.Show(conn.State.ToString(), "State");
      conn.Close();

    }

    private void menuItem8_Click(object sender, EventArgs e)
    {
      frmSqlCeResultSet newForm = new frmSqlCeResultSet();
      newForm.Show();
    }
  }
}