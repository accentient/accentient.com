USE AdventureWorks
GO

INSERT Production.ProductReview(
 ProductID,ReviewerName,ReviewDate,EmailAddress,Rating,Comments)
VALUES ('937','BillG',GetDate(),'billg@microsoft.com',5,
 'Very satisfied. These pedals are fantastic!')
