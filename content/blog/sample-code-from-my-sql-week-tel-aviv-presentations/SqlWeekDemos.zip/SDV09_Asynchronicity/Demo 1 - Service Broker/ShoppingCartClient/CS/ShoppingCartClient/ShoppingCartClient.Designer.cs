﻿namespace Microsoft.Samples.SqlServer
{
	partial class frmMain
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "System.Windows.Forms.Control.set_Text(System.String)")]
        private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabApplication = new System.Windows.Forms.TabPage();
            this.paneShop = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.nudQuantity = new System.Windows.Forms.NumericUpDown();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.lstItems = new System.Windows.Forms.ListBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtUnitPrice = new System.Windows.Forms.TextBox();
            this.cboItem = new System.Windows.Forms.ComboBox();
            this.paneFinish = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTotalAmount = new System.Windows.Forms.TextBox();
            this.txtNumberItems = new System.Windows.Forms.TextBox();
            this.paneData = new System.Windows.Forms.Panel();
            this.paneCreateOrder = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnCreateOrder = new System.Windows.Forms.Button();
            this.txtLabelFinish = new System.Windows.Forms.TextBox();
            this.txtLabelShop = new System.Windows.Forms.TextBox();
            this.txtLabelCreateOrder = new System.Windows.Forms.TextBox();
            this.tabTrace = new System.Windows.Forms.TabPage();
            this.txtLog = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtConversationHandle = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabControl.SuspendLayout();
            this.tabApplication.SuspendLayout();
            this.paneShop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).BeginInit();
            this.paneFinish.SuspendLayout();
            this.paneData.SuspendLayout();
            this.paneCreateOrder.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabTrace.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(377, 354);
            this.dataGridView1.TabIndex = 0;
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabApplication);
            this.tabControl.Controls.Add(this.tabTrace);
            this.tabControl.Location = new System.Drawing.Point(1, 3);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(505, 524);
            this.tabControl.TabIndex = 0;
            // 
            // tabApplication
            // 
            this.tabApplication.Controls.Add(this.paneShop);
            this.tabApplication.Controls.Add(this.paneFinish);
            this.tabApplication.Controls.Add(this.paneCreateOrder);
            this.tabApplication.Controls.Add(this.txtLabelFinish);
            this.tabApplication.Controls.Add(this.txtLabelShop);
            this.tabApplication.Controls.Add(this.txtLabelCreateOrder);
            this.tabApplication.Location = new System.Drawing.Point(4, 22);
            this.tabApplication.Name = "tabApplication";
            this.tabApplication.Padding = new System.Windows.Forms.Padding(3);
            this.tabApplication.Size = new System.Drawing.Size(497, 498);
            this.tabApplication.TabIndex = 0;
            this.tabApplication.Text = "Application";
            // 
            // paneShop
            // 
            this.paneShop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.paneShop.Controls.Add(this.label8);
            this.paneShop.Controls.Add(this.label7);
            this.paneShop.Controls.Add(this.label6);
            this.paneShop.Controls.Add(this.label5);
            this.paneShop.Controls.Add(this.nudQuantity);
            this.paneShop.Controls.Add(this.btnConfirm);
            this.paneShop.Controls.Add(this.btnRemove);
            this.paneShop.Controls.Add(this.lstItems);
            this.paneShop.Controls.Add(this.btnAdd);
            this.paneShop.Controls.Add(this.txtUnitPrice);
            this.paneShop.Controls.Add(this.cboItem);
            this.paneShop.Location = new System.Drawing.Point(93, 20);
            this.paneShop.Name = "paneShop";
            this.paneShop.Size = new System.Drawing.Size(397, 458);
            this.paneShop.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(54, 125);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(124, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "Items in the shopping cart";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(271, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "Quantity";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(205, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Unit price";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(54, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Item";
            // 
            // nudQuantity
            // 
            this.nudQuantity.Location = new System.Drawing.Point(271, 51);
            this.nudQuantity.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nudQuantity.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudQuantity.Name = "nudQuantity";
            this.nudQuantity.ReadOnly = true;
            this.nudQuantity.Size = new System.Drawing.Size(60, 20);
            this.nudQuantity.TabIndex = 13;
            this.nudQuantity.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnConfirm
            // 
            this.btnConfirm.Enabled = false;
            this.btnConfirm.Location = new System.Drawing.Point(156, 398);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(75, 23);
            this.btnConfirm.TabIndex = 6;
            this.btnConfirm.Text = "Confirm";
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Enabled = false;
            this.btnRemove.Location = new System.Drawing.Point(256, 326);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(75, 23);
            this.btnRemove.TabIndex = 5;
            this.btnRemove.Text = "Remove Item";
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // lstItems
            // 
            this.lstItems.FormattingEnabled = true;
            this.lstItems.Location = new System.Drawing.Point(54, 146);
            this.lstItems.Name = "lstItems";
            this.lstItems.Size = new System.Drawing.Size(279, 173);
            this.lstItems.TabIndex = 4;
            // 
            // btnAdd
            // 
            this.btnAdd.Enabled = false;
            this.btnAdd.Location = new System.Drawing.Point(256, 77);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 3;
            this.btnAdd.Text = "Add Item";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtUnitPrice
            // 
            this.txtUnitPrice.Location = new System.Drawing.Point(205, 51);
            this.txtUnitPrice.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.txtUnitPrice.Name = "txtUnitPrice";
            this.txtUnitPrice.ReadOnly = true;
            this.txtUnitPrice.Size = new System.Drawing.Size(59, 20);
            this.txtUnitPrice.TabIndex = 1;
            // 
            // cboItem
            // 
            this.cboItem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboItem.FormattingEnabled = true;
            this.cboItem.Location = new System.Drawing.Point(53, 50);
            this.cboItem.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.cboItem.Name = "cboItem";
            this.cboItem.Size = new System.Drawing.Size(148, 21);
            this.cboItem.TabIndex = 0;
            this.cboItem.SelectedIndexChanged += new System.EventHandler(this.cboItem_SelectedIndexChanged);
            // 
            // paneFinish
            // 
            this.paneFinish.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.paneFinish.Controls.Add(this.label3);
            this.paneFinish.Controls.Add(this.label2);
            this.paneFinish.Controls.Add(this.label1);
            this.paneFinish.Controls.Add(this.txtTotalAmount);
            this.paneFinish.Controls.Add(this.txtNumberItems);
            this.paneFinish.Controls.Add(this.paneData);
            this.paneFinish.Location = new System.Drawing.Point(93, 20);
            this.paneFinish.Name = "paneFinish";
            this.paneFinish.Size = new System.Drawing.Size(397, 458);
            this.paneFinish.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Invoice";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(209, 425);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Total amount:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(192, 398);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Number of Items:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtTotalAmount
            // 
            this.txtTotalAmount.Location = new System.Drawing.Point(288, 422);
            this.txtTotalAmount.Margin = new System.Windows.Forms.Padding(1, 3, 3, 3);
            this.txtTotalAmount.Name = "txtTotalAmount";
            this.txtTotalAmount.Size = new System.Drawing.Size(97, 20);
            this.txtTotalAmount.TabIndex = 3;
            // 
            // txtNumberItems
            // 
            this.txtNumberItems.Location = new System.Drawing.Point(288, 395);
            this.txtNumberItems.Margin = new System.Windows.Forms.Padding(2, 3, 3, 3);
            this.txtNumberItems.Name = "txtNumberItems";
            this.txtNumberItems.Size = new System.Drawing.Size(98, 20);
            this.txtNumberItems.TabIndex = 2;
            // 
            // paneData
            // 
            this.paneData.Controls.Add(this.dataGridView1);
            this.paneData.Location = new System.Drawing.Point(9, 34);
            this.paneData.Name = "paneData";
            this.paneData.Size = new System.Drawing.Size(377, 354);
            this.paneData.TabIndex = 0;
            // 
            // paneCreateOrder
            // 
            this.paneCreateOrder.BackColor = System.Drawing.SystemColors.Window;
            this.paneCreateOrder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.paneCreateOrder.Controls.Add(this.pictureBox1);
            this.paneCreateOrder.Controls.Add(this.textBox1);
            this.paneCreateOrder.Controls.Add(this.label4);
            this.paneCreateOrder.Controls.Add(this.btnCreateOrder);
            this.paneCreateOrder.Location = new System.Drawing.Point(93, 20);
            this.paneCreateOrder.Name = "paneCreateOrder";
            this.paneCreateOrder.Size = new System.Drawing.Size(397, 458);
            this.paneCreateOrder.TabIndex = 6;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = Properties.Resources.imgShoppingCart;
            this.pictureBox1.ImageLocation = "";
            this.pictureBox1.InitialImage = Properties.Resources.imgShoppingCart;
            this.pictureBox1.Location = new System.Drawing.Point(102, 45);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(202, 225);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.AutoSize = false;
            this.textBox1.BackColor = System.Drawing.SystemColors.Window;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Location = new System.Drawing.Point(33, 293);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(333, 115);
            this.textBox1.TabIndex = 3;
            this.textBox1.Text = resources.GetString("textBox1.Text");
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(115, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(177, 24);
            this.label4.TabIndex = 2;
            this.label4.Text = "Shopping Cart Client";
            // 
            // btnCreateOrder
            // 
            this.btnCreateOrder.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnCreateOrder.Location = new System.Drawing.Point(156, 414);
            this.btnCreateOrder.Name = "btnCreateOrder";
            this.btnCreateOrder.Size = new System.Drawing.Size(75, 23);
            this.btnCreateOrder.TabIndex = 0;
            this.btnCreateOrder.Text = "Create Order";
            this.btnCreateOrder.UseVisualStyleBackColor = false;
            this.btnCreateOrder.Click += new System.EventHandler(this.btnCreateOrder_Click);
            // 
            // txtLabelFinish
            // 
            this.txtLabelFinish.AutoSize = false;
            this.txtLabelFinish.BackColor = System.Drawing.Color.LightSteelBlue;
            this.txtLabelFinish.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLabelFinish.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLabelFinish.ForeColor = System.Drawing.Color.White;
            this.txtLabelFinish.Location = new System.Drawing.Point(7, 120);
            this.txtLabelFinish.Multiline = true;
            this.txtLabelFinish.Name = "txtLabelFinish";
            this.txtLabelFinish.ReadOnly = true;
            this.txtLabelFinish.Size = new System.Drawing.Size(87, 32);
            this.txtLabelFinish.TabIndex = 9;
            this.txtLabelFinish.Text = "Finish";
            // 
            // txtLabelShop
            // 
            this.txtLabelShop.AutoSize = false;
            this.txtLabelShop.BackColor = System.Drawing.Color.LightSteelBlue;
            this.txtLabelShop.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLabelShop.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLabelShop.ForeColor = System.Drawing.Color.White;
            this.txtLabelShop.Location = new System.Drawing.Point(7, 79);
            this.txtLabelShop.Multiline = true;
            this.txtLabelShop.Name = "txtLabelShop";
            this.txtLabelShop.ReadOnly = true;
            this.txtLabelShop.Size = new System.Drawing.Size(87, 32);
            this.txtLabelShop.TabIndex = 8;
            this.txtLabelShop.Text = "Shop";
            // 
            // txtLabelCreateOrder
            // 
            this.txtLabelCreateOrder.AutoSize = false;
            this.txtLabelCreateOrder.BackColor = System.Drawing.Color.RoyalBlue;
            this.txtLabelCreateOrder.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLabelCreateOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLabelCreateOrder.ForeColor = System.Drawing.Color.White;
            this.txtLabelCreateOrder.Location = new System.Drawing.Point(7, 20);
            this.txtLabelCreateOrder.Multiline = true;
            this.txtLabelCreateOrder.Name = "txtLabelCreateOrder";
            this.txtLabelCreateOrder.ReadOnly = true;
            this.txtLabelCreateOrder.Size = new System.Drawing.Size(87, 52);
            this.txtLabelCreateOrder.TabIndex = 7;
            this.txtLabelCreateOrder.Text = "Create Order";
            // 
            // tabTrace
            // 
            this.tabTrace.Controls.Add(this.txtLog);
            this.tabTrace.Controls.Add(this.label10);
            this.tabTrace.Controls.Add(this.label9);
            this.tabTrace.Controls.Add(this.txtConversationHandle);
            this.tabTrace.Location = new System.Drawing.Point(4, 22);
            this.tabTrace.Name = "tabTrace";
            this.tabTrace.Padding = new System.Windows.Forms.Padding(3);
            this.tabTrace.Size = new System.Drawing.Size(497, 498);
            this.tabTrace.TabIndex = 1;
            this.tabTrace.Text = "Service Broker Trace";
            // 
            // txtLog
            // 
            this.txtLog.AutoSize = false;
            this.txtLog.Location = new System.Drawing.Point(8, 66);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ReadOnly = true;
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLog.Size = new System.Drawing.Size(483, 426);
            this.txtLog.TabIndex = 17;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 45);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(227, 13);
            this.label10.TabIndex = 16;
            this.label10.Text = "Messages sent or received on the conversation";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(87, 16);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 13);
            this.label9.TabIndex = 15;
            this.label9.Text = "Conversation Handle:";
            // 
            // txtConversationHandle
            // 
            this.txtConversationHandle.AutoSize = false;
            this.txtConversationHandle.Location = new System.Drawing.Point(207, 13);
            this.txtConversationHandle.Multiline = true;
            this.txtConversationHandle.Name = "txtConversationHandle";
            this.txtConversationHandle.ReadOnly = true;
            this.txtConversationHandle.Size = new System.Drawing.Size(279, 21);
            this.txtConversationHandle.TabIndex = 12;
            // 
            // frmMain
            // 
            this.ClientSize = new System.Drawing.Size(504, 526);
            this.Controls.Add(this.tabControl);
            this.Name = "frmMain";
            this.Text = "Shopping Cart Client Sample";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmMain_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabControl.ResumeLayout(false);
            this.tabApplication.ResumeLayout(false);
            this.paneShop.ResumeLayout(false);
            this.paneShop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).EndInit();
            this.paneFinish.ResumeLayout(false);
            this.paneFinish.PerformLayout();
            this.paneData.ResumeLayout(false);
            this.paneCreateOrder.ResumeLayout(false);
            this.paneCreateOrder.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabTrace.ResumeLayout(false);
            this.tabTrace.PerformLayout();
            this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.DataGridView dataGridView1;
		private System.Windows.Forms.TabControl tabControl;
		private System.Windows.Forms.TabPage tabApplication;
		private System.Windows.Forms.TextBox txtLabelFinish;
		private System.Windows.Forms.TextBox txtLabelShop;
		private System.Windows.Forms.TextBox txtLabelCreateOrder;
		private System.Windows.Forms.Panel paneCreateOrder;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button btnCreateOrder;
		private System.Windows.Forms.Panel paneShop;
		private System.Windows.Forms.NumericUpDown nudQuantity;
		private System.Windows.Forms.Button btnConfirm;
		private System.Windows.Forms.Button btnRemove;
		private System.Windows.Forms.ListBox lstItems;
		private System.Windows.Forms.Button btnAdd;
		private System.Windows.Forms.TextBox txtUnitPrice;
		private System.Windows.Forms.ComboBox cboItem;
		private System.Windows.Forms.Panel paneFinish;
		private System.Windows.Forms.TextBox txtTotalAmount;
		private System.Windows.Forms.TextBox txtNumberItems;
		private System.Windows.Forms.Panel paneData;
		private System.Windows.Forms.TabPage tabTrace;
		private System.Windows.Forms.TextBox txtConversationHandle;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox txtLog;






	}
}

