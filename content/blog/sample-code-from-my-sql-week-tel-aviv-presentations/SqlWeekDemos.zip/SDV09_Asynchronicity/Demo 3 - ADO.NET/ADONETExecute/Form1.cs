using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ADONETExecute
{
  public partial class Form1 : Form
  {

    private SqlCommand cmd = null;

    public Form1()
    {
      InitializeComponent();
    }

    private delegate void UICallback(object param);

    private void ReBindOnUIThread(object param)
    {
      if (param is DataTable)
      {
        grdDemo.DataSource = param;
        cmd = null;
        lblInfo.Text = "Ready";
      }
      else
        lblInfo.Text = "Ready (last failed: " +
          ((Exception)param).Message + ")";
    }

    private void ExecCallback(IAsyncResult ar)
    {
      using (SqlDataReader reader = cmd.EndExecuteReader(ar))
      {
        try
        {
          DataTable tbl = new DataTable();
          tbl.Load(reader);
          this.Invoke(new UICallback(ReBindOnUIThread),
            new Object[] { tbl });
        }
        catch (Exception ex)
        {
          this.Invoke(new UICallback(ReBindOnUIThread),
            new Object[] { ex });
        }
      }
    }

    private void btnExecuteSynch_Click(object sender, EventArgs e)
    {
      SqlConnection cnn = null;
      try
      {
        lblInfo.Text = "Connecting...";
        cnn = new SqlConnection("Server=(local);Database=AdventureWorks;Integrated Security=SSPI;");
        cnn.Open();

        lblInfo.Text = "Executing...";
        cmd = new SqlCommand(txtSQL.Text, cnn);
        DataTable dt = new DataTable();
        SqlDataReader reader =
         cmd.ExecuteReader(CommandBehavior.CloseConnection);
        dt.Load(reader);

        // dt.CreateDataReader(); WTF?

        reader.Close();
        this.grdDemo.DataSource = dt;
        lblInfo.Text = "Ready";
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }

    private void btnExecuteHourglass_Click(object sender, EventArgs e)
    {
      this.Cursor = Cursors.WaitCursor;
      SqlConnection cnn = null;
      try
      {
        lblInfo.Text = "Connecting...";
        cnn = new SqlConnection("Server=(local);Database=AdventureWorks;Integrated Security=true;");
        cnn.Open();

        lblInfo.Text = "Executing...";
        cmd = new SqlCommand(txtSQL.Text, cnn);
        DataTable dt = new DataTable();
        SqlDataReader reader =
         cmd.ExecuteReader(CommandBehavior.CloseConnection);
        dt.Load(reader);
        reader.Close();
        this.grdDemo.DataSource = dt;
        lblInfo.Text = "Ready";
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        this.Cursor = Cursors.Default;
      }
    }

    private void btnExecuteAsync_Click(object sender, EventArgs e)
    {
      SqlConnection cnn = null;

      try
      {
        lblInfo.Text = "Connecting...";
        cnn = new SqlConnection("Server=(local);Database=AdventureWorks;Integrated Security=true;Asynchronous Processing=true");
        cnn.Open();
        cmd = new SqlCommand(txtSQL.Text, cnn);

        lblInfo.Text = "Executing...";
        cmd.BeginExecuteReader(
          new AsyncCallback(ExecCallback), null,
          CommandBehavior.CloseConnection);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
        cmd = null;
        if (cnn != null)
        {
          cnn.Close();
        }
      }
    }

    private void btnClear_Click(object sender, EventArgs e)
    {
      grdDemo.DataSource = null;
    }
  }
}