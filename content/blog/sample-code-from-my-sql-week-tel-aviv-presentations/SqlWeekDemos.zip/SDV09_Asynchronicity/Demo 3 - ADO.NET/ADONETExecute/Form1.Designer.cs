namespace ADONETExecute
{
  partial class Form1
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.btnClear = new System.Windows.Forms.Button();
      this.btnExecuteAsync = new System.Windows.Forms.Button();
      this.btnExecuteHourglass = new System.Windows.Forms.Button();
      this.lblInfo = new System.Windows.Forms.Label();
      this.btnExecuteSynch = new System.Windows.Forms.Button();
      this.grdDemo = new System.Windows.Forms.DataGridView();
      this.txtSQL = new System.Windows.Forms.TextBox();
      ((System.ComponentModel.ISupportInitialize)(this.grdDemo)).BeginInit();
      this.SuspendLayout();
      // 
      // btnClear
      // 
      this.btnClear.Location = new System.Drawing.Point(613, 7);
      this.btnClear.Name = "btnClear";
      this.btnClear.Size = new System.Drawing.Size(75, 23);
      this.btnClear.TabIndex = 13;
      this.btnClear.Text = "Clear";
      this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
      // 
      // btnExecuteAsync
      // 
      this.btnExecuteAsync.Location = new System.Drawing.Point(532, 7);
      this.btnExecuteAsync.Name = "btnExecuteAsync";
      this.btnExecuteAsync.Size = new System.Drawing.Size(75, 23);
      this.btnExecuteAsync.TabIndex = 12;
      this.btnExecuteAsync.Text = "Async";
      this.btnExecuteAsync.Click += new System.EventHandler(this.btnExecuteAsync_Click);
      // 
      // btnExecuteHourglass
      // 
      this.btnExecuteHourglass.Location = new System.Drawing.Point(451, 7);
      this.btnExecuteHourglass.Name = "btnExecuteHourglass";
      this.btnExecuteHourglass.Size = new System.Drawing.Size(75, 23);
      this.btnExecuteHourglass.TabIndex = 11;
      this.btnExecuteHourglass.Text = "Hourglass";
      this.btnExecuteHourglass.Click += new System.EventHandler(this.btnExecuteHourglass_Click);
      // 
      // lblInfo
      // 
      this.lblInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.lblInfo.AutoSize = true;
      this.lblInfo.Location = new System.Drawing.Point(12, 260);
      this.lblInfo.Name = "lblInfo";
      this.lblInfo.Size = new System.Drawing.Size(38, 13);
      this.lblInfo.TabIndex = 10;
      this.lblInfo.Text = "Ready";
      // 
      // btnExecuteSynch
      // 
      this.btnExecuteSynch.Location = new System.Drawing.Point(370, 7);
      this.btnExecuteSynch.Name = "btnExecuteSynch";
      this.btnExecuteSynch.Size = new System.Drawing.Size(75, 23);
      this.btnExecuteSynch.TabIndex = 9;
      this.btnExecuteSynch.Text = "Execute";
      this.btnExecuteSynch.Click += new System.EventHandler(this.btnExecuteSynch_Click);
      // 
      // grdDemo
      // 
      this.grdDemo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.grdDemo.Location = new System.Drawing.Point(12, 39);
      this.grdDemo.Name = "grdDemo";
      this.grdDemo.Size = new System.Drawing.Size(675, 218);
      this.grdDemo.TabIndex = 8;
      // 
      // txtSQL
      // 
      this.txtSQL.Location = new System.Drawing.Point(11, 10);
      this.txtSQL.Name = "txtSQL";
      this.txtSQL.Size = new System.Drawing.Size(353, 20);
      this.txtSQL.TabIndex = 7;
      this.txtSQL.Text = "WAITFOR DELAY \'00:00:05\'; SELECT * FROM Person.Contact";
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(698, 275);
      this.Controls.Add(this.btnClear);
      this.Controls.Add(this.btnExecuteAsync);
      this.Controls.Add(this.btnExecuteHourglass);
      this.Controls.Add(this.lblInfo);
      this.Controls.Add(this.btnExecuteSynch);
      this.Controls.Add(this.grdDemo);
      this.Controls.Add(this.txtSQL);
      this.Name = "Form1";
      this.Text = "Form1";
      ((System.ComponentModel.ISupportInitialize)(this.grdDemo)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button btnClear;
    private System.Windows.Forms.Button btnExecuteAsync;
    private System.Windows.Forms.Button btnExecuteHourglass;
    private System.Windows.Forms.Label lblInfo;
    private System.Windows.Forms.Button btnExecuteSynch;
    private System.Windows.Forms.DataGridView grdDemo;
    private System.Windows.Forms.TextBox txtSQL;
  }
}