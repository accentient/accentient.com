using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LongRunning
{
    public partial class Form1 : Form
    {

        SqlConnection conNW;

        public Form1()
        {
            InitializeComponent();
        }

        void conNW_InfoMessage(object sender, SqlInfoMessageEventArgs e)
        {
            int progress;
            if (int.TryParse(e.Message,out progress))
            {
                progressBar1.Value = progress;
            }
            toolStripStatusLabel1.Text = e.Message;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Mouse pointer

            this.Cursor = Cursors.WaitCursor;

            // Reset

            progressBar1.Value = 0;
            toolStripStatusLabel1.Text = "";

            // Connect to database

            conNW = new SqlConnection();
            conNW.FireInfoMessageEventOnUserErrors = true;

            // conNW.FireInfoMessageEventOnUserErrors = true;
            conNW.InfoMessage += new SqlInfoMessageEventHandler(conNW_InfoMessage);
            conNW.ConnectionString = "server=(local);database=AdventureWorks;integrated security=SSPI";
            conNW.Open();

            // Execute sproc

            SqlCommand cmdNW = conNW.CreateCommand();
            cmdNW.CommandText = "spLongRunning";
            cmdNW.CommandType = CommandType.StoredProcedure;
            cmdNW.ExecuteNonQuery();

            // Done

            progressBar1.Value = 100;
            this.Cursor = Cursors.Default;
        }
    }
}