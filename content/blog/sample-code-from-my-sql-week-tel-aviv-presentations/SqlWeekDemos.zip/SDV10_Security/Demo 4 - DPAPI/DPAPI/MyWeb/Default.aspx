﻿<%@ Page Language="C#" AutoEventWireup="true"  CodeFile="Default.aspx.cs" Inherits="_Default" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        Please enter some data to encrypt:<br />
        <asp:TextBox ID="txtPlainText" runat="server" Width="600px"></asp:TextBox>
        <asp:Button ID="btnEncrypt" runat="server" OnClick="btnEncrypt_Click" Text="Encrypt" /><br />
        <br />
        Here is the encrypted data:<br />
        &nbsp;<asp:TextBox ID="txtEncrypted" runat="server" Width="600px"></asp:TextBox>
        <asp:Button
            ID="btnDecrypt" runat="server" Text="Decrypt" OnClick="btnDecrypt_Click" /><br />
        <br />
        and here's the decrypted data again:<br />
        &nbsp;<asp:TextBox ID="txtDecrypted" runat="server" Width="600px"></asp:TextBox></div>
    </form>
</body>
</html>
