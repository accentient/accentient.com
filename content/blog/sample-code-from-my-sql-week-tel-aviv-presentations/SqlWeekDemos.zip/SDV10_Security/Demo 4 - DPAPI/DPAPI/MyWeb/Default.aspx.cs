using System;
using System.Configuration;
using System.Data;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using DataProtection;

public partial class _Default : System.Web.UI.Page 
{

  protected void btnEncrypt_Click(object sender, EventArgs e)
  {
    DataProtector dp = new DataProtector(DataProtector.Store.USE_MACHINE_STORE);
    byte[] dataToEncrypt = Encoding.ASCII.GetBytes(txtPlainText.Text);
    txtEncrypted.Text = Convert.ToBase64String(dp.Encrypt(dataToEncrypt, null));
  }

  protected void btnDecrypt_Click(object sender, EventArgs e)
  {
    DataProtector dp = new DataProtector(DataProtector.Store.USE_MACHINE_STORE);
    byte[] dataToDecrypt = Convert.FromBase64String(txtEncrypted.Text);
    txtDecrypted.Text = Encoding.ASCII.GetString(dp.Decrypt(dataToDecrypt, null));
  }

}
