using System;
using System.Data;
using System.Data.SqlClient;

namespace ChangePassword
{
    class Program
    {
        static void Main(string[] args)
        {
            // Change password

            string strConn = "server=(local);database=Master;user id=Elvis;password=J345#thb";
            //SqlConnection.ChangePassword(strConn, "J345#)abc");
            //strConn = "server=(local);database=Master;user id=Elvis;password=J345#)abc";
            
            SqlConnection conSQL2005 = new SqlConnection();
            conSQL2005.ConnectionString = strConn;
            conSQL2005.Open();

            Console.WriteLine("Connected!");
            Console.ReadLine();
        }
    }
}
