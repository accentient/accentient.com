Imports System.Reflection
Imports System.IO

Public Class frmReflection

  Private Sub Log(ByVal msg As String)
    TextBox1.AppendText(msg & ControlChars.CrLf)
  End Sub

  Private Sub TallyByType(ByVal sAssemblyName As String, ByVal myType As Type)

    Dim MyMemberInfoArray As MemberInfo() = myType.GetMembers()
    Dim MyMemberInfo As MemberInfo

    Dim numConstructor As Int32
    Dim numCustom As Int32
    Dim numEvent As Int32
    Dim numField As Int32
    Dim numMethod As Int32
    Dim numNestedType As Int32
    Dim numProperty As Int32
    Dim numTypeInfo As Int32

    ' Walk through all of its members

    For Each MyMemberInfo In MyMemberInfoArray
      Select Case MyMemberInfo.MemberType.ToString()
        Case "Constructor"
          numConstructor = numConstructor + 1
        Case "Field"
          numField = numField + 1
        Case "Method"
          numMethod = numMethod + 1
        Case "Property"
          numProperty = numProperty + 1
        Case "Event"
          numEvent = numEvent + 1
        Case "NestedType"
          numNestedType = numNestedType + 1
        Case Else
          Log("   !" & MyMemberInfo.MemberType.ToString() & _
          ControlChars.Tab & MyMemberInfo.Name & " declaring type - " + MyMemberInfo.DeclaringType.ToString())
      End Select
    Next MyMemberInfo

    ' Display Sub Totals

    Log(sAssemblyName + "," + myType.Name + "," _
                + numConstructor.ToString() + "," _
                + numMethod.ToString() + "," _
                + numProperty.ToString() + "," _
                + numEvent.ToString() + "," _
                + numField.ToString() + "," _
                + numTypeInfo.ToString() + "," _
                + numNestedType.ToString() + "," _
                + numCustom.ToString())
  End Sub

  Private Sub ReflectAssembly(ByVal ASM As String, ByVal showHeading As Boolean)

    Dim MyAssembly As [Assembly]
    Dim myTypes() As Type = Nothing
    Dim myType As Type

    Try
      If showHeading Then
        Log("")
        Log("Assembly,Type,Constructors,Methods,Properties,Events,Fields,Type Info,Nested Types,Custom")
      End If
      MyAssembly = [Assembly].LoadFrom(ASM)
      myTypes = MyAssembly.GetExportedTypes()
    Catch
    End Try

    ' Anything found?

    If Not myTypes Is Nothing AndAlso myTypes.Length > 0 Then
      Log(ASM)
      For Each myType In myTypes
        TallyByType(ASM, myType)
      Next
    End If
  End Sub

  Private Sub ReflectAssemblies(ByVal PTH As String)
    Log("")
    Log("Assembly,Type,Constructors,Methods,Properties,Events,Fields,Type Info,Nested Types,Custom")
    Dim Files() As String = System.IO.Directory.GetFiles(PTH, "*.DLL")
    For Each F As String In Files
      ReflectAssembly(F, False)
    Next
  End Sub

  Private Sub btnReflect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReflect.Click
    TextBox1.Clear()
    ReflectAssembly("C:\Program Files\Microsoft SQL Server\90\SDK\Assemblies\Microsoft.SqlServer.Smo.dll", True)
    ReflectAssembly("C:\Program Files\Microsoft SQL Server\90\SDK\Assemblies\Microsoft.SqlServer.SmoEnum.dll", True)
    ReflectAssembly("C:\Program Files\Microsoft SQL Server\90\SDK\Assemblies\Microsoft.SqlServer.ConnectionInfo.dll", True)
    ' ReflectAssemblies("C:\WINDOWS\Microsoft.NET\Framework\v2.0.50727")
  End Sub

End Class
