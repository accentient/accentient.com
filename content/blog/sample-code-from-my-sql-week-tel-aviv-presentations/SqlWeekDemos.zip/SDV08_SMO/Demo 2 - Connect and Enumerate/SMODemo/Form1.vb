Imports Microsoft.SqlServer.Management.Smo

Public Class Form1

  Private Sub Log(ByVal Msg As String)
    txtOutput.AppendText(Msg & vbCrLf)
  End Sub

  Private Sub ListDatabases(ByVal SRV As Server)
    Log("")
    For Each DB As Database In SRV.Databases
      Log(DB.Name)
    Next
  End Sub

  ' Click event

  Private Sub btnTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest.Click

    ' Connect and basics

    Dim SRV As New Server(Environment.MachineName)
    Log(SRV.Name)
    Log(SRV.Information.Edition)
    Log(SRV.Information.VersionString)
    Log(SRV.Information.OSVersion)
    Log(SRV.Information.Platform)

    ' List Databases

    Log("")
    Log(SRV.Databases.Count & " Databases")
    ListDatabases(SRV)

    ' Create a Database

    Log("")
    Log("Creating Database")
    Try
      Dim newDB As Database
      newDB = New Database(SRV, "SQLWeek")
      newDB.Create()
    Catch Ex As Exception
      MessageBox.Show(Ex.Message, "Error")
    End Try
    ListDatabases(SRV)

    ' Drop Database

    SRV.Databases("SQLWeek").Drop()
  End Sub

End Class
