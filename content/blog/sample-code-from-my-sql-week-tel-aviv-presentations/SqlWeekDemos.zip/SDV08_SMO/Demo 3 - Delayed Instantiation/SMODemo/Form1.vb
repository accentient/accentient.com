Imports Microsoft.SqlServer.Management.Smo

Public Class Form1

  Private Sub Log(ByVal Msg As String)
    txtOutput.AppendText(Msg & vbCrLf)
  End Sub

  Private Sub ListDatabases(ByVal SRV As Server)
    Log("")
    For Each DB As Database In SRV.Databases
      Log(DB.Name)
    Next
  End Sub

  ' Click event

  Private Sub btnTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest.Click

    ' Connect and basics

    Dim SRV As New Server(Environment.MachineName)
    Log(SRV.Name)

    ' Request table properties

    Dim DB As Database = SRV.Databases("AdventureWorks")
    Dim TBL As Table = DB.Tables.Item("Contact", "Person")
    Log("")
    Log(TBL.Name) ' lightweight property
    Log(TBL.Schema) ' lightweight property
    Log(TBL.CreateDate) ' must fully instantiate first
    Log(TBL.DataSpaceUsed) ' expensive property
    Log(DB.Size) ' expensive property

    ' Force the properties be loaded. 

    Log(DB.Initialize(True))

  End Sub

End Class
