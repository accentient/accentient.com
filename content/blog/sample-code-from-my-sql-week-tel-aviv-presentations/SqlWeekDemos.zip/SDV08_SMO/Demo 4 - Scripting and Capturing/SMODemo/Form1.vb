Imports Microsoft.SqlServer.Management.Smo

Public Class Form1

  Private Sub Log(ByVal Msg As String)
    txtOutput.AppendText(Msg & vbCrLf)
  End Sub

  Private Sub ListDatabases(ByVal SRV As Server)
    Log("")
    For Each DB As Database In SRV.Databases
      Log(DB.Name)
    Next
  End Sub

  ' Click event

  Private Sub btnTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest.Click

    ' Connect and basics

    Dim SRV As New Server(Environment.MachineName)
    Log(SRV.Name)

    ''''''''''''''''''''''''''''''''''''''''''''''
    ' Scripter

    Dim SCR As New Scripter(SRV)
    SCR.Options.FileName = "c:\demo\script.txt"
    SCR.Options.AppendToFile = True
    SCR.Options.IncludeHeaders = True
    SCR.Options.ScriptDrops = True

    ' Add a couple of SMO objects to an array

    Dim SMOObjs(0) As SqlSmoObject
    SMOObjs(0) = SRV.Databases("AdventureWorks").Tables("Contact", "Person")
    SMOObjs(0) = SRV.Databases("AdventureWorks").Tables("Employee", "HumanResources")

    ' Script it!

    SCR.Script(SMOObjs)
    Log("Scripting complete")

    '''''''''''''''''''''''''''''''''''''''''''''''
    '' Capture Mode (Similar to SSMS)

    'Dim CON As Microsoft.SqlServer.Management.Common.ServerConnection = SRV.ConnectionContext

    'CON.ServerInstance = Environment.MachineName
    'CON.SqlExecutionModes = Microsoft.SqlServer.Management.Common.SqlExecutionModes.ExecuteAndCaptureSql

    'CON.Connect()

    'Log("")
    'Log("Executing:")
    'Log(CON.ExecuteScalar("SELECT @@Version"))

    'Log("")
    'Log("Captured:")
    'For Each S As String In CON.CapturedSql.Text
    '  Log(S)
    'Next
    'CON.Disconnect()

  End Sub

End Class
