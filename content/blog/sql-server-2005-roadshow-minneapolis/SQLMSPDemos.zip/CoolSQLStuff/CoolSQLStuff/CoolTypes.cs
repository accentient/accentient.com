using System;
using System.Data;
using System.Data.Sql;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

[Serializable]
[Microsoft.SqlServer.Server.SqlUserDefinedType(Format.Native)]
[System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]

public class DMS : INullable
{
	private Int16 dd, mm, ss;
	private bool bIsNull = true;

	public Int16 DD
	{
		get { return dd; }
		set { dd = value; }
	}

	public Int16 MM
	{
		get { return mm; }
		set { mm = value; }
	}

	public Int16 SS
	{
		get { return ss; }
		set { ss = value; }
	}

	public override string ToString()
	{
		if (bIsNull)
			return "null";
		else
			return String.Format("{0}�{1}'{2}", dd, mm, ss);
	}

	public bool IsNull
	{
		get
		{
			return bIsNull;
		}
	}

	public static DMS Null
	{
		get
		{
			DMS dms = new DMS();
			return dms;
		}
	}

	public static DMS Parse(SqlString s)
	{
		if (s.IsNull || s.Value.ToLower().Equals("null"))
			return null;
		DMS dms = new DMS();
		string[] st = s.Value.Split('.');
		dms.DD = Int16.Parse(st[0]);
		dms.MM = Int16.Parse(st[1]);
		dms.SS = Int16.Parse(st[2]);
		dms.bIsNull = false;
		return dms;
	}
}