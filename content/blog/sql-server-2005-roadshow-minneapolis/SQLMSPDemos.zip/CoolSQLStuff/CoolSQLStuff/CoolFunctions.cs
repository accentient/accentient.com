using System.Data;
using System.Data.Sql;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

public partial class CoolFunctions
{
	[Microsoft.SqlServer.Server.SqlFunction]
	public static SqlString CoolEncrypt(SqlString Data)
	{
		char[] strArray = Data.ToString().ToCharArray();
		System.Array.Reverse(strArray);
		return new string(strArray);
	}

};