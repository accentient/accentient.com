' Constants

Const LDAP        = "WinNT://vsts,computer"
Const PASSWORD    = "P@ssw0rd"
Const NEVEREXPIRE = &h10000

' Set Instance

Set objComputer = GetObject(LDAP)

' Create Group(s)

CreateGroup "TFS Administrators","Users who will be managing TFS"

' Create Account(s)

CreateUser "TFSSERVICE","TFS Service Account"
CreateUser "TFSREPORTS","TFS Reporting Account"
CreateUser "TFSBUILD","TFS Build Service Account"
CreateUser "WSSSERVICE","WSS Service Account"

' Set User Rights

Set oShell = WScript.CreateObject("WScript.Shell")
oShell.Run "%comspec% /c ntrights.exe /? > tfsaccounts.log", 1, True
oShell.Run "%comspec% /c ntrights.exe -u TFSREPORTS +r SeInteractiveLogonRight >> tfsaccounts.log", 1, True
oShell.Run "%comspec% /c ntrights.exe -u TFSSERVICE +r SeServiceLogonRight >> tfsaccounts.log", 1, True
oShell.Run "%comspec% /c ntrights.exe -u TFSBUILD +r SeServiceLogonRight >> tfsaccounts.log", 1, True

' Done

msgbox "TFS Service Accounts created"
Wscript.quit

' Subroutines

sub CreateUser (User,Description)

  ' Drop first

  on error resume next
  objComputer.Delete "User",User
  on error goto 0

  ' Add User

  set objUser = objComputer.Create("User",User)
  objUser.SetInfo
  objUser.FullName = Description
  objUser.Description = Description
  objUser.SetPassword PASSWORD

  ' Set Password so it doesn't expire

  lngUF = objUser.Get("userFlags")
  lngUF = lngUF Or NEVEREXPIRE
  objUser.Put "userFlags", lngUF

  ' Activate the above settings
  
  objUser.SetInfo

End Sub

sub CreateGroup (Group,Description)

  ' Drop

  on error resume next
  objComputer.Delete "Group",Group
  on error goto 0

  ' Create

  set objGroup = objComputer.Create("Group",Group)
  objGroup.SetInfo
  objGroup.Description = Description
  objGroup.SetInfo
End Sub
