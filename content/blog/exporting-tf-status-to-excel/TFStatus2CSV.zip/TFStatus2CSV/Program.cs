﻿using System;
using System.IO;

namespace TFStatus2CSV
{
  class Program
  {
    const string DEL = "!";

    public struct ItemStruct
    {
      public string ItemSpec, User, Lock, Change, Workspace, LocalItem, FileType;
      public DateTime Date;
    }

    static void Convert2CSV()
    {
      string line;
      ItemStruct item = new ItemStruct();

      StreamWriter SW = new StreamWriter(@"C:\Status\Detailed.csv");
      SW.WriteLine("Item" + DEL + "User" + DEL + "Date" + DEL + "Lock" + DEL + "Change" + DEL + "Workspace" + DEL + "Local" + DEL + "FileType");

      StreamReader SR = new StreamReader(@"C:\Status\Detailed.txt");
      while ((line = SR.ReadLine()) != null)
      {
        line = line.Trim();
        if (line != "" && line != null)
        {
          if (line.Substring(0, 1) == "$")
          {
            if (item.ItemSpec != null && item.ItemSpec != "")
            {
              SW.WriteLine(item.ItemSpec + "" + DEL + "" + item.User + "" + DEL + "" + item.Date + "" + DEL + "" + item.Lock + "" + DEL + "" + item.Change + "" + DEL + "" + item.Workspace + "" + DEL + "" + item.LocalItem + "" + DEL + "" + item.FileType);
            }
            item = new ItemStruct();
            item.ItemSpec = line;
          }
          else if (line.Substring(0, 12) == "User       :")
          {
            item.User = line.Replace("User       :", "").Trim();
          }
          else if (line.Substring(0, 12) == "Date       :")
          {
            string rawDate = line.Replace("Date       :", "").Trim();
            item.Date = DateTime.Parse(rawDate);
          }
          else if (line.Substring(0, 12) == "Lock       :")
          {
            item.Lock = line.Replace("Lock       :", "").Trim();
          }
          else if (line.Substring(0, 12) == "Change     :")
          {
            item.Change = line.Replace("Change     :", "").Trim();
          }
          else if (line.Substring(0, 12) == "Workspace  :")
          {
            item.Workspace = line.Replace("Workspace  :", "").Trim();
          }
          else if (line.Substring(0, 12) == "Local item :")
          {
            item.LocalItem = line.Replace("Local item :", "").Trim();
          }
          else if (line.Substring(0, 12) == "File type  :")
          {
            item.FileType = line.Replace("File type  :", "").Trim();
          }
        }
      }
      if (item.ItemSpec != null && item.ItemSpec != "")
      {
        SW.WriteLine(item.ItemSpec + "" + DEL + "" + item.User + "" + DEL + "" + item.Date + "" + DEL + "" + item.Lock + "" + DEL + "" + item.Change + "" + DEL + "" + item.Workspace + "" + DEL + "" + item.LocalItem + "" + DEL + "" + item.FileType);
      }
      SR.Close();
      SW.Close();
    }

    static void Main(string[] args)
    {
      Convert2CSV();
    }
  }
}
