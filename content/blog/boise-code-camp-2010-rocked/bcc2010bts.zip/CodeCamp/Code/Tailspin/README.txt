
Working with Tailspin

1.       I have IntegratedSecurity on in the connection strings, instead of including the username and password, so make sure your dev account is sysadmin in  SQLServer and that the account running your app in IIS has dbowner (or at least read/write) to TailspinToys and aspnetdb databases.

2.        I don�t have parameterized deployment working yet, so if your DB is not on the same machine, you�ll have to update the connection strings in web.config to point to the right box.

3.       You can deploy the database schema from within VS, in which case you need to update the connection string associated with the project if it�s not localhost. You can also deploy the schema using vsdbcmd. (There is also a connection string in the Utility.tt file, but you shouldn�t have to change that unless you need to regen that code after schema changes.)

4.       Once you have the DB in a place accessible to your dev account, you can F5 or Ctrl-F5 to make sure things are working on your box.

5.       If you�re using msdeploy, you have to make sure you have the same version on the boxes you�re using it on.


Known Bugs for Demos

�         If you �Add Item To Cart� more than once, it doesn�t increment the quantity in the cart, as is expected of most shopping sites. It�s more subtle than many of the bugs we usually demo, but some of the unit tests pick it up and we have a reasonable Architecture Explorer to Historical Debugger scenario to find and fix the issue. Because of the unit test (and manual test) overlap, this also gives us test impact data in the VM. The fix for the bug is in Tailspin.Model/Customer/ShoppingCart.cs. Change line 93 to include the quantity passed into the method:
AdjustQuantity(product, item.Quantity + quantity);

�         Shipping is included in the Grand Total for the shopping cart when you checkout, but not in the actual order receipt that you receive at the end. We have a manual test case that we use to find that one, because it exercises the core shopping experience. That is fixed in Kona.Web/Order/Order.cs. Change line 201 to include the shipping amount:
decimal total= SubTotal + TaxAmount + ShippingAmount;

�         The Preorder checkboxes don�t work in the Admin App.

 
Deploying to IIS

The Tailspin Toys site now deploys to IIS7 in Integrated mode. Deploy to an integrated app pool with an ID that can access the databases.


To register ASP.NET

Cd C:\windows\microsoft.net\framework\<version>

aspnet_regiis �i

