﻿<%@ Control Language="C#" Inherits="System.Web.Mvc.ViewUserControl<ProductList>" %>

<%if (Model.Products != null) { %>
    <div class="wish-list">
        <h2>My Wish List</h2>
        <ul>
            <%foreach (Product p in Model.Products) { %>
                <li><a href="<%=Url.Action("Show","Home",new{sku=p.SKU}) %>"><%=p.Name%></a></li>
            <%} %>
        </ul>
        <div class="clear"></div><!--end clear-->
    </div><!--end wish-list-->
<%} %>

