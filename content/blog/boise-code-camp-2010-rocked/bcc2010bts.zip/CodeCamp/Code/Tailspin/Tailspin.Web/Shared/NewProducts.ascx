﻿<%@ Control Language="C#" Inherits="System.Web.Mvc.ViewUserControl<ProductList>" %>

<table class="badges">
    <tr>
        <%foreach (Product p in Model.Products) { %>
            <td><a href="<%=Url.Action("Show","Home",new{sku=p.SKU}) %>"><img src="<%=Html.ProductImage(p.DefaultImage.FullSizePhoto) %>" width="65" height="57" alt="<%=p.Name%>" /></a></td>
        <%} %>
    </tr>
</table> <!--end badges-->

