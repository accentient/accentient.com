using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using Tailspin.Model;
using Tailspin.Infrastructure;

namespace Tailspin.Web.App.Controllers
{

    public class WishListController : TailspinController
    {
        IProductRepository _productRepository;
        ICustomerRepository _customerRepository;
       
        public WishListController(ICustomerRepository customerRepository,
            IProductRepository productRepository) : base(customerRepository) {
            _productRepository = productRepository;
            _customerRepository = customerRepository;
        }

        public ActionResult Index()
        {
            return View();
        }

        #region Wish List Actions

        public ActionResult Show() {
            IList<Product> products = new List<Product>();
            foreach (string sku in this.GetWishListSkus()){
                products.Add(_productRepository.GetProduct(sku));
            }
            if (products.Count() == 0)
            {
                products = null;
            }

            return View("WishList", new ProductList("Wish List", products));
        }

        public ActionResult AddItem(string sku) {
            this.SaveWishListSkus(sku);
            this.SelectedProduct = _productRepository.GetProduct(sku);
            return View("Detail");
        }
        
        #endregion
    
    
    
    
    }
}
