namespace ADONETDemo
{
	partial class Form2
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnClear = new System.Windows.Forms.Button();
			this.btnExecuteAsync = new System.Windows.Forms.Button();
			this.btnExecuteHourglass = new System.Windows.Forms.Button();
			this.btnExecuteSynch = new System.Windows.Forms.Button();
			this.grdDemo = new System.Windows.Forms.DataGridView();
			this.txtSQL = new System.Windows.Forms.TextBox();
			((System.ComponentModel.ISupportInitialize)(this.grdDemo)).BeginInit();
			this.SuspendLayout();
			// 
			// btnClear
			// 
			this.btnClear.Location = new System.Drawing.Point(586, 15);
			this.btnClear.Name = "btnClear";
			this.btnClear.Size = new System.Drawing.Size(75, 23);
			this.btnClear.TabIndex = 12;
			this.btnClear.Text = "Clear";
			// 
			// btnExecuteAsync
			// 
			this.btnExecuteAsync.Location = new System.Drawing.Point(505, 15);
			this.btnExecuteAsync.Name = "btnExecuteAsync";
			this.btnExecuteAsync.Size = new System.Drawing.Size(75, 23);
			this.btnExecuteAsync.TabIndex = 11;
			this.btnExecuteAsync.Text = "Async";
			// 
			// btnExecuteHourglass
			// 
			this.btnExecuteHourglass.Location = new System.Drawing.Point(424, 15);
			this.btnExecuteHourglass.Name = "btnExecuteHourglass";
			this.btnExecuteHourglass.Size = new System.Drawing.Size(75, 23);
			this.btnExecuteHourglass.TabIndex = 10;
			this.btnExecuteHourglass.Text = "Hourglass";
			// 
			// btnExecuteSynch
			// 
			this.btnExecuteSynch.Location = new System.Drawing.Point(343, 15);
			this.btnExecuteSynch.Name = "btnExecuteSynch";
			this.btnExecuteSynch.Size = new System.Drawing.Size(75, 23);
			this.btnExecuteSynch.TabIndex = 9;
			this.btnExecuteSynch.Text = "Execute";
			this.btnExecuteSynch.Click += new System.EventHandler(this.btnExecuteSynch_Click);
			// 
			// grdDemo
			// 
			this.grdDemo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.grdDemo.Location = new System.Drawing.Point(-16, 47);
			this.grdDemo.Name = "grdDemo";
			this.grdDemo.Size = new System.Drawing.Size(699, 211);
			this.grdDemo.TabIndex = 8;
			// 
			// txtSQL
			// 
			this.txtSQL.Location = new System.Drawing.Point(-16, 18);
			this.txtSQL.Name = "txtSQL";
			this.txtSQL.Size = new System.Drawing.Size(353, 20);
			this.txtSQL.TabIndex = 7;
			this.txtSQL.Text = "WAITFOR DELAY \'00:00:10\'; SELECT * FROM Person.Contact";
			// 
			// Form2
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(667, 273);
			this.Controls.Add(this.btnClear);
			this.Controls.Add(this.btnExecuteAsync);
			this.Controls.Add(this.btnExecuteHourglass);
			this.Controls.Add(this.btnExecuteSynch);
			this.Controls.Add(this.grdDemo);
			this.Controls.Add(this.txtSQL);
			this.Name = "Form2";
			this.Text = "Form2";
			((System.ComponentModel.ISupportInitialize)(this.grdDemo)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Button btnExecuteAsync;
		private System.Windows.Forms.Button btnExecuteHourglass;
		private System.Windows.Forms.Button btnExecuteSynch;
		private System.Windows.Forms.DataGridView grdDemo;
		private System.Windows.Forms.TextBox txtSQL;
	}
}