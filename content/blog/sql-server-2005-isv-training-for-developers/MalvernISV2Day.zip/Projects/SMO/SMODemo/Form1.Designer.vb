﻿Partial Public Class Form1
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

    End Sub

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.btnTest = New System.Windows.Forms.Button
    Me.txtOutput = New System.Windows.Forms.TextBox
    Me.SuspendLayout()
    '
    'btnTest
    '
    Me.btnTest.Location = New System.Drawing.Point(13, 13)
    Me.btnTest.Name = "btnTest"
    Me.btnTest.TabIndex = 0
    Me.btnTest.Text = "Test"
    '
    'txtOutput
    '
    Me.txtOutput.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.txtOutput.AutoSize = False
    Me.txtOutput.Location = New System.Drawing.Point(13, 43)
    Me.txtOutput.Multiline = True
    Me.txtOutput.Name = "txtOutput"
    Me.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
    Me.txtOutput.Size = New System.Drawing.Size(486, 432)
    Me.txtOutput.TabIndex = 1
    '
    'Form1
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(511, 487)
    Me.Controls.Add(Me.txtOutput)
    Me.Controls.Add(Me.btnTest)
    Me.Name = "Form1"
    Me.Text = "SMO Demo"
    Me.ResumeLayout(False)

  End Sub
  Friend WithEvents btnTest As System.Windows.Forms.Button
  Friend WithEvents txtOutput As System.Windows.Forms.TextBox

End Class
