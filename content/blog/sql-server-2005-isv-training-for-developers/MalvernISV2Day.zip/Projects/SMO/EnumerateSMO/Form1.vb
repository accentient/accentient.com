﻿Imports System.Reflection
Imports System.IO

Public Class Form1

  Private Sub Log(ByVal msg As String)
    TextBox1.AppendText(msg & ControlChars.CrLf)
  End Sub

  Private Sub TallyByType(ByVal sAssemblyName As String, ByVal myType As Type)

    Dim MyMemberInfoArray As MemberInfo() = myType.GetMembers()
    Dim MyMemberInfo As MemberInfo

    Dim numConstructor As Int32
    Dim numCustom As Int32
    Dim numEvent As Int32
    Dim numField As Int32
    Dim numMethod As Int32
    Dim numNestedType As Int32
    Dim numProperty As Int32
    Dim numTypeInfo As Int32
    Dim sMsg As String

    ' Walk through all of its members

    For Each MyMemberInfo In MyMemberInfoArray
      Select Case MyMemberInfo.MemberType.ToString()
        Case "Constructor"
          numConstructor = numConstructor + 1
        Case "Field"
          numField = numField + 1
        Case "Method"
          numMethod = numMethod + 1
        Case "Property"
          numProperty = numProperty + 1
        Case "Event"
          numEvent = numEvent + 1
        Case "NestedType"
          numNestedType = numNestedType + 1
        Case Else
          Log("   !" & MyMemberInfo.MemberType.ToString() & _
          ControlChars.Tab & MyMemberInfo.Name & " declaring type - " + MyMemberInfo.DeclaringType.ToString())
      End Select
    Next MyMemberInfo

    ' Display Sub Totals

    Log(sAssemblyName + "," + myType.Name + "," _
                + numConstructor.ToString() + "," _
                + numMethod.ToString() + "," _
                + numProperty.ToString() + "," _
                + numEvent.ToString() + "," _
                + numField.ToString() + "," _
                + numTypeInfo.ToString() + "," _
                + numNestedType.ToString() + "," _
                + numCustom.ToString())
  End Sub

  Private Sub ReflectAssembly(ByVal ASM As String)

    Dim MyAssembly As [Assembly]

    Log(ASM)
    Log("")
    Log("Assembly,Type,Constructors,Methods,Properties,Events,Fields,Type Info,Nested Types,Custom")
    MyAssembly = [Assembly].LoadFrom(ASM)

    Dim myTypes() As Type
    Dim myType As Type

    myTypes = MyAssembly.GetExportedTypes()

    For Each myType In myTypes
      TallyByType(ASM, myType)
    Next
  End Sub

  Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
    TextBox1.Clear()
    ReflectAssembly("C:\Program Files\Microsoft SQL Server\90\SDK\Assemblies\Microsoft.SqlServer.Smo.dll")
    ReflectAssembly("C:\Program Files\Microsoft SQL Server\90\SDK\Assemblies\Microsoft.SqlServer.SmoEnum.dll")
  End Sub
End Class
