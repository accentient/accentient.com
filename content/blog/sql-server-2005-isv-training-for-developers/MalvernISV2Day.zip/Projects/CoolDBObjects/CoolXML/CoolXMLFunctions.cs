using System;
using System.Data;
using System.Data.Sql;
using System.Data.SqlTypes;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;
using Microsoft.SqlServer.Server;

public partial class StoredProcedures
{
	[Microsoft.SqlServer.Server.SqlProcedure]
	public static void spTransformXML(SqlXml rawXML, SqlXml rawXSLT)
	{
		SqlPipe pipe = SqlContext.Pipe;

		// Cast XML

		XmlDocument xmlDoc = new System.Xml.XmlDocument();
		xmlDoc.LoadXml(rawXML.Value);

		// Cast XSLT

		XmlDocument xslDoc = new System.Xml.XmlDocument();
		xslDoc.LoadXml(rawXSLT.Value);

		// Transform

		XslCompiledTransform xslt = new XslCompiledTransform();
		xslt.Load(xslDoc);
		Stream stream = new MemoryStream();
		XmlWriter wrt = new XmlTextWriter(stream, System.Text.Encoding.UTF8);
		xslt.Transform(xmlDoc, null, wrt);

		// Return HTML

		stream.Position = 0;
		StreamReader SR = new StreamReader(stream);
		pipe.Send(SR.ReadToEnd());
		SR.Close();
	}
};
