Imports System
Imports System.Data
Imports System.Data.Sql
Imports System.Data.SqlTypes
Imports Microsoft.SqlServer.Server

Partial Public Class CoolFunctions

    <Microsoft.SqlServer.Server.SqlFunction()> _
    Public Shared Function HappyMessage() As SqlString
        Return New SqlString("Hello World")
    End Function

    <Microsoft.SqlServer.Server.SqlFunction()> _
    Public Shared Function CoolEncrypt(ByVal Data As SqlString) As SqlString
        Dim strArray() As Char
        strArray = Data.ToString().ToCharArray()
        Array.Reverse(strArray)
        Return New SqlString(strArray)
    End Function

End Class
