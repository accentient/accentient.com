using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace ConsoleApplication1
{
	class Program
	{

		static void RowUpdatedHandler(Object sender, SqlRowUpdatedEventArgs args)
		{
			Console.WriteLine("Just updated " + args.RecordsAffected.ToString() + " rows.");
		}

		static void Main(string[] args)
		{
			SqlConnection conAW = new SqlConnection("server=(local);database=AdventureWorks;Integrated Security=SSPI;");
			conAW.Open();

			// DataSet

			DataSet ds = new DataSet();
			SqlDataAdapter adpAW = new SqlDataAdapter("SELECT EmployeeID, Title, BirthDate FROM HumanResources.Employee",conAW);
			adpAW.Fill(ds, "Employees");

			// Make a bunch of changes

			DataTable tblEmp = ds.Tables["Employees"];
			foreach (DataRow rowEmp in tblEmp.Rows)
				rowEmp["Title"] = "Light Sabre Cleaner";

			// Create an UpdateCommand

			SqlCommandBuilder bldAW = new SqlCommandBuilder(adpAW);
			adpAW.UpdateCommand = bldAW.GetUpdateCommand();

			// Connect the event

			adpAW.RowUpdated += new SqlRowUpdatedEventHandler(RowUpdatedHandler);

			// Send the changes


			// adpAW.UpdateBatchSize = 50; // Should give us 6 batches (@ 290)
			adpAW.UpdateBatchSize = 0;

			adpAW.Update(ds, "Employees");

			conAW.Close();
			Console.ReadLine();
		}
	}
}
