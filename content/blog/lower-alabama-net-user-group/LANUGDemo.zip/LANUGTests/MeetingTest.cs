﻿using LANUG;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace LANUGTests
{
    
    [TestClass()]
    public class MeetingTest
    {

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        [TestMethod()]
        public void Announce_MeetingIsFull_ReturnsTrue()
        {
            Meeting meeting = new Meeting();
            Boolean result = meeting.Announce("Meeting is full");
            Assert.IsTrue(result);
        }

        [TestMethod()]
        public void Announce_MeetingCanceled_ReturnsFalse()
        {
            Meeting meeting = new Meeting();
            Boolean result = meeting.Announce("Meeting is canceled");
            Assert.IsFalse(result);
        }

        [TestCategory("Schedule"), TestCategory("Richard"), TestCategory("Meeting"), TestMethod()]
        public void ScheduleTest()
        {
            Meeting meeting = new Meeting();
            meeting.Schedule();
            Assert.IsTrue(meeting.Scheduled);
        }

        [TestCategory("Richard"), TestCategory("Cancel"), TestCategory("ADO.NET"), TestCategory("Meeting"), TestMethod()]
        public void CancelTest()
        {
            Meeting meeting = new Meeting();
            meeting.Schedule();
            meeting.Cancel();
            Assert.IsFalse(meeting.Scheduled);
        }

        [TestMethod()]
        public void StreamBegin_ReturnStreamID_IsAGUID()
        {
            Meeting meeting = new Meeting();
            string result = meeting.BeginStream();
            Guid newGuid;
            Assert.IsTrue(Guid.TryParse(result, out newGuid));
        }

        [TestMethod()]
        public void StreamEnd_ReturnsTrue()
        {
            Assert.Inconclusive("Not now, maybe later");
        }

    }
}
