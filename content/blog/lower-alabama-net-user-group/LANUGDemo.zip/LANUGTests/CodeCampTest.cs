﻿using LANUG;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace LANUGTests
{
    
    
    /// <summary>
    ///This is a test class for CodeCampTest and is intended
    ///to contain all CodeCampTest Unit Tests
    ///</summary>
    [TestClass()]
    public class CodeCampTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        [DataSource("Microsoft.VisualStudio.TestTools.DataSource.CSV", "|DataDirectory|\\Attendees.csv", "Attendees#csv", DataAccessMethod.Sequential), DeploymentItem("LANUGTests\\Attendees.csv"), TestMethod()]
        public void EmailBlastTest()
        {
            CodeCamp codeCamp = new CodeCamp();
            string Email = Convert.ToString(TestContext.DataRow["Email"]);
            string Name = Convert.ToString(TestContext.DataRow["Name"]);
            Boolean Presenter = Convert.ToBoolean(TestContext.DataRow["Speaker"]);
            bool result = codeCamp.EmailBlast(Email, Name, Presenter);
            Assert.IsTrue(result);
        }

        [TestMethod()]
        [ExpectedException(typeof(ApplicationException))]
        public void EmailBlast_BadEmailFormat_EasyWay_Test()
        {
            CodeCamp codeCamp = new CodeCamp();
            string Email = "Pudding!";
            string Name = "Bill Cosby";
            Boolean Presenter = true;
            bool result = codeCamp.EmailBlast(Email, Name, Presenter);
        }

        [TestMethod()]
        public void EmailBlast_BadEmailFormat_HardWay_Test()
        {
            CodeCamp codeCamp = new CodeCamp();
            string Email = "Pudding!";
            string Name = "Bill Cosby";
            Boolean Presenter = true;
            try
            {
                bool result = codeCamp.EmailBlast(Email, Name, Presenter);
                Assert.Fail();
            }
            catch (ApplicationException)
            {
                // smile
            }
            catch (Exception)
            {
                Assert.Fail();
            }
        }

    }
}
