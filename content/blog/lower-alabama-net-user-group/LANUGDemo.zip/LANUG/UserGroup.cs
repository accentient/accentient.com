﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LANUG
{
    public class Attendee
    {
        public string Name
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public string Email
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }

    public class Speaker : Attendee
    {
        public string Passion
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }

    public class Giveaway
    {
        private string Name;
    }

    public class Meeting
    {
        private Boolean _scheduled = false;

        public Boolean Scheduled
        {
            get
            {
                return _scheduled;
            }
        }

        public bool Announce(string message)
        {
            // send this to Twitter
            // send this to everyone's phone
            // post it on Facebook

            if (message == "Meeting is canceled")
            {
                return false;
            }
            return true;
        }

        public void Schedule()
        {
            _scheduled = true;
        }

        public void Cancel()
        {
            Boolean f = false;
            _scheduled = f;
        }

        public string BeginStream()
        {
            // make it work better, faster, more secure
            // actually do something
            //
            // MAINTAINABILITY
            //
            // BUT NOT "GOLD PLATE" IT

            return new Guid().ToString();
        }
    }

}
