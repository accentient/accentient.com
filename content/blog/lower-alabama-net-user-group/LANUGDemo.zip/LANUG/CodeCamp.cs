﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LANUG
{
    public class CodeCamp
    {
        public bool EmailBlast(string Email, string Name, bool Presenter)
        {
            if (Email.IndexOf("@") == -1)
            {
                throw new ApplicationException("Invalid Email Format");
            }

            if (Presenter)
            {
                // send email 1
            }
            else
            {
                // send email 2
            }
            return true;
        }
    }
}
