Dim objNetwork
Dim objComputer
Dim strGroupUsers
Dim strGroupStudents
Dim strGroupTeam

Const PASSWORD = "password"
Const ADS_UF_DONT_EXPIRE_PASSWD = &h10000

' Get Computer

Set objNetwork = CreateObject("WScript.Network")
Set objComputer = GetObject("WinNT://" + objNetwork.ComputerName)

' Get Groups

strGroupUsers = "WinNT://" + objNetwork.ComputerName + "/Users,group"
strGroupRemoteDesktopUsers = "WinNT://" + objNetwork.ComputerName + "/Remote Desktop Users,group"

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
' Create Users
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

CreateUser "Scott","Scott (ScrumMaster)","Scrum Team"
CreateUser "Alice","Alice (Business Analyst)","Scrum Team"
CreateUser "Art","Art (Architect)","Scrum Team"
CreateUser "Dave","Dave (Developer)","Scrum Team"
CreateUser "Dieter","Dieter (DBA)","Scrum Team"
CreateUser "Toni","Toni (Tester)","Scrum Team"
CreateUser "Wade","Wade (Developer)","Scrum Team"
CreateUser "Bob","Bob (Builder)","Scrum Team"

' Readers

CreateUser "Jake","Jake (Stakeholder)","Stakeholders"

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

' Done

Set objComputer = Nothing
Set objNetwork  = Nothing
msgbox "Team Members Added!"
Wscript.quit

' Subroutines

sub CreateUser (User,FullName,Group)

  ' Drop first

  on error resume next
  objComputer.Delete "User",User
  on error goto 0

  ' Add User

  set objUser = objComputer.Create("User",User)
  objUser.SetInfo
  objUser.FullName = FullName
  objUser.Description = FullName
  objUser.SetPassword PASSWORD

  ' Set Password so it doesn't expire

  lngUF = objUser.Get("userFlags")
  lngUF = lngUF Or ADS_UF_DONT_EXPIRE_PASSWD
  objUser.Put "userFlags", lngUF

  ' Activate the above settings
  
  objUser.SetInfo

  ' Add account to Users group

  Set objGroup = GetObject(strGroupUsers)
  objGroup.Add(objUser.ADsPath)

  ' Add account to Remote Desktop Users group

  Set objGroup = GetObject(strGroupRemoteDesktopUsers)
  objGroup.Add(objUser.ADsPath)

  ' Add account to Team group

  strGroupTeam = "WinNT://" + objNetwork.ComputerName + "/" + Group + ",group"
  Set objGroup = GetObject(strGroupTeam)
  objGroup.Add(objUser.ADsPath)
End Sub