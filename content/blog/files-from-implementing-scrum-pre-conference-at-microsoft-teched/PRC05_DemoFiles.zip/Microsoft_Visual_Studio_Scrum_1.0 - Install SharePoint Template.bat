@ECHO OFF
C:
CD \Program Files\Microsoft\Microsoft Visual Studio Scrum 1.0\Project Portal
COPY *.wsp "C:\Program Files\Microsoft Team Foundation Server 2010\Tools\Templates"
PAUSE

"C:\Program Files\Common Files\Microsoft Shared\web server extensions\12\BIN\stsadm.exe" -o addsolution -filename "C:\Program Files\Microsoft Team Foundation Server 2010\Tools\Templates\Microsoft.TeamFoundation.SharePoint.Scrum.wsp"
PAUSE

"C:\Program Files\Common Files\Microsoft Shared\web server extensions\12\BIN\stsadm.exe" -o deploysolution -name microsoft.teamfoundation.sharepoint.scrum.wsp -immediate -allowGacDeployment
"C:\Program Files\Common Files\Microsoft Shared\web server extensions\12\BIN\stsadm.exe" -o execadmsvcjobs
PAUSE

"C:\Program Files\Common Files\Microsoft Shared\web server extensions\12\BIN\stsadm.exe" -o enumsolutions
PAUSE