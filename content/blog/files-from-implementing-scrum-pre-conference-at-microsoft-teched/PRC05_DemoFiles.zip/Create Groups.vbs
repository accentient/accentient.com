Dim objNetwork
Dim objComputer
Dim objGroup

' Get computer

Set objNetwork = CreateObject("WScript.Network")
Set objComputer = GetObject("WinNT://" + objNetwork.ComputerName)

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
' Create Groups
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

CreateGroup "TFS Administrators","TFS Administrators"
CreateGroup "Scrum Team","Team members who can contribute to the project"
CreateGroup "Stakeholders","Read-only access to the project"

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

' Done

Set objGroup    = Nothing
Set objComputer = Nothing
Set objNetwork  = Nothing
msgbox "Groups Added!"
Wscript.quit

' Create the group

sub CreateGroup (Group,Description)

  ' Drop

  on error resume next
  objComputer.Delete "Group",Group
  on error goto 0

  ' Create

  set objGroup = objComputer.Create("Group",Group)
  objGroup.SetInfo
  objGroup.Description = Description
  objGroup.SetInfo
End Sub
