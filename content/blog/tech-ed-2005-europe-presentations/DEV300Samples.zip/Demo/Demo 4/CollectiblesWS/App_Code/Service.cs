// Copyright(c) Microsoft Corporation. All rights reserved.

using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

//Additional namespaces
using System.Collections;
using System.Xml;
using System.Xml.Serialization;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Security.Principal;
using System.IO;
using System.Configuration;

using CollectorNS;

//BIS namespaces
using Microsoft.VisualStudio.Bis.Proxy;
using Microsoft.VisualStudio.Bis.BisEnablement;
using Microsoft.VisualStudio.Bis.Services;
using System.Diagnostics;

[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class Service : System.Web.Services.WebService
{
	private static string myConnectString; //stores connection string   
	private static string myTfsServerUrl; //stores connection string   

	/// <summary>
	/// constructor initializes DB connection string
	/// </summary>
	public Service()
	{
		//read connection string from web.config
		myConnectString = ConfigurationManager.AppSettings.Get("Connection String");
		myTfsServerUrl = ConfigurationManager.AppSettings.Get("TFS URL");
	}

	//
	//these methods implement IToolServerLinking
	//

	/// <summary>
	/// Gets Artifacts specified by URIs
	/// </summary>
	/// <param name="artifactUris">an array of artifactUris</param>
	/// <returns>the Artifacts with the artifactUris</returns>
	[WebMethod]
	public Artifact[] GetArtifacts(string[] artifactUris)
	{
		int ID = 0;
		Artifact[] aList = new Artifact[artifactUris.Length];

		for (int i = 0; i < artifactUris.Length; i++)
		{
			BisProxyServices bisServices = new BisProxyServices();
			ILinking linkingInstance = (ILinking)bisServices.GetProxyFromUrl(myTfsServerUrl, typeof(ILinking));
			ID = int.Parse(linkingInstance.DecodeUri(artifactUris[i]).ToolSpecificId);
			Collector c = GetCollector(ID);
			aList[i] = Collector.Collector2Artifact(c);

		}
		return aList;
	}

	/// <summary>
	/// Gets the Artifacts referring to the uris
	/// </summary>
	/// <param name="uriList">the array of artifact URIs</param>
	/// <returns>the array of Collector Artifacts that refer to one or more URIs in uriList; null if there are no such Collector Artifacts</returns>
	[WebMethod]
	public Artifact[] GetReferencingArtifacts(string[] uriList)
	{
		Collector[] collectors = GetCollectors(null);
		if (collectors != null && uriList.Length > 0)
		{
			//contains Collectors that refer to the input artifact Uris
			ArrayList returnSet = new ArrayList();

			//create a hash table of the artifactUris for quick look up
			Hashtable hashedUris = new Hashtable();
			for (int i = 0; i < uriList.Length; i++)
			{
				hashedUris.Add(uriList[i], null);
			}

			//iterate through all collectors to find those that refer to artifactUris
			for (int i = 0; i < collectors.Length; i++)
			{
				for (int j = 0; j < collectors[i].OutboundLinks.Length; j++)
				{
					if (hashedUris.ContainsKey(collectors[i].OutboundLinks[j].ReferencedUri))
					{
						returnSet.Add(Collector.Collector2Artifact(collectors[i]));
						break;
					}
				}
			}

			//This is necessary to make sure the XML passed back through SOAP includes each
			//artifact's artifact-ness only.  If the serialized object includes anything about
			//the collector class, the pass through from the ILinking interface will fail.
			Artifact[] aList = new Artifact[returnSet.Count];
			for (int i = 0; i < returnSet.Count; i++)
			{
				Artifact a = (Artifact)returnSet[i];
				aList[i] = a;
			}
			//return the returnSet as an Artifact array
			return aList;
		}
		else
		{
			return null;
		}
	}

	/// <summary>
	/// A stub for an IServerLinking method - not implemented for this class
	/// </summary>
	/// <param name="uriList"></param>
	/// <param name="filters"></param>
	/// <returns>null</returns>
	public Artifact[] GetReferencingArtifacts(string[] uriList, LinkFilter[] filters)
	{
		return null;
	}


	//these methods are for getting and manipulating collectors

	/// <summary>
	/// Gets all collectors scoped to the projectUri
	/// </summary>
	/// <param name="projectUri">the projectUri</param>
	/// <returns>All collectors that have the projectUri; all collectors on server if projectUri == null</returns>
	[WebMethod]
	public Collector[] GetCollectors(string projectUri)
	{
		SqlConnection conn = new SqlConnection(myConnectString);
		conn.Open();
		SqlCommand comm = new SqlCommand();
		comm.Connection = conn;
		comm.CommandType = CommandType.Text;

		if (projectUri == null)
		{
			comm.CommandText = "SELECT ID FROM CollectorStore";
		}
		else
		{
			comm.CommandText = "SELECT ID FROM CollectorStore WHERE ProjectUri = '" + projectUri + "'";
		}

		SqlDataReader rows = comm.ExecuteReader();

		ArrayList results = new ArrayList();
		while (rows.Read())
		{
			int tmp = rows.GetInt32(0);
			results.Add(GetCollector(tmp));
		}

		conn.Close();
		return (Collector[])results.ToArray(typeof(Collector));
	}

	/// <summary>
	/// Gets the collector with ID
	/// </summary>
	/// <param name="ID">the ID of the desired Collector</param>
	/// <returns>the Collector w/ the ID; null if there's no Collector w/ ID</returns>
	[WebMethod]
	public Collector GetCollector(int ID)
	{
		Collector result = null;

		SqlConnection m_sqlConn = new SqlConnection(myConnectString);
		m_sqlConn.Open();

		SqlCommand m_sqlComm = new SqlCommand();
		m_sqlComm.Connection = m_sqlConn;
		m_sqlComm.CommandType = CommandType.Text;

		m_sqlComm.CommandText = "SELECT Title, ProjectUri FROM CollectorStore WHERE ID = " + ID.ToString();

		SqlDataReader row = m_sqlComm.ExecuteReader();

		//verify that there's a selected collector row and read it
		if (row != null && row.Read())
		{
			result = new Collector(ID, row.GetString(0), row.GetString(1), myTfsServerUrl);
			result = SetOutboundLinks(result);
		}

		return result;
	}


	/// <summary>
	/// A test method that verifies the web service is running.  This test method inserts a new collector into the server and then gets an array of all collectors on the server.  It returns "42" upon success.
	/// </summary>
	/// <returns>"42" if the server is running properly</returns>
	[WebMethod]
	public int Test()
	{
		Collector c = new Collector(-1, "a test collector", "vstfs:///test123", myTfsServerUrl);
		InsertCollector(c);
		Collector[] cols = GetCollectors(null);

		return 42;
	}

	/// <summary>
	/// Replaces a collector w/ a new version of the collector
	/// </summary>
	/// <param name="collector">The collector parameter will replace the existing collector on the server that shares the same ID</param>
	/// <returns>the number of rows changed in the Collector database; should be 2 (1 for removal of old, 1 for insertion) on success; 0 on failure</returns>
	[WebMethod]
	public int SetCollector(Collector collector)
	{
		int nRows = 0;

		if (collector != null && collector.ArtifactTitle != null & collector.ProjectUri != null)
		{
			//get the matching collector from the DB
			BisProxyServices bisServices = new BisProxyServices();
			ILinking linkingInstance = (ILinking)bisServices.GetProxyFromUrl(myTfsServerUrl, typeof(ILinking));
			ArtifactId artifactId = linkingInstance.DecodeUri(collector.Uri);
			if (artifactId == null || artifactId.ToolSpecificId == null)
			{
				return nRows;
			}
			Collector matchingCollector = GetCollector(int.Parse(artifactId.ToolSpecificId));
			if (matchingCollector == null)
			{
				return nRows;
			}

			//remove old links and rows
			nRows += RemoveCollector(int.Parse(artifactId.ToolSpecificId));

			SqlConnection conn = new SqlConnection(myConnectString);
			conn.Open();
			SqlCommand comm = new SqlCommand();
			comm.Connection = conn;
			comm.CommandType = CommandType.Text;

			//insert new row
			comm.CommandText = "set IDENTITY_INSERT CollectorStore ON; "
				+ "INSERT INTO CollectorStore (ID, Title, ProjectURI) values ('"
				+ artifactId.ToolSpecificId + "', '"
				+ collector.ArtifactTitle + "', '" + collector.ProjectUri + "'); "
				+ "set IDENTITY_INSERT CollectorStore OFF";
			nRows += comm.ExecuteNonQuery();
			conn.Close();

			//insert new links
			nRows += InsertOutboundLinks(collector);

			//fire event for delete of old         
			FireCollectorChangeEvent(collector, ChangeType.Change);
		}

		return nRows;
	}

	/// <summary>
	/// Inserts a new collector into the database
	/// </summary>
	/// <param name="collector">the collector to be inserted; the collector's ID is ignored as the database will assign this automatically upon insertion</param>
	/// <returns>the number of rows changed in the database; should be 1 on success; 0 for failure</returns>
	[WebMethod]
	public int InsertCollector(Collector collector)
	{
		int nRows = 0;

		if (collector != null && collector.ArtifactTitle != null & collector.ProjectUri != null)
		{
			SqlConnection conn = new SqlConnection(myConnectString);
			conn.Open();
			SqlCommand comm = new SqlCommand();
			comm.Connection = conn;
			comm.CommandType = CommandType.Text;

			//insert new row and links
			comm.CommandText = "INSERT INTO CollectorStore (Title, ProjectURI) values ('"
	+ collector.ArtifactTitle + "', '" + collector.ProjectUri + "')";
			nRows += comm.ExecuteNonQuery();

			conn.Close();

			//get inserted collector
			Collector[] collectors = GetCollectors(collector.ProjectUri);
			Collector insertedCollector = null;
			foreach (Collector c in collectors)
			{
				if (c.ArtifactTitle == collector.ArtifactTitle)
				{
					insertedCollector = c;
					break;
				}
			}
			//return fail if the inserted collector could not be found
			if (insertedCollector == null)
			{
				return nRows;
			}

			//update collector w/ URI (which reflects DB-assigned ID) of insertedCollector
			collector.Uri = insertedCollector.Uri;

			//fire event
			FireCollectorChangeEvent(collector, ChangeType.Add);

			//update links
			nRows += InsertOutboundLinks(collector);
		}

		return nRows;
	}

	/// <summary>
	/// Removes a collector w/ a given ID from the database
	/// </summary>
	/// <param name="ID">the ID of the collector to be removed</param>
	/// <returns>the number of rows changed in the database; 1 for successful removal of the collector; 0 for failure</returns>
	[WebMethod]
	public int RemoveCollector(int ID)
	{
		//get collector from DB and fire event first
		Collector collector = GetCollector(ID);
		if (collector == null)
		{
			return 0;
		}

		FireCollectorChangeEvent(collector, ChangeType.Delete);

		//remove links from table first due to referential integrity issues
		RemoveOutboundLinks(ID);

		SqlConnection conn = new SqlConnection(myConnectString);
		conn.Open();
		SqlCommand comm = new SqlCommand();
		comm.Connection = conn;
		comm.CommandType = CommandType.Text;

		//remove collector
		comm.CommandText = "DELETE FROM CollectorStore WHERE ID = " + ID.ToString();
		int nRows = comm.ExecuteNonQuery();
		conn.Close();

		return nRows;
	}

	/// <summary>
	/// Helper method for populating a collector's outbound links from the database
	/// </summary>
	/// <param name="collector">the collector whose OutboundLinks will be populated</param>
	/// <returns>the collector with its OutboundLinks</returns>
	private static Collector SetOutboundLinks(Collector collector)
	{
		//sql connect
		SqlConnection conn = new SqlConnection(myConnectString);
		conn.Open();
		SqlCommand comm = new SqlCommand();
		comm.Connection = conn;
		comm.CommandType = CommandType.Text;

		BisProxyServices bisServices = new BisProxyServices();
		ILinking linkingInstance = (ILinking)bisServices.GetProxyFromUrl(myTfsServerUrl, typeof(ILinking));
		comm.CommandText = "SELECT Uri, LinkType FROM OutgoingLinks WHERE CollectorId = "
			+ linkingInstance.DecodeUri(collector.Uri).ToolSpecificId;

		SqlDataReader results = comm.ExecuteReader();

		//add each outbound link from the result set into an array
		ArrayList linksArray = new ArrayList();
		while (results.Read())
		{
			OutboundLink aLink = new OutboundLink();
			aLink.ReferencedUri = results.GetString(0);
			aLink.LinkType = results.GetString(1);
			linksArray.Add(aLink);
		}

		collector.OutboundLinks = (OutboundLink[])linksArray.ToArray(typeof(OutboundLink));

		conn.Close();

		return collector;
	}

	/// <summary>
	/// Helper for inserting the collector's OutboundLinks into the database
	/// </summary>
	/// <param name="collector">the collector's OutboundLinks will be inserted</param>
	/// <returns>the number of link rows added to the database from the collector; 0 if no links were added to the database</returns>
	private static int InsertOutboundLinks(Collector collector)
	{
		int nRows = 0; //tracks number of row transactions

		if (collector.OutboundLinks != null && collector.OutboundLinks.Length > 0)
		{
			SqlConnection conn = new SqlConnection(myConnectString);
			conn.Open();
			SqlCommand comm = new SqlCommand();
			comm.Connection = conn;
			comm.CommandType = CommandType.Text;

			//insert each link into DB
			BisProxyServices bisServices = new BisProxyServices();
			ILinking linkingInstance = (ILinking)bisServices.GetProxyFromUrl(myTfsServerUrl, typeof(ILinking));
			string ID = linkingInstance.DecodeUri(collector.Uri).ToolSpecificId;
			foreach (OutboundLink aLink in collector.OutboundLinks)
			{
				comm.CommandText = "INSERT INTO OutgoingLinks (CollectorId, URI, LinkType) values ('"
					+ ID
					+ "', '" + aLink.ReferencedUri + "', '"
					+ aLink.LinkType + "')";
				nRows += comm.ExecuteNonQuery();
			}

			conn.Close();
		}

		return nRows;
	}

	/// <summary>
	/// Helper for removing all the outbound links for collector w/ ID from the database
	/// </summary>
	/// <param name="ID">the ID of the collector whose links willb e removed from the database</param>
	/// <returns>the number of link rows removed; 0 on fail</returns>
	private static int RemoveOutboundLinks(int ID)
	{
		SqlConnection conn = new SqlConnection(myConnectString);
		conn.Open();
		SqlCommand comm = new SqlCommand();
		comm.Connection = conn;
		comm.CommandType = CommandType.Text;

		comm.CommandText = "DELETE FROM OutgoingLinks where CollectorId = " + ID.ToString();
		int nRows = comm.ExecuteNonQuery();

		conn.Close();

		return nRows;
	}

	/// <summary>
	/// Helper method for firing a VSTF event when a collector changes
	/// </summary>
	/// <param name="collector">the event will be fired for this collector</param>
	/// <param name="changeType">the event will be fired w/ this changeType</param>
	private static void FireCollectorChangeEvent(Collector collector, ChangeType changeType)
	{
		//create ArtifactChangedEvent for this collector
		Artifact artifact = new Artifact();
		artifact.ArtifactTitle = collector.ArtifactTitle;
		artifact.Uri = collector.Uri;
		artifact.OutboundLinks = collector.OutboundLinks;
		BisProxyServices bisServices = new BisProxyServices();
		ILinking linkingInstance = (ILinking)bisServices.GetProxyFromUrl(myTfsServerUrl, typeof(ILinking));
		ArtifactId artifactId = linkingInstance.DecodeUri(artifact.Uri);
		artifact.ExternalId = artifactId.ToolSpecificId;
		ArtifactChangedEvent aEvent = new ArtifactChangedEvent(artifact.Uri, changeType, artifact);


		IEventService eventService = (IEventService)bisServices.GetProxyFromUrl(myTfsServerUrl, typeof(IEventService));
		XmlSerializer xmls = new XmlSerializer(typeof(ArtifactChangedEvent));
		StringWriter sw = new StringWriter();
		xmls.Serialize(sw, aEvent);
		string xmlStr = sw.ToString();

		eventService.FireAsyncEvent(xmlStr);
	}
}
