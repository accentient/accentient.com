﻿// Copyright(c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.Bis.Proxy;
using Microsoft.VisualStudio.Bis.Services;

namespace CollectorNS
{
    public class Collector : Artifact
    {
        private string projectUri;
        public string ProjectUri
        {
            get
            { return projectUri; }
            set
            { projectUri = value; }
        }

        /// <summary>
        /// This is the default constructor.  It is required for serialization of this class when it is passed between web service calls
        /// </summary>
        public Collector()
        {
            projectUri = null;
        }

        /// <summary>
        /// Constructs a new Collector w/ the specified parameters
        /// </summary>
        /// <param name="id">Constructs the Collector with ToolSpecificID id</param>
        /// <param name="title">Constructs the Collector with ArtifactTitle title</param>
        /// <param name="projectUri">Constructs the Collector scoped to the projectUri</param>
		/// <param name="tfsServerUrl">The URL to the tfs to which this collector is to be scoped</param>
		public Collector(int id, string title, string projectUri, string tfsServerUrl)
        {
            //create an ArtifactId to encapsulate id
            ArtifactId artifactId = new ArtifactId();
            artifactId.ArtifactType = "Collector";
            artifactId.Tool = "Collectibles";
            artifactId.ToolSpecificId = id.ToString();

            //set the artifact's URI, title, and outbound links 
            this.ExternalId = artifactId.ToolSpecificId;
            BisProxyServices bisServices = new BisProxyServices();
            ILinking linkingInstance = (ILinking)bisServices.GetProxyFromUrl(tfsServerUrl, typeof(ILinking));
            this.Uri = linkingInstance.EncodeUri(artifactId);

            this.ArtifactTitle = title;
            this.OutboundLinks = null;

            //scope the artifact to the desired project
            ProjectUri = projectUri;
        }

        /// <summary>
        /// Adds an Outbound link to this
        /// </summary>
        /// <param name="link">Appends link to this collector's OutboundLinks</param>
        /// <returns>A success message on success; null on failure</returns>
        public string AddLink(OutboundLink link)
        {
            if (link.LinkType == null || link.ReferencedUri == null)
            {
                return null;
            }

            //copy current links into temp
            if (OutboundLinks == null)
            {
                OutboundLinks = new OutboundLink[1];
                OutboundLinks[0] = link;
            }
            else
            {
                OutboundLink[] temp = new OutboundLink[this.OutboundLinks.Length];
                for (int i = 0; i < OutboundLinks.Length; i++)
                {
                    temp[i] = OutboundLinks[i];
                }

                //increase OutboundLink array size by 1 and add link
                OutboundLinks = new OutboundLink[temp.Length + 1];
                for (int i = 0; i < temp.Length; i++)
                {
                    OutboundLinks[i] = temp[i];
                }
                OutboundLinks[OutboundLinks.Length - 1] = link;
            }

            return link.ToString() + " added";
        }

        /// <summary>
        /// Removes an outbound link from this 
        /// </summary>
        /// <param name="index">Removes this.OutboundLinks[index]</param>
        /// <returns>the new OutboundLinks on success; an index out of bound error on invalid index</returns>
        public string RemoveLink(int index)
        {
            if (OutboundLinks == null || index < 0 || index >= OutboundLinks.Length)
            {
                return "index out of bound";
            }

            //copy all links but the one to be removed into temp
            if (OutboundLinks.Length == 1)
            {
                OutboundLinks = null;
            }
            else
            {
                OutboundLink[] temp = new OutboundLink[this.OutboundLinks.Length - 1];
                int tempIndex = 0;
                for (int i = 0; i < OutboundLinks.Length; i++)
                {
                    if (index != i)
                    {
                        temp[tempIndex] = OutboundLinks[i];
                        tempIndex++;
                    }
                }

                OutboundLinks = temp;
            }

            return null;
        }

        /// <summary>
        /// IToolServerLinking methods return Artifacts.  SOAP cannot properly cast Collector into its parent Artifact class, so this helper is used
        /// </summary>
        /// <param name="c">the Collector to be converted into an Artifact</param>
        /// <returns>the Artifact equivalent of c without Collector specific properties</returns>
        public static Artifact Collector2Artifact(Collector c)
        {
            Artifact art = new Artifact();
            art.ArtifactTitle = c.ArtifactTitle;
            art.ChangeType = c.ChangeType;
            art.ExtendedAttributes = c.ExtendedAttributes;
            art.ExternalId = c.ExternalId;
            art.LastChangedBy = c.LastChangedBy;
            art.LastChangedOn = c.LastChangedOn;
            art.OutboundLinks = c.OutboundLinks;
            art.Uri = c.Uri;
            return art;
        }
    }
}
