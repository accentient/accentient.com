﻿// Copyright(c) Microsoft Corporation. All rights reserved.

namespace CollectorApp
{
	partial class CollectorProps
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.lblID = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.txtName = new System.Windows.Forms.TextBox();
			this.lblUri = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.lvwRefers = new System.Windows.Forms.ListView();
			this.label4 = new System.Windows.Forms.Label();
			this.lvwReferenced = new System.Windows.Forms.ListView();
			this.btnAddLink = new System.Windows.Forms.Button();
			this.chkAlert = new System.Windows.Forms.CheckBox();
			this.txtEmail = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.btnRemove = new System.Windows.Forms.Button();
			this.btnClose = new System.Windows.Forms.Button();
			this.btnRename = new System.Windows.Forms.Button();
			this.btnSubs = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(13, 4);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(19, 14);
			this.label1.TabIndex = 0;
			this.label1.Text = "ID:";
			// 
			// lblID
			// 
			this.lblID.AutoSize = true;
			this.lblID.Location = new System.Drawing.Point(57, 4);
			this.lblID.Name = "lblID";
			this.lblID.Size = new System.Drawing.Size(27, 14);
			this.lblID.TabIndex = 1;
			this.lblID.Text = "lblID";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(13, 23);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(38, 14);
			this.label2.TabIndex = 2;
			this.label2.Text = "Name:";
			// 
			// txtName
			// 
			this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtName.Location = new System.Drawing.Point(57, 22);
			this.txtName.Name = "txtName";
			this.txtName.ReadOnly = true;
			this.txtName.Size = new System.Drawing.Size(398, 16);
			this.txtName.TabIndex = 3;
			this.txtName.Text = "txtName";
			// 
			// lblUri
			// 
			this.lblUri.AutoSize = true;
			this.lblUri.Location = new System.Drawing.Point(57, 40);
			this.lblUri.Name = "lblUri";
			this.lblUri.Size = new System.Drawing.Size(30, 14);
			this.lblUri.TabIndex = 4;
			this.lblUri.Text = "lblUri";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(13, 56);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(53, 14);
			this.label3.TabIndex = 5;
			this.label3.Text = "Refers to:";
			// 
			// lvwRefers
			// 
			this.lvwRefers.FullRowSelect = true;
			this.lvwRefers.Location = new System.Drawing.Point(13, 76);
			this.lvwRefers.Name = "lvwRefers";
			this.lvwRefers.Size = new System.Drawing.Size(464, 97);
			this.lvwRefers.TabIndex = 6;
			this.lvwRefers.View = System.Windows.Forms.View.Details;
			this.lvwRefers.SelectedIndexChanged += new System.EventHandler(this.lvwRefers_SelectedIndexChanged);
			// 
			// label4
			// 
			this.label4.AccessibleDescription = "Referenced by:";
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(16, 181);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(81, 14);
			this.label4.TabIndex = 7;
			this.label4.Text = "Referenced by:";
			// 
			// lvwReferenced
			// 
			this.lvwReferenced.Location = new System.Drawing.Point(13, 201);
			this.lvwReferenced.Name = "lvwReferenced";
			this.lvwReferenced.Size = new System.Drawing.Size(464, 97);
			this.lvwReferenced.TabIndex = 8;
			this.lvwReferenced.View = System.Windows.Forms.View.Details;
			// 
			// btnAddLink
			// 
			this.btnAddLink.Location = new System.Drawing.Point(483, 76);
			this.btnAddLink.Name = "btnAddLink";
			this.btnAddLink.Size = new System.Drawing.Size(81, 23);
			this.btnAddLink.TabIndex = 9;
			this.btnAddLink.Text = "Add...";
			this.btnAddLink.Click += new System.EventHandler(this.btnAddLink_Click);
			// 
			// chkAlert
			// 
			this.chkAlert.AutoSize = true;
			this.chkAlert.Location = new System.Drawing.Point(12, 306);
			this.chkAlert.Name = "chkAlert";
			this.chkAlert.Size = new System.Drawing.Size(186, 17);
			this.chkAlert.TabIndex = 10;
			this.chkAlert.Text = "Send alert when collector changes";
			this.chkAlert.CheckedChanged += new System.EventHandler(this.chkAlert_CheckedChanged);
			// 
			// txtEmail
			// 
			this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtEmail.Enabled = false;
			this.txtEmail.Location = new System.Drawing.Point(141, 324);
			this.txtEmail.Name = "txtEmail";
			this.txtEmail.ReadOnly = true;
			this.txtEmail.Size = new System.Drawing.Size(325, 16);
			this.txtEmail.TabIndex = 11;
			this.txtEmail.Text = "txtEmail";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Enabled = false;
			this.label5.Location = new System.Drawing.Point(30, 325);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(104, 14);
			this.label5.TabIndex = 12;
			this.label5.Text = "Alert email address:";
			// 
			// btnRemove
			// 
			this.btnRemove.Location = new System.Drawing.Point(483, 105);
			this.btnRemove.Name = "btnRemove";
			this.btnRemove.Size = new System.Drawing.Size(81, 23);
			this.btnRemove.TabIndex = 13;
			this.btnRemove.Text = "Remove";
			this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
			// 
			// btnClose
			// 
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnClose.Location = new System.Drawing.Point(483, 342);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(81, 23);
			this.btnClose.TabIndex = 14;
			this.btnClose.Text = "Close";
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// btnRename
			// 
			this.btnRename.Location = new System.Drawing.Point(483, 24);
			this.btnRename.Name = "btnRename";
			this.btnRename.Size = new System.Drawing.Size(81, 23);
			this.btnRename.TabIndex = 15;
			this.btnRename.Text = "Rename";
			// 
			// btnSubs
			// 
			this.btnSubs.Location = new System.Drawing.Point(30, 342);
			this.btnSubs.Name = "btnSubs";
			this.btnSubs.Size = new System.Drawing.Size(128, 23);
			this.btnSubs.TabIndex = 16;
			this.btnSubs.Text = "Show my email events";
			this.btnSubs.Click += new System.EventHandler(this.btnSubs_Click);
			// 
			// CollectorProps
			// 
			this.AcceptButton = this.btnClose;
			this.AutoScaleDimensions = new System.Drawing.SizeF(5, 13);
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(576, 373);
			this.Controls.Add(this.btnSubs);
			this.Controls.Add(this.btnRename);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.btnRemove);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.txtEmail);
			this.Controls.Add(this.chkAlert);
			this.Controls.Add(this.btnAddLink);
			this.Controls.Add(this.lvwReferenced);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.lvwRefers);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.lblUri);
			this.Controls.Add(this.txtName);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.lblID);
			this.Controls.Add(this.label1);
			this.Name = "CollectorProps";
			this.Text = "CollectorProps";
			this.Load += new System.EventHandler(this.CollectorProps_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label lblID;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtName;
		private System.Windows.Forms.Label lblUri;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ListView lvwRefers;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ListView lvwReferenced;
		private System.Windows.Forms.Button btnAddLink;
		private System.Windows.Forms.CheckBox chkAlert;
		private System.Windows.Forms.TextBox txtEmail;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button btnRemove;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Button btnRename;
		private System.Windows.Forms.Button btnSubs;
	}
}