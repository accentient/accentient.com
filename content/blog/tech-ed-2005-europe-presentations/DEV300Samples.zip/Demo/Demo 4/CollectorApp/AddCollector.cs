﻿// Copyright(c) Microsoft Corporation. All rights reserved.

#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualStudio.Bis.Proxy;
using Microsoft.VisualStudio.Bis.Services;

#endregion

namespace CollectorApp
{
	partial class AddCollector : Form
	{
		private Collector _coll;
		public Collector Collector
		{	get { return _coll; }		}

		public AddCollector()
		{
			InitializeComponent();
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			_coll = new Collector(-1, txtName.Text, CollectorContext.currentProject.Uri);

			int i = CollectorContext.g_CollectiblesWebService.InsertCollector(_coll);
			if (i == 0)
			{
				MessageBox.Show("Nothing added.", "Surprising result", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			this.Close();

		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			_coll = null;
			this.Close();
		}



	}
}