// Copyright(c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.Bis.Proxy;
using Microsoft.VisualStudio.Bis.Services;

namespace CollectorApp
{
	class ArtifactHelper
	{
		private const string uriStart = "vstfs:///";

		//implementing encodeURI and decodeURI methods since these are not implemented in curretn BISLinkingService dll
		//the URIs are of teh form
		//vstfs:///toolType/artifactType/toolSpecificID
		public static string EncodeUri(ArtifactId artifactId)
		{
			if (artifactId != null && 
				artifactId.Tool != null &&
				artifactId.ArtifactType != null &&
				artifactId.ToolSpecificId != null)
			{
				return uriStart + "/" + artifactId.Tool + "/" + artifactId.ArtifactType + "/" + artifactId.ToolSpecificId;
			}

			return null;
		}

		public static ArtifactId DecodeUri(string artifactUri)
		{
			string toolType = null;
			string artifactType = null;
			string toolSpecificID = null;

			if (ValidateUri(artifactUri, ref toolType, ref artifactType, ref toolSpecificID))
			{
				ArtifactId artifactId = new ArtifactId();
				artifactId.Tool = toolType;
				artifactId.ArtifactType = artifactType;
				artifactId.ToolSpecificId = toolSpecificID;

				return artifactId;
			}

			return null;
		}

		//helper for validating a collector Uri
		private static bool ValidateUri(string artifactUri, ref string toolType, ref string artifactType, ref string toolSpecificID)
		{
			bool ret = false;
			string delimStr = "/";
			char[] delimiter = delimStr.ToCharArray();
			string[] split = null;

			if (artifactUri != null && artifactUri.Length >= uriStart.Length)
			{
				//verify that the Uri starts w/ uriStart
				artifactUri = artifactUri.Substring(uriStart.Length);

				//split the uri into its components and verify that the components are well-formed
				split = artifactUri.Split(delimiter);

				//there should be a tool type, artifact type, and artifact id in the URI
				if (split != null && split.Length == 3)
				{
					ret = true;
					foreach (string element in split)
					{
						if (element == null || element.Length == 0)
						{
							ret = false;
						}
					}
				}
			}

			//if the URI is good, set the following artifact info
			if (ret)
			{
				toolType = split[0];
				artifactType = split[1];
				toolSpecificID = split[2];
			}

			return ret;
		}
	}
}
