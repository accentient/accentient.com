﻿// Copyright(c) Microsoft Corporation. All rights reserved.

#region Using directives
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.Services.Protocols;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Security.Principal;
using Microsoft.VisualStudio.Bis.Proxy;
using Microsoft.VisualStudio.Bis.Services;
namespace CollectorApp
#endregion

{
	partial class Subs : Form
	{
		IEventService esProxy;

		public Subs()
		{
			InitializeComponent();
		}

		private void Subs_Load(object sender, EventArgs e)
		{
			int i, j, k, l;

			i = lvwSubs.Width;
			j = i / 10 * 1;
			k = i / 10 * 2;
			l = i / 10 * 2;

			lvwSubs.Columns.Add("ID", j);
			lvwSubs.Columns.Add("Event Type", k);
			lvwSubs.Columns.Add("Email addr", l);
			lvwSubs.Columns.Add("Condition", -2);

			btnUnsub.Enabled = false;

			lvwSubs.View = View.Details;
			esProxy = (IEventService)CollectorContext.tfs.GetService((typeof(IEventService)));
			string user = WindowsIdentity.GetCurrent().Name;

			Subscription[] sList = esProxy.Subscriptions(user);
			foreach (Subscription s in sList)
			{
				ListViewItem lvi = lvwSubs.Items.Add(s.ID.ToString());
				lvi.SubItems.Add(s.EventType);
				lvi.SubItems.Add(s.DeliveryPreference.Address);
				lvi.SubItems.Add(s.ConditionString);

			}
			lvwSubs.Refresh();

		}

		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void lvwSubs_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (lvwSubs.SelectedItems.Count > 0)
			{
				btnUnsub.Enabled = true;
			}
			else
			{
				btnUnsub.Enabled = false;
			}
		}

		private void btnUnsub_Click(object sender, EventArgs e)
		{
			ListViewItem lvi = lvwSubs.SelectedItems[0];
			if (lvi.Text.Length > 0) 
			{
				esProxy.Unsubscribe(System.Convert.ToInt32(lvi.Text));
			}
			lvi.Remove();
			lvwSubs.Refresh();
		}
	}
}