﻿// Copyright(c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.Bis.Proxy;
using Microsoft.VisualStudio.Bis.Services;

namespace CollectorApp
{
	public class Collector : Artifact
	{
		private const string uriStart = "vstfs:///Collectibles/Collector/";

		private string projectUri;
		public string ProjectUri
		{
			get
			{ return projectUri; }
			set
			{ projectUri = value; }
		}

		


        //constructs a new Collector with the specified id and title scoped to the projectUri
        public Collector(int id, string title, string projectUri)
        {
            //create an ArtifactId to encapsulate id
            ArtifactId artifactId = new ArtifactId();
            artifactId.ArtifactType = "Collector";
            artifactId.Tool = "Collectibles";
            artifactId.ToolSpecificId = id.ToString();

            //set the artifact's URI, title, and outbound links 
            this.Uri = Collector.EncodeUri(artifactId);
            this.ArtifactTitle = title;
            this.OutboundLinks = null;

            //scope the artifact to the desired project
            ProjectUri = projectUri;
        }

        //implementing encodeURI and decodeURI methods since these are not implemented in curretn BISLinkingService dll
        //the URIs will look like:
        //vstfs:///Collectibles/Collector/ID
        public static string EncodeUri(ArtifactId artifactId) {
            if (artifactId != null && artifactId.ToolSpecificId != null)
            {
                return uriStart + artifactId.ToolSpecificId;
            }

            return null;
        }

        public static ArtifactId DecodeUri(string artifactUri) {
            if (ValidateUri(artifactUri))
            {
                ArtifactId artifactId = new ArtifactId();
                artifactId.ArtifactType = "Collector";
                artifactId.Tool = "Collectibles";
                artifactId.ToolSpecificId = artifactUri.Substring(uriStart.Length);

                return artifactId;
            }

            return null;
        }

        //helper for validating a collector Uri
        private static bool ValidateUri(string artifactUri)
        {
            return artifactUri.Substring(0, uriStart.Length).Equals(uriStart);
        }
    }
	
}
