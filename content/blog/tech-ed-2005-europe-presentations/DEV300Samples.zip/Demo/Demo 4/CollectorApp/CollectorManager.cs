﻿// Copyright(c) Microsoft Corporation. All rights reserved.

#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.Services.Protocols;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualStudio.Bis.Proxy;
using Microsoft.VisualStudio.Bis.Services;
using Microsoft.VisualStudio.TeamFoundation.Client;


#endregion

namespace CollectorApp

{
	partial class CollectorManager : Form
	{
		public CollectorManager()
		{
			InitializeComponent();
		}

		//This property is used to store the selected Collector when CollectorManager is used in 
		//"browse" mode.
		private Collector _selectedColl;
		public Collector SelectedCollector
		{
			get
			{
				return _selectedColl;
			}
		}

		//"Browse mode" enables reuse of this code as the "Collector Selector" when you're adding a link.
		//This program normally acts as the Collector Manager, but when accessed by hitting the "Browse Collectors"
		//button from the Add Link dialog it shows fewer buttons and offers a slightly different behavior.
		bool browseMode;	//true = browse mode, false = manager mode

		public DialogResult ShowDialog(bool _browseMode)
		{
			browseMode = _browseMode;
			return ShowDialog();
		}

		private void CollectorManager_Load(object sender, EventArgs e)
		{
			if (browseMode)
			{
				btnAdd.Visible = false;
				btnDelete.Visible = false;
				btnChangeProject.Visible = false;
				btnProps.Visible = false;
				btnSelect.Visible = true;
				btnSelect.Enabled = false;
				this.Text = "Collector Browser";
			}
			else
			{
				btnAdd.Visible = true;
				btnDelete.Visible = true;
				btnDelete.Enabled = false;
				btnChangeProject.Visible = true;
				btnProps.Visible = true;
				btnProps.Enabled = false;
				btnSelect.Visible = false;
				this.Text = "Collector Manager";
				if (CollectorContext.currentProject == null)
				{
					chooseProject();
				}
			}
			if (CollectorContext.currentProject != null) { displayProject(); }
		}

		private void displayProject()
		{
			if (CollectorContext.currentProject != null)
			{
				lblTeamProject.Text = CollectorContext.currentProject.Name;
				lblTeamProjectUri.Text = CollectorContext.currentProject.Uri;
				ToolTip tooltip = new ToolTip();
				tooltip.SetToolTip(lblTeamProjectUri, CollectorContext.currentProject.Uri);
				btnAdd.Enabled = true;
				loadCollectors();
			}
			else
			{
				MessageBox.Show("No project selected.", "Project Selection Failure", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				lblTeamProject.Text = "<No project selected>";
				lblTeamProjectUri.Text = "";
				ToolTip tooltip = new ToolTip();
				tooltip.SetToolTip(lblTeamProjectUri, "No project selected.");
				btnAdd.Enabled = false;
				btnDelete.Enabled = false;
			}

		}

		private void btnChangeProject_Click(object sender, EventArgs e)
		{
			chooseProject();
		}



		private void chooseProject()
		{
			//The domain picker is a pre-built Microsoft utility for selecting a domain and project.

			DomainProjectPicker domainPicker = new DomainProjectPicker(false);
			if (CollectorContext.currentDomain != null)
			{
				domainPicker.SelectedDomain = CollectorContext.currentDomain;
			}

			if (DialogResult.OK == domainPicker.ShowDialog())
			{
				CollectorContext.currentProject = null;
				CollectorContext.currentDomain = domainPicker.SelectedDomain;
				CollectorContext.tfs = TeamFoundationServerFactory.GetServer(CollectorContext.currentDomain.Name);
				ProjectInfo[] projects = domainPicker.SelectedProjects;
				if (projects.Length > 0)
				{
					CollectorContext.currentProject = projects[0];
				}
			}
			else
			{
				CollectorContext.currentProject = null;
			}

			if (CollectorContext.currentDomain != null)
			{
				//Validate that Collectibles exists on the domain here.
				CollectorContext.currentRegEnt = null;
				IRegistration regProxy = (IRegistration) CollectorContext.tfs.GetService((typeof(IRegistration)));
				RegistrationEntry[] regEntries = regProxy.GetRegistrationEntries("Collectibles");

				if (regEntries.Length != 1)
				{
					MessageBox.Show("Collectibles tool not installed on this server.", "Collectibles Absent", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					CollectorContext.currentProject = null;
				}
				else
				{
					//Get interface for Collectibles tool
					CollectorContext.currentRegEnt = regEntries[0];
					foreach (ServiceInterface si in regEntries[0].ServiceInterfaces)
					{
						if (si.Name == "CollectiblesService") CollectorContext.csUrl = si.Url;
						if (si.Name == "IToolServerLinking") CollectorContext.lsUrl = si.Url;
						if (si.Name == "IBisEnablement") CollectorContext.lsUrl = si.Url;
					}

					CollectorContext.g_CollectiblesWebService = new Service();
					CollectorContext.g_CollectiblesWebService.Url = CollectorContext.lsUrl;

					// Adding linking proxy
					CollectorContext.g_linkingProxy = (ILinking)CollectorContext.tfs.GetService((typeof(ILinking)));
					displayProject();
				}
			}
		}



		private void btnClose_Click(object sender, EventArgs e)
		{
			CollectorManager.ActiveForm.Close();
		}

		private void setColHdgs()
		{
			int i, j, k, l;

			i = lvwCollectors.Width;
			j = i / 10 * 2;
			k = i / 10 * 3;
			l = (i - (j + k)) - 4;

			lvwCollectors.Columns.Add("ID", j);
			lvwCollectors.Columns.Add("Collector Title", k);
			lvwCollectors.Columns.Add("Uri", -2);
		}

		private void loadCollectors()
		{
			lvwCollectors.Clear();
			setColHdgs();

			//Go to the Collector web service and grab an array of Collectors

			Collector[] coll = CollectorContext.g_CollectiblesWebService.GetCollectors(CollectorContext.currentProject.Uri);
			
			//Add 'em to the list view.
			for (int i = 0; i < coll.GetLength(0); i++)
			{
				Collector c = coll[i];
				ArtifactId a = ArtifactHelper.DecodeUri(c.Uri);
				ListViewItem lvi = lvwCollectors.Items.Add(a.ToolSpecificId);
				lvi.SubItems.Add(c.ArtifactTitle);
				lvi.SubItems.Add(c.Uri);
				lvi.SubItems.Add(c.ProjectUri);
				lvi.Tag = c;
			}
			lvwCollectors.Refresh();
			setColHdgs();

		}

		private void btnProps_Click(object sender, EventArgs e)
		{
			if (lvwCollectors.SelectedItems.Count > 0)
			{
				CollectorProps cp = new CollectorProps();
				Collector c = (Collector)lvwCollectors.SelectedItems[0].Tag;
				cp.ShowDialog(c);
			}

		}

		private void lvwCollectors_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (lvwCollectors.SelectedItems.Count > 0)
			{
				btnProps.Enabled = true;
				btnDelete.Enabled = true;
				btnSelect.Enabled = true;
			}
		}

		private void btnAdd_Click(object sender, EventArgs e)
		{
			AddCollector a = new AddCollector();
			a.ShowDialog();

			Collector currentCollector = a.Collector;
			if (currentCollector != null)
			{
				loadCollectors();
				ListViewItem lvi = lvwCollectors.Items[lvwCollectors.Items.Count - 1];
				lvi.Selected = true;
				lvi.EnsureVisible();
			}
		}

		private void btnSelect_Click(object sender, EventArgs e)
		//This button is only present when in "browse mode."
		{
			ListViewItem lvi = lvwCollectors.SelectedItems[0];
			_selectedColl = null;
			{
				_selectedColl = (Collector)lvi.Tag;
			}
			this.Close();
		}

		private void lvwCollectors_DoubleClick(object sender, EventArgs e)
		{
			if (browseMode)
			{
				btnSelect_Click(null, null);
			}
			else
			{
				btnProps_Click(null, null);
			}
		}

		private void btnDelete_Click(object sender, EventArgs e)
		{
			Collector coll = new Collector();
			foreach (ListViewItem lvi in lvwCollectors.SelectedItems)
			{
				coll = (Collector)lvi.Tag;
				ArtifactId a = ArtifactHelper.DecodeUri(coll.Uri);
				int i = System.Convert.ToInt32(a.ToolSpecificId);
				CollectorContext.g_CollectiblesWebService.RemoveCollector(i);
			}
			loadCollectors();

		}



	}
}