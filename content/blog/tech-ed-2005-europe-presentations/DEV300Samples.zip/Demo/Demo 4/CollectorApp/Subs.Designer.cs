﻿// Copyright(c) Microsoft Corporation. All rights reserved.

namespace CollectorApp
{
	partial class Subs
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lvwSubs = new System.Windows.Forms.ListView();
			this.btnClose = new System.Windows.Forms.Button();
			this.btnUnsub = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lvwSubs
			// 
			this.lvwSubs.FullRowSelect = true;
			this.lvwSubs.Location = new System.Drawing.Point(13, 13);
			this.lvwSubs.Name = "lvwSubs";
			this.lvwSubs.Size = new System.Drawing.Size(638, 239);
			this.lvwSubs.TabIndex = 0;
			this.lvwSubs.View = System.Windows.Forms.View.Details;
			this.lvwSubs.SelectedIndexChanged += new System.EventHandler(this.lvwSubs_SelectedIndexChanged);
			// 
			// btnClose
			// 
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnClose.Location = new System.Drawing.Point(576, 259);
			this.btnClose.Name = "btnClose";
			this.btnClose.TabIndex = 1;
			this.btnClose.Text = "Close";
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// btnUnsub
			// 
			this.btnUnsub.Location = new System.Drawing.Point(495, 259);
			this.btnUnsub.Name = "btnUnsub";
			this.btnUnsub.TabIndex = 2;
			this.btnUnsub.Text = "Unsubscribe";
			this.btnUnsub.Click += new System.EventHandler(this.btnUnsub_Click);
			// 
			// Subs
			// 
			this.AcceptButton = this.btnClose;
			this.AutoScaleDimensions = new System.Drawing.SizeF(5, 13);
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(663, 294);
			this.Controls.Add(this.btnUnsub);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.lvwSubs);
			this.Name = "Subs";
			this.Text = "Subs";
			this.Load += new System.EventHandler(this.Subs_Load);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.ListView lvwSubs;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Button btnUnsub;
	}
}