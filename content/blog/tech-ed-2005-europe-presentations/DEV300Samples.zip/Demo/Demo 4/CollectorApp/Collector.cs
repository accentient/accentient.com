﻿// Copyright(c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.Bis.Proxy;
using Microsoft.VisualStudio.Bis.Services;

namespace CollectorApp
{
	public class Collector : Artifact
	{
		private const string uriStart = "vstfs:///Collectibles/Collector/";

		private string projectUri;
		public string ProjectUri
		{
			get
			{ return projectUri; }
			set
			{ projectUri = value; }
		}

		public int id
		{
			get
			{
				ArtifactId a = ArtifactHelper.DecodeUri(this.Uri);
				return (System.Convert.ToInt32(a.ToolSpecificId));
			}
		}

		//default constructor
		public Collector()
		{
			projectUri = null;
		}

		//constructs a new Collector with the specified id and title scoped to the projectUri
		public Collector(int id, string title, string projectUri)
		{
			//create an ArtifactId to encapsulate id
			ArtifactId artifactId = new ArtifactId();
			artifactId.ArtifactType = "Collector";
			artifactId.Tool = "Collectibles";
			artifactId.ToolSpecificId = id.ToString();

			//set the artifact's URI, title, and outbound links 
			this.Uri = ArtifactHelper.EncodeUri(artifactId);
			this.ArtifactTitle = title;
			this.OutboundLinks = null;

			//scope the artifact to the desired project
			ProjectUri = projectUri;
		}

		//adds an outbound link to this
		public string AddLink(OutboundLink link)
		{
			if (link.LinkType == null || link.ReferencedUri == null)
			{
				return "Missing link type or referenced Uri";
			}

			//copy current links into temp
			if (OutboundLinks == null)
			{
				OutboundLinks = new OutboundLink[1];
				OutboundLinks[0] = link;
			}
			else
			{
				OutboundLink[] temp = new OutboundLink[this.OutboundLinks.Length];
				for (int i = 0; i < OutboundLinks.Length; i++)
				{
					temp[i] = OutboundLinks[i];
				}

				//increase OutboundLink array size by 1 and add link
				OutboundLinks = new OutboundLink[temp.Length + 1];
				for (int i = 0; i < temp.Length; i++)
				{
					OutboundLinks[i] = temp[i];
				}
				OutboundLinks[OutboundLinks.Length - 1] = link;
			}

			return "";
		}

		//removes OutboundLinks[index] from array
		public string RemoveLink(OutboundLink link)
		{
			if (OutboundLinks == null || link == null)
			{
				return "Nothing to remove.";
			}

			//copy all links but the one to be removed into temp
			if (OutboundLinks.Length == 1)
			{
				OutboundLinks = null;
			}
			else
			{
				bool found = false;
				int deleteMe = 0;

				for (int i = 0; i < OutboundLinks.Length; i++)
				{
					OutboundLink ol = OutboundLinks[i];
					if (ol.LinkType == link.LinkType && ol.ReferencedUri == link.ReferencedUri)
					{
						deleteMe = i;
						found = true;
					}
				}

				if (found)
				{
					OutboundLink[] temp = new OutboundLink[this.OutboundLinks.Length - 1];
					int tempIndex = 0;
					for (int i = 0; i < OutboundLinks.Length; i++)
					{
						if (i != deleteMe)
						{
							temp[tempIndex] = OutboundLinks[i];
							tempIndex++;
						}
					}

					OutboundLinks = temp;
				}
			}

			return null;
		}

		////implementing encodeURI and decodeURI methods since these are not implemented in curretn BISLinkingService dll
		////the URIs will look like:
		////vstfs:///Collectibles/Collector/ID
		//public static string EncodeUri(ArtifactId artifactId)
		//{
		//    if (artifactId != null && artifactId.ToolSpecificId != null)
		//    {
		//        return uriStart + artifactId.ToolSpecificId;
		//    }

		//    return null;
		//}

		//public static ArtifactId DecodeUri(string artifactUri)
		//{
		//    if (ValidateUri(artifactUri))
		//    {
		//        ArtifactId artifactId = new ArtifactId();
		//        artifactId.ArtifactType = "Collector";
		//        artifactId.Tool = "Collectibles";
		//        artifactId.ToolSpecificId = artifactUri.Substring(uriStart.Length);

		//        return artifactId;
		//    }

		//    return null;
		//}

		////helper for validating a collector Uri
		//private static bool ValidateUri(string artifactUri)
		//{
		//    if (artifactUri != null && artifactUri.Length >= uriStart.Length)
		//    {
		//        return artifactUri.Substring(0, uriStart.Length).Equals(uriStart);
		//    }

		//    return false;
		//}
	}

}
