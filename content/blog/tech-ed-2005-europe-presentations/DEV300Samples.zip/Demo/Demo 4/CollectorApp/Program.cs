﻿// Copyright(c) Microsoft Corporation. All rights reserved.

#region Using directives

using System;
using System.Collections.Generic;
using System.Windows.Forms;

#endregion

namespace CollectorApp
{
	static class Program
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			Application.EnableVisualStyles();
			//deprecated: Application.EnableRTLMirroring();
			Application.Run(new CollectorManager());
		}
	}
}