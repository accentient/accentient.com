﻿// Copyright(c) Microsoft Corporation. All rights reserved.

#region Using directives

using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualStudio.Bis.Proxy;
using Microsoft.VisualStudio.Bis.Services;
using Microsoft.VisualStudio.ELead.Common.Control;
using Microsoft.VisualStudio.TeamFoundation.Client;
using Microsoft.VisualStudio.Currituck.Client;

#endregion

namespace CollectorApp
{

	partial class AddLink : Form
	{
		Collector c;

		public AddLink()
		{
			InitializeComponent();
		}
		public DialogResult ShowDialog(Collector coll)
		{
			//Get linktypes from registration into combo box
			ArtifactType a = new ArtifactType();
			a = CollectorContext.currentRegEnt.ArtifactTypes[0];

			foreach (OutboundLinkType olt in a.OutboundLinkTypes)
			{
				cmbLinkType.Items.Add(olt.Name);
			}
			cmbLinkType.Text = cmbLinkType.Items[0].ToString();

			c = coll;
			this.Text = "Add link to " + c.ArtifactTitle;
			return this.ShowDialog();
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			AddLink.ActiveForm.Close();
		}

		private void btnOK_Click(object sender, EventArgs e)
		{

			string[] uris = new string[1];
			uris[0] = txtTargetUri.Text;
			Artifact[] a;

			try
			{
				a = CollectorContext.g_linkingProxy.GetArtifacts(uris);
				if (a[0] == null)
				{
					MessageBox.Show("Artifact " + uris[0] + " does not exist.", "Egregious Entry", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					OutboundLink ol = new OutboundLink();
					ol.LinkType = cmbLinkType.SelectedItem.ToString();
					ol.ReferencedUri = txtTargetUri.Text;
					string msg = c.AddLink(ol);
					if (msg.Length == 0)
					{
						CollectorContext.g_CollectiblesWebService.SetCollector(c);
						this.Close();
					}
					else
					{
						MessageBox.Show(msg, "Lamentable Link Lapse", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
			}
			catch (Exception x)
			{
				MessageBox.Show(x.Message, "Unsatisfactory Uri", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void btnBrowseCollectors_Click(object sender, EventArgs e)
		{
			CollectorManager cm = new CollectorManager();
			cm.ShowDialog(true);
			if (cm.SelectedCollector != null)
			{
				txtTargetUri.Text = cm.SelectedCollector.Uri;
			}
		}

		private void txtTargetUri_TextChanged(object sender, EventArgs e)
		{

		}

		private void buttonBrowseWorkItems_Click_1(object sender, EventArgs e)
		{
			WorkItemStore workItemStore = (WorkItemStore)CollectorContext.tfs.GetService((typeof(WorkItemStore)));
			WorkItemPickerDialog workItemPickerDialog = new WorkItemPickerDialog(workItemStore, false, null);

			workItemPickerDialog.PortfolioDisplayName = CollectorContext.currentProject.Name;
			workItemPickerDialog.ColumnsTabHidden = true;
			workItemPickerDialog.ColumnsTabEnabled = false;
			workItemPickerDialog.ProjectPickerControlEnabled = false;

			if (DialogResult.OK == workItemPickerDialog.ShowDialog())
			{
				ArrayList swi = workItemPickerDialog.SelectedWorkItems();
				if (swi.Count > 0)
				{
					IEnumerator enumerator = swi.GetEnumerator();
					enumerator.MoveNext();
					WorkItem wi = (WorkItem) enumerator.Current;
					txtTargetUri.Text = wi.Uri.ToString();
				}
				else
				{
					MessageBox.Show("Nothing selected.", "Work Item Picker", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				}
			}
		}


	}

}