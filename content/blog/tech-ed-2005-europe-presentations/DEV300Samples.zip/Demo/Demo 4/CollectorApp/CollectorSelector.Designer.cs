﻿// Copyright(c) Microsoft Corporation. All rights reserved.

namespace CollectorApp
{
	partial class CollectorSelector
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.lblTeamProject = new System.Windows.Forms.Label();
			this.lblTeamProjectUri = new System.Windows.Forms.Label();
			this.btnClose = new System.Windows.Forms.Button();
			this.lvwCollectors = new System.Windows.Forms.ListView();
			this.chID = new System.Windows.Forms.ColumnHeader("");
			this.chCollector = new System.Windows.Forms.ColumnHeader("");
			this.chUri = new System.Windows.Forms.ColumnHeader("");
			this.label2 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(13, 13);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(75, 14);
			this.label1.TabIndex = 1;
			this.label1.Text = "Team Project:";
			// 
			// lblTeamProject
			// 
			this.lblTeamProject.AutoSize = true;
			this.lblTeamProject.Location = new System.Drawing.Point(94, 13);
			this.lblTeamProject.Name = "lblTeamProject";
			this.lblTeamProject.Size = new System.Drawing.Size(142, 14);
			this.lblTeamProject.TabIndex = 2;
			this.lblTeamProject.Text = "<No team project selected>";
			// 
			// lblTeamProjectUri
			// 
			this.lblTeamProjectUri.AutoSize = true;
			this.lblTeamProjectUri.Location = new System.Drawing.Point(94, 33);
			this.lblTeamProjectUri.Name = "lblTeamProjectUri";
			this.lblTeamProjectUri.Size = new System.Drawing.Size(0, 0);
			this.lblTeamProjectUri.TabIndex = 7;
			// 
			// btnClose
			// 
			this.btnClose.Location = new System.Drawing.Point(465, 295);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(94, 22);
			this.btnClose.TabIndex = 8;
			this.btnClose.Text = "Close";
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// lvwCollectors
			// 
			this.lvwCollectors.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chID,
            this.chCollector,
            this.chUri});
			this.lvwCollectors.FullRowSelect = true;
			this.lvwCollectors.HideSelection = false;
			this.lvwCollectors.Location = new System.Drawing.Point(1, 61);
			this.lvwCollectors.Name = "lvwCollectors";
			this.lvwCollectors.Size = new System.Drawing.Size(565, 228);
			this.lvwCollectors.TabIndex = 9;
			this.lvwCollectors.View = System.Windows.Forms.View.Details;
			this.lvwCollectors.SelectedIndexChanged += new System.EventHandler(this.lvwCollectors_SelectedIndexChanged);
			// 
			// chID
			// 
			this.chID.Text = "ID";
			// 
			// chCollector
			// 
			this.chCollector.Text = "Collector";
			this.chCollector.Width = 293;
			// 
			// chUri
			// 
			this.chUri.Text = "CollectorUri";
			this.chUri.Width = 206;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(94, 34);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(0, 0);
			this.label2.TabIndex = 11;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(365, 295);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(94, 22);
			this.button1.TabIndex = 12;
			this.button1.Text = "Select";
			// 
			// CollectorSelector
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(566, 318);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.lvwCollectors);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.lblTeamProjectUri);
			this.Controls.Add(this.lblTeamProject);
			this.Controls.Add(this.label1);
			this.Name = "CollectorSelector";
			this.Text = "Collector Selector";
			this.Load += new System.EventHandler(this.CollectorSelector_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label lblTeamProject;
		private System.Windows.Forms.Label lblTeamProjectUri;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.ListView lvwCollectors;
		private System.Windows.Forms.ColumnHeader chID;
		private System.Windows.Forms.ColumnHeader chCollector;
		private System.Windows.Forms.ColumnHeader chUri;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button button1;

	}
}

