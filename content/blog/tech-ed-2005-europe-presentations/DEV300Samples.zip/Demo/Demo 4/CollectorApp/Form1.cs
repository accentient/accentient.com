﻿// Copyright(c) Microsoft Corporation. All rights reserved.

#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualStudio.Bis.Proxy;
using Microsoft.VisualStudio.Bis.Services;

#endregion

namespace CollectorApp
{
	partial class Form1 : Form
	{
		ProjectInfo currentProject;

		public Form1()
		{
			InitializeComponent();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			if (currentProject == null)
			{
				chooseProject();
			}

		}

		private void btnChangeProject_Click(object sender, EventArgs e)
		{
				chooseProject();
		}



		private void chooseProject()
		{
			DomainProjectPicker domainPicker = new DomainProjectPicker();
			if (DialogResult.OK == domainPicker.ShowDialog())
			{
				currentProject = null;
				BisDomain domain = domainPicker.SelectedDomain;
				ProjectInfo[] projects = domainPicker.SelectedProjects;
				if (projects.Length > 0) currentProject = projects[0];
			}
			else
			{
				currentProject = null;
			}
			if (currentProject == null)
			{
				MessageBox.Show("No project selected.", "Project Selection Failure", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				lblTeamProject.Text = "<No project selected>";
				//lblTeamProjectUri.Text = "";
				btnAdd.Enabled = false;
				btnDelete.Enabled = false;
			}
			else
			{
				lblTeamProject.Text = currentProject.Name;
				ToolTip tooltip = new ToolTip();
				tooltip.SetToolTip(lblTeamProject, currentProject.Uri);
				//lblTeamProjectUri.Text = currentProject.Uri;
				btnAdd.Enabled = true;
				btnDelete.Enabled = true;
			}
		}



		private void btnClose_Click(object sender, EventArgs e)
		{
			Form1.ActiveForm.Close();
		}



	}
}