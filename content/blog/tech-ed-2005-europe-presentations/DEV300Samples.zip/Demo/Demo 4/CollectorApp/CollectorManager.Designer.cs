﻿// Copyright(c) Microsoft Corporation. All rights reserved.

namespace CollectorApp
{
	partial class CollectorManager
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnChangeProject = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.lblTeamProject = new System.Windows.Forms.Label();
			this.btnAdd = new System.Windows.Forms.Button();
			this.btnDelete = new System.Windows.Forms.Button();
			this.lblTeamProjectUri = new System.Windows.Forms.Label();
			this.btnClose = new System.Windows.Forms.Button();
			this.lvwCollectors = new System.Windows.Forms.ListView();
			this.chID = new System.Windows.Forms.ColumnHeader("");
			this.chCollector = new System.Windows.Forms.ColumnHeader("");
			this.chUri = new System.Windows.Forms.ColumnHeader("");
			this.btnProps = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.btnSelect = new System.Windows.Forms.Button();
			this.service1 = new Service();
			this.SuspendLayout();
			// 
			// btnChangeProject
			// 
			this.btnChangeProject.Location = new System.Drawing.Point(305, 295);
			this.btnChangeProject.Name = "btnChangeProject";
			this.btnChangeProject.Size = new System.Drawing.Size(94, 22);
			this.btnChangeProject.TabIndex = 0;
			this.btnChangeProject.Text = "Change Project...";
			this.btnChangeProject.Click += new System.EventHandler(this.btnChangeProject_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(13, 13);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(75, 14);
			this.label1.TabIndex = 1;
			this.label1.Text = "Team Project:";
			// 
			// lblTeamProject
			// 
			this.lblTeamProject.AutoSize = true;
			this.lblTeamProject.Location = new System.Drawing.Point(94, 13);
			this.lblTeamProject.Name = "lblTeamProject";
			this.lblTeamProject.Size = new System.Drawing.Size(142, 14);
			this.lblTeamProject.TabIndex = 2;
			this.lblTeamProject.Text = "<No team project selected>";
			// 
			// btnAdd
			// 
			this.btnAdd.Enabled = false;
			this.btnAdd.Location = new System.Drawing.Point(1, 295);
			this.btnAdd.Name = "btnAdd";
			this.btnAdd.Size = new System.Drawing.Size(94, 22);
			this.btnAdd.TabIndex = 4;
			this.btnAdd.Text = "Add Collector...";
			this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
			// 
			// btnDelete
			// 
			this.btnDelete.Enabled = false;
			this.btnDelete.Location = new System.Drawing.Point(103, 295);
			this.btnDelete.Name = "btnDelete";
			this.btnDelete.Size = new System.Drawing.Size(94, 22);
			this.btnDelete.TabIndex = 5;
			this.btnDelete.Text = "Delete Collector";
			this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
			// 
			// lblTeamProjectUri
			// 
			this.lblTeamProjectUri.AutoSize = true;
			this.lblTeamProjectUri.Location = new System.Drawing.Point(94, 33);
			this.lblTeamProjectUri.Name = "lblTeamProjectUri";
			this.lblTeamProjectUri.Size = new System.Drawing.Size(0, 0);
			this.lblTeamProjectUri.TabIndex = 7;
			// 
			// btnClose
			// 
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnClose.Location = new System.Drawing.Point(465, 295);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(94, 22);
			this.btnClose.TabIndex = 8;
			this.btnClose.Text = "Close";
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// lvwCollectors
			// 
			this.lvwCollectors.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chID,
            this.chCollector,
            this.chUri});
			this.lvwCollectors.FullRowSelect = true;
			this.lvwCollectors.HideSelection = false;
			this.lvwCollectors.Location = new System.Drawing.Point(1, 61);
			this.lvwCollectors.Name = "lvwCollectors";
			this.lvwCollectors.Size = new System.Drawing.Size(565, 228);
			this.lvwCollectors.TabIndex = 9;
			this.lvwCollectors.View = System.Windows.Forms.View.Details;
			this.lvwCollectors.SelectedIndexChanged += new System.EventHandler(this.lvwCollectors_SelectedIndexChanged);
			this.lvwCollectors.DoubleClick += new System.EventHandler(this.lvwCollectors_DoubleClick);
			// 
			// chID
			// 
			this.chID.Text = "ID";
			// 
			// chCollector
			// 
			this.chCollector.Text = "Collector";
			this.chCollector.Width = 293;
			// 
			// chUri
			// 
			this.chUri.Text = "CollectorUri";
			this.chUri.Width = 206;
			// 
			// btnProps
			// 
			this.btnProps.Enabled = false;
			this.btnProps.Location = new System.Drawing.Point(205, 295);
			this.btnProps.Name = "btnProps";
			this.btnProps.Size = new System.Drawing.Size(94, 22);
			this.btnProps.TabIndex = 10;
			this.btnProps.Text = "Properties...";
			this.btnProps.Click += new System.EventHandler(this.btnProps_Click);
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(94, 34);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(0, 0);
			this.label2.TabIndex = 11;
			// 
			// btnSelect
			// 
			this.btnSelect.Location = new System.Drawing.Point(365, 295);
			this.btnSelect.Name = "btnSelect";
			this.btnSelect.Size = new System.Drawing.Size(94, 22);
			this.btnSelect.TabIndex = 12;
			this.btnSelect.Text = "Select";
			this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
			// 
			// service1
			// 
			this.service1.Credentials = null;
			this.service1.SoapVersion = System.Web.Services.Protocols.SoapProtocolVersion.Default;
			this.service1.UnsafeAuthenticatedConnectionSharing = false;
			this.service1.Url = "http://vse1120:11791/service.asmx";
			this.service1.UseDefaultCredentials = false;
			this.service1.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; MS Web Services Client Protocol 2.0.41115.15)";
			// 
			// CollectorManager
			// 
			this.AcceptButton = this.btnClose;
			this.AutoScaleDimensions = new System.Drawing.SizeF(5, 13);
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(566, 318);
			this.Controls.Add(this.btnSelect);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.btnProps);
			this.Controls.Add(this.lvwCollectors);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.lblTeamProjectUri);
			this.Controls.Add(this.btnDelete);
			this.Controls.Add(this.btnAdd);
			this.Controls.Add(this.lblTeamProject);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnChangeProject);
			this.Name = "CollectorManager";
			this.Text = "Collector Manager";
			this.Load += new System.EventHandler(this.CollectorManager_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnChangeProject;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label lblTeamProject;
		private System.Windows.Forms.Button btnAdd;
		private System.Windows.Forms.Button btnDelete;
		private System.Windows.Forms.Label lblTeamProjectUri;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.ListView lvwCollectors;
		private System.Windows.Forms.ColumnHeader chID;
		private System.Windows.Forms.ColumnHeader chCollector;
		private System.Windows.Forms.ColumnHeader chUri;
		private System.Windows.Forms.Button btnProps;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button btnSelect;
		private Service service1;

	}
}

