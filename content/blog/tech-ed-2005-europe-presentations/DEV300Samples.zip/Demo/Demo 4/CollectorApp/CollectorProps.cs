﻿// Copyright(c) Microsoft Corporation. All rights reserved.

#region Using directives

using System;
using System.Security.Principal;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualStudio.Bis.Proxy;
using Microsoft.VisualStudio.Bis.Services;
using Microsoft.VisualStudio.TeamFoundation.Client;
using Microsoft.VisualStudio.Bis.BisEnablement;//remove
#endregion

namespace CollectorApp
{
	partial class CollectorProps : Form
	{
		Collector c;
		IEventService esProxy;
		bool readyToRoll;

		public CollectorProps()
		{
			InitializeComponent();
		}

		public DialogResult ShowDialog(Collector coll)
		{
			readyToRoll = false;
			esProxy = (IEventService)CollectorContext.tfs.GetService((typeof(IEventService)));

			c = coll;
			ArtifactId a = ArtifactHelper.DecodeUri(c.Uri);
			this.Text = "Properties for Collector " + a.ToolSpecificId;
			this.lblID.Text = a.ToolSpecificId;
			this.txtName.Text = c.ArtifactTitle;
			this.lblUri.Text = c.Uri;

			loadRefersTo();
			loadReferencedBy();

			loadAlert();

			readyToRoll = true;
			return base.ShowDialog();
		}

		private void loadRefersTo()
		{
			lvwRefers.Clear();
			setRefersColHdgs();
			if (c.OutboundLinks != null)
			{
				string[] sList = new string[c.OutboundLinks.Length];
				for (int i = 0; i < c.OutboundLinks.Length; i++)
				{
					//Build array of Uris for GetArtifacts
					sList[i] = c.OutboundLinks[i].ReferencedUri;
				}

				Artifact[] aList = null;
				try
				{
					//Get the artifacts.  This call invokes the TFS linking proxy which in turn calls
					//the collectors web service.  If this GetArtifacts call included artifacts returned by 
					//multiple tool, each tool's GetArtifacts method would be called by the TFS linking proxy.

					aList = CollectorContext.g_linkingProxy.GetArtifacts(sList);
				}
				catch (Exception)
				{
				}

				//Build list view by synchronized iteration through
				//OutboundLinks for LinkType and Artifacts for artiface details.
				for (int i = 0; i < c.OutboundLinks.Length; i++)
				{
					ListViewItem lvi = lvwRefers.Items.Add(c.OutboundLinks[i].LinkType);
					lvi.Tag = c.OutboundLinks[i];

					if (aList != null && aList[i] != null)
					{
						//Extract artifact type and tool-specific ID from Uri
						ArtifactId id = ArtifactHelper.DecodeUri(aList[i].Uri);
						lvi.SubItems.Add(id.ArtifactType);
						lvi.SubItems.Add(id.ToolSpecificId);
						lvi.SubItems.Add(aList[i].ArtifactTitle);
					}
					else
					{
						lvi.SubItems.Add("???");
						lvi.SubItems.Add("???");
						lvi.SubItems.Add("This item cannot be found. It may have been deleted.");
					}

				}
				lvwRefers.Refresh();
			}
		}

		private void loadReferencedBy()
		{
			lvwReferenced.Clear();
			setReferencedColHdgs();
			string[] sList = new string[1];
			sList[0] = c.Uri;
			try
			{
				//Get the referencing artifacts

				//The following line is commented out (using #if false...#endif) because of a TFS bug in Beta 2 that causes the 
				//linking proxy (_g_linkingProxy)to fail to contact the Collectors web service.  Instead 
				//we use the next uncommented line which accesses the Collectibles Web Service directly.
				//Artifact[] aList = CollectorContext.g_linkingProxy.GetReferencingArtifacts(sList);
				Artifact[] aList = CollectorContext.g_CollectiblesWebService.GetReferencingArtifacts(sList);

				if (aList != null)
				{
					foreach (Artifact a in aList)
					{
						//Find the specific backward pointers from each artifact
						//so that LinkType is correct
						foreach (OutboundLink ol in a.OutboundLinks)
						{
							if (ol.ReferencedUri == c.Uri)
							{
								ListViewItem lvi = lvwReferenced.Items.Add(ol.LinkType);

								//Extract artifact type and tool-specific ID from Uri
								ArtifactId id = ArtifactHelper.DecodeUri(a.Uri);
								lvi.SubItems.Add(id.ArtifactType);
								lvi.SubItems.Add(id.ToolSpecificId);
								lvi.SubItems.Add(a.ArtifactTitle);
							}
						}
					}
				}
				lvwReferenced.Refresh();
			}
			catch (Exception x)
			{
				MessageBox.Show(x.Message, "'Referenced By' Artifact Retrieval Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void loadAlert()
		{
			Subscription s = new Subscription();
			s = findSub();
			if (s == null)
			{
				chkAlert.Checked = false;
				txtEmail.Text = "N/A";
			}
			else
			{
				chkAlert.Checked = true;
				txtEmail.Text = s.DeliveryPreference.Address;
			}
		}

		private void chkAlert_CheckedChanged(object sender, EventArgs e)
		{
			if (readyToRoll)
			{
				if (chkAlert.Checked == true)
				{
					string user = WindowsIdentity.GetCurrent().Name;
					SetEmailAddr f = new SetEmailAddr();
					f.ShowDialog(user);
					txtEmail.Text = f.addr;
					if (txtEmail.Text.Length > 0)
					{

						DeliveryPreference dp = new DeliveryPreference();
						dp.Address = f.addr;
						dp.Schedule = DeliverySchedule.Immediate;
						dp.Type = DeliveryType.EmailHtml;

						string uriString = "ArtifactUri = " + '\u0022' + c.Uri + '\u0022';


						esProxy.Subscribe(user, "ArtifactChangedEvent", uriString, dp);
					}
				}
				else
				{
					//find subscription and delete it
					Subscription s = findSub();
					if (s != null)
					{
						esProxy.Unsubscribe(s.ID);
					}
				}
			}
		}


		private void btnAddLink_Click(object sender, EventArgs e)
		{
			AddLink al = new AddLink();
			al.ShowDialog(c);

			CollectorContext.g_CollectiblesWebService.GetCollector(c.id);
			loadRefersTo();

		}

		private void btnClose_Click(object sender, EventArgs e)
		{
			CollectorProps.ActiveForm.Close();
		}


		private void setRefersColHdgs()
		{
			int i, j, k, l;

			i = lvwRefers.Width;
			j = i / 10 * 2;
			k = i / 10 * 2;
			l = i / 10 * 2;

			lvwRefers.Columns.Add("Link Type", j);
			lvwRefers.Columns.Add("Type", k);
			lvwRefers.Columns.Add("Id", l);
			lvwRefers.Columns.Add("Title", -2);
		}

		private void setReferencedColHdgs()
		{
			int i, j, k, l;

			i = lvwRefers.Width;
			j = i / 10 * 2;
			k = i / 10 * 2;
			l = i / 10 * 2;

			lvwReferenced.Columns.Add("Link Type", j);
			lvwReferenced.Columns.Add("Type", k);
			lvwReferenced.Columns.Add("Id", l);
			lvwReferenced.Columns.Add("Title", -2);
		}

		private void CollectorProps_Load(object sender, EventArgs e)
		{
			btnRemove.Enabled = false;
		}

		private void btnRemove_Click(object sender, EventArgs e)
		{
			for (int i = 0; i < lvwRefers.SelectedItems.Count; i++)
			{
				ListViewItem lvi = lvwRefers.SelectedItems[i];
				c.RemoveLink((OutboundLink)lvi.Tag);
			}
			CollectorContext.g_CollectiblesWebService.SetCollector(c);
			loadRefersTo();
		}

		private void lvwRefers_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (lvwRefers.SelectedItems.Count > 0)
			{
				btnRemove.Enabled = true;
			}
			else
			{
				btnRemove.Enabled = false;
			}
		}

		private void btnSubs_Click(object sender, EventArgs e)
		{
			Subs subs = new Subs();
			subs.ShowDialog();
		}

		private Subscription findSub()
		{
			Subscription sub = new Subscription();
			IEventService esProxy = (IEventService)CollectorContext.tfs.GetService((typeof(IEventService)));
			string user = WindowsIdentity.GetCurrent().Name;

			Subscription[] subs = esProxy.Subscriptions(user);
			sub = null;
			string uriString = "ArtifactUri = \"" + c.Uri + "\"";

			foreach (Subscription s in subs)
			{
				if (uriString == s.ConditionString)
				{
					sub = s;
				}
			}
			return sub;
		}
	}
}