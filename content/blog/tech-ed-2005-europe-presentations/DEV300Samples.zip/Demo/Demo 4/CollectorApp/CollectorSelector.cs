﻿// Copyright(c) Microsoft Corporation. All rights reserved.

#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualStudio.Bis.Proxy;
using Microsoft.VisualStudio.Bis.Services;
using Microsoft.VisualStudio.TeamFoundation.Client;

#endregion

namespace CollectorApp
{
	partial class CollectorSelector : Form
	{
		private TeamFoundationServer tfs;
		private Collector c;

		private Collector _selectedCollector;
		public Collector selectedCollector
		{
			get
			{
				return _selectedCollector;
			}
		}	

		public CollectorSelector()
		{
			InitializeComponent();
		}

		private void CollectorSelector_Load(object sender, EventArgs e)
		{
			if (currentProject == null)
			{
				loadProject();
			}

		}

		public DialogResult ShowDialog(Collector _c,TeamFoundationServer _tfs)
		{
			tfs = _tfs;
			c = _c;

			//First, find project name
			foreach (TeamProject tp  in tfs.TeamProjects)
			{
				if (tp.Id == c.ProjectUri)
				{
					lblTeamProject.Text = tp.Name;
				}
			}

			lblTeamProjectUri.Text = currentProject.Uri;
			ToolTip tooltip = new ToolTip();
			tooltip.SetToolTip(lblTeamProjectUri, currentProject.Uri);
			loadCollectors();

		}



		private void btnClose_Click(object sender, EventArgs e)
		{
			_selectedCollector = null;
			CollectorSelector.ActiveForm.Close();
		}

		private void setColHdgs()
		{
			lvwCollectors.Clear();
			int i, j, k, l;

			i = lvwCollectors.Width;
			j = i / 10 * 2;
			k = i / 10 * 3;
			l = (i - (j + k)) - 4;

			lvwCollectors.Columns.Add("ID", j);
			lvwCollectors.Columns.Add("Collector Title", k);
			lvwCollectors.Columns.Add("Uri", -2);
		}

		private void loadCollectors()
		{
			lvwCollectors.Clear();
			setColHdgs();
			dummyCollectors = null;

			//First, go to the Collector web service and grab an array of Collectors
			Collector[] coll = getCollectors(currentProject.Uri);
			for (int i = 0; i < coll.GetLength(0); i++)
			{
				Collector c = coll[i];
				ArtifactId a = Collector.DecodeUri(c.Uri);
				ListViewItem lvi = lvwCollectors.Items.Add(a.ToolSpecificId);
				lvi.SubItems.Add(c.ArtifactTitle);
				lvi.SubItems.Add(c.Uri);
				lvi.SubItems.Add(c.ProjectUri);
				lvi.Tag = c;
			}
		}
		//Dummy implementation of getCollectors.
		public Collector[] getCollectors(string projectUri)
		{

			int i;

			if (dummyCollectors == null) buildDummyCollectors();

			Collector[] myColl = new Collector[dummyCollectors.Length];
			for (i = 0; i < dummyCollectors.Length; i++)
			{
				myColl[i] = dummyCollectors[i];
			}
			return myColl;
		}

		private void buildDummyCollectors()
		{
			int i, j, limit;
			limit = 5;		//Number of dummy collectors to build
			dummyCollectors = null;
			dummyCollectors = new Collector[5];

			for (i = 0; i < limit; i++)
			{
				j = i + 1;
				Collector c = new Collector(j, "Project " + currentProject.Name + " - " + j.ToString(), currentProject.Uri);
				dummyCollectors[i] = c;
				//How can I add outbound links?
			}
		}

		private void btnProps_Click(object sender, EventArgs e)
		{
			if (lvwCollectors.SelectedItems.Count > 0)
			{
				CollectorProps cp = new CollectorProps();
				Collector c = (Collector)lvwCollectors.SelectedItems[0].Tag;
				if (cp.ShowDialog(c, tfs) == DialogResult.OK)
				{
					MessageBox.Show("Whoopppeeee!");
				}
			}

		}

		private void lvwCollectors_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (lvwCollectors.SelectedItems.Count = 1)
			{
				btnProps.Enabled = true;
			}
		}

		
	}
}