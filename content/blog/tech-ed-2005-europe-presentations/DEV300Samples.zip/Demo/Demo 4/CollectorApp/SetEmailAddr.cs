﻿// Copyright(c) Microsoft Corporation. All rights reserved.

#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualStudio.Bis.Proxy;
using Microsoft.VisualStudio.Bis.Services;

#endregion

namespace CollectorApp
{
	partial class SetEmailAddr : Form
	{
		public SetEmailAddr()
		{
			InitializeComponent();
		}


		private string _addr;
		public string addr
		{
			get
			{
				return _addr;
			}
		}

		private void SetEmailAddr_Load(object sender, EventArgs e)
		{
			btnOK.Enabled = true;
		}
		public DialogResult ShowDialog(string user)
		{
			string s = user;
			int i = user.LastIndexOf('\u005c');
			if (i > 0)
			{
				s = user.Substring(i + 1);
			}
			textBox1.Text = s + "@microsoft.com";

			return base.ShowDialog();
		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{
			if (textBox1.Text.Length > 0)
			{
				btnOK.Enabled = true;
			}
			else
			{
				btnOK.Enabled = false;
			}
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			_addr = textBox1.Text;
			this.Close();
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			_addr = "";
			this.Close();
		}
	}
}