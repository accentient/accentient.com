﻿// Copyright(c) Microsoft Corporation. All rights reserved.

#region Using directives


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualStudio.Bis.Proxy;
using Microsoft.VisualStudio.Bis.Services;
using Microsoft.VisualStudio.ELead.Common.Control;
using Microsoft.VisualStudio.TeamFoundation.Client;
using Microsoft.VisualStudio.Currituck.Client;
#endregion

namespace CollectorApp
{
	public static class CollectorContext
	{
		public static RegistrationEntry currentRegEnt;
		public static BisDomain currentDomain;
		public static ProjectInfo currentProject;
		public static TeamFoundationServer tfs;
		public static string csUrl;
		public static string lsUrl;
		public static Service g_CollectiblesWebService;	//Collectibles App Tier
		public static ILinking g_linkingProxy;
	}
}
