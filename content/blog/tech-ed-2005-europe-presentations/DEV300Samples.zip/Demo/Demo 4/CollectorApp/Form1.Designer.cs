﻿// Copyright(c) Microsoft Corporation. All rights reserved.

namespace CollectorApp
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnChangeProject = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.lblTeamProject = new System.Windows.Forms.Label();
			this.btnAdd = new System.Windows.Forms.Button();
			this.btnDelete = new System.Windows.Forms.Button();
			this.lblTeamProjectUri = new System.Windows.Forms.Label();
			this.btnClose = new System.Windows.Forms.Button();
			this.lvwCollectors = new System.Windows.Forms.ListView();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader("");
			this.columnHeader2 = new System.Windows.Forms.ColumnHeader("");
			this.SuspendLayout();
			// 
			// btnChangeProject
			// 
			this.btnChangeProject.Location = new System.Drawing.Point(253, 305);
			this.btnChangeProject.Name = "btnChangeProject";
			this.btnChangeProject.Size = new System.Drawing.Size(106, 23);
			this.btnChangeProject.TabIndex = 0;
			this.btnChangeProject.Text = "Change Project...";
			this.btnChangeProject.Click += new System.EventHandler(this.btnChangeProject_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(13, 13);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(75, 14);
			this.label1.TabIndex = 1;
			this.label1.Text = "Team Project:";
			// 
			// lblTeamProject
			// 
			this.lblTeamProject.AutoSize = true;
			this.lblTeamProject.Location = new System.Drawing.Point(13, 34);
			this.lblTeamProject.Name = "lblTeamProject";
			this.lblTeamProject.Size = new System.Drawing.Size(142, 14);
			this.lblTeamProject.TabIndex = 2;
			this.lblTeamProject.Text = "<No team project selected>";
			// 
			// btnAdd
			// 
			this.btnAdd.Location = new System.Drawing.Point(30, 305);
			this.btnAdd.Name = "btnAdd";
			this.btnAdd.Size = new System.Drawing.Size(106, 23);
			this.btnAdd.TabIndex = 4;
			this.btnAdd.Text = "Add Collector...";
			// 
			// btnDelete
			// 
			this.btnDelete.Location = new System.Drawing.Point(141, 305);
			this.btnDelete.Name = "btnDelete";
			this.btnDelete.Size = new System.Drawing.Size(106, 23);
			this.btnDelete.TabIndex = 5;
			this.btnDelete.Text = "Delete Collector";
			// 
			// lblTeamProjectUri
			// 
			this.lblTeamProjectUri.AutoSize = true;
			this.lblTeamProjectUri.Location = new System.Drawing.Point(12, 54);
			this.lblTeamProjectUri.Name = "lblTeamProjectUri";
			this.lblTeamProjectUri.Size = new System.Drawing.Size(0, 0);
			this.lblTeamProjectUri.TabIndex = 7;
			// 
			// btnClose
			// 
			this.btnClose.Location = new System.Drawing.Point(272, 350);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(106, 23);
			this.btnClose.TabIndex = 8;
			this.btnClose.Text = "Close";
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// lvwCollectors
			// 
			this.lvwCollectors.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
			this.lvwCollectors.IsBackgroundImageTiled = false;
			this.lvwCollectors.Location = new System.Drawing.Point(17, 58);
			this.lvwCollectors.Name = "lvwCollectors";
			this.lvwCollectors.Size = new System.Drawing.Size(361, 228);
			this.lvwCollectors.TabIndex = 9;
			this.lvwCollectors.View = System.Windows.Forms.View.Details;
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "ID";
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "Collector";
			this.columnHeader2.Width = 299;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(390, 387);
			this.Controls.Add(this.lvwCollectors);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.lblTeamProjectUri);
			this.Controls.Add(this.btnDelete);
			this.Controls.Add(this.btnAdd);
			this.Controls.Add(this.lblTeamProject);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnChangeProject);
			this.Name = "Form1";
			this.Text = "Collector Manager";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnChangeProject;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label lblTeamProject;
		private System.Windows.Forms.Button btnAdd;
		private System.Windows.Forms.Button btnDelete;
		private System.Windows.Forms.Label lblTeamProjectUri;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.ListView lvwCollectors;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ColumnHeader columnHeader2;

	}
}

