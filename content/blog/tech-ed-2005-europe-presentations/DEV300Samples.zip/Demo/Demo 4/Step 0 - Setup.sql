CREATE DATABASE Collectibles
GO

USE Collectibles
GO

create table CollectorStore
(
ID int identity not null primary key clustered,
Title nvarchar(255) not null,
ProjectURI nvarchar(255) not null
)
 
create table OutgoingLinks
(
ID int identity not null primary key clustered,
CollectorId int not null foreign key references CollectorStore(ID),
URI nvarchar(255) not null, 
LinkType nvarchar(50) not null,
CONSTRAINT constraintLinkType CHECK (LinkType = 'Holds' or LinkType = 'Points To')
)