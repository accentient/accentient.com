<?xml version='1.0'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
  <xsl:template match="ArtifactChangedEvent">

The following artifact has changed. 

ID: <xsl:value-of select="Artifact/ExternalId" />
Title: <xsl:value-of select="Artifact/ArtifactTitle" />
URI: <xsl:value-of select="ArtifactUri" />
ChangeType: <xsl:value-of select="ChngType" />
      
  </xsl:template>
</xsl:stylesheet>