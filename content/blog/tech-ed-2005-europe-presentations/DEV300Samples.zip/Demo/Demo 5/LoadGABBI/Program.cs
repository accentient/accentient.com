// Need to reference: C:\Program Files\Visual Studio 2005 Team System Extensibility Kit Beta 2\Work Item Tracking\Work Item Object Model Sample\CurrituckSamples\bin\Microsoft.VisualStudio.Currituck.Client.dll
// Need to reference: C:\Program Files\Visual Studio 2005 Team System Extensibility Kit Beta 2\Work Item Tracking\Work Item Object Model Sample\CurrituckSamples\bin\Microsoft.VisualStudio.TeamFoundation.Client.dll

using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Security.Principal;
using System.Runtime.InteropServices;
using Microsoft.VisualStudio.TeamFoundation.Client;
using Microsoft.VisualStudio.Currituck.Client;

// Manual: Create GABBI Team Project

// Manual: Create Area Paths
//
//   Project Management (OU)
//     Requirements (OU)
//   Architecture (OU)
//     Infrastructure (OU)
//   Development (OU)
//     Software (OU)
//   Testing (OU)

// Manual: Create Iterations
//
//   Alpha
//   Beta
//   Release

// Manual: Manually link documents and associate work items

namespace LoadGABBI
{
	class Program
	{

		static void Main(string[] args)
		{

			AddWorkItem("GABBIPM", "Scenario", "Create a new Blog", "Active", "GABBISA", DateTime.Today.AddDays(-30), "Development", @"\Development", @"\Alpha");
			AddWorkItem("GABBIPM", "Scenario", "View a Blog", "Active", "GABBISA", DateTime.Today.AddDays(-30), "Development", @"\Development", @"\Alpha");
			AddWorkItem("GABBIPM", "Scenario", "Add Blog entries", "Active", "GABBISA", DateTime.Today.AddDays(-30), "Development", @"\Development", @"\Alpha");
			AddWorkItem("GABBIPM", "Quality of Service Requirement", "Response time must be 8 seconds or less", "Active", "GABBITest", DateTime.Today.AddDays(-29), "Performance", @"\Testing", @"\Alpha");
			AddWorkItem("GABBIPM", "Quality of Service Requirement", "5 or more simultaneous users must be supported", "Active", "GABBITest", DateTime.Today.AddDays(-29), "Performance", @"\Testing", @"\Alpha");
			AddWorkItem("GABBIPM", "Task", "Create the GABBI Logical Datacenter Diagram", "Active", "GABBIIA", DateTime.Today.AddDays(-27), "Development", @"\Architecture\Infrastructure", @"\Alpha");
			AddWorkItem("GABBIPM", "Task", "Create the GABBI Application Diagram", "Active", "GABBISA", DateTime.Today.AddDays(-27), "Development", @"\Development", @"\Alpha");
			AddWorkItem("GABBIPM", "Task", "Create the GABBI Deployment Diagram", "Active", "GABBIIA", DateTime.Today.AddDays(-27), "Development", @"\Architecture", @"\Alpha");
			AddWorkItem("GABBIPM", "Task", "Fax whiteboard photo to sponsor", "Active", "GABBISA", DateTime.Today.AddDays(-27), "Project Management", @"\Development", @"\Alpha");

			AddWorkItem("GABBISA", "Task", "Fax whiteboard photo to sponsor", "Active", "GABBIDev1", DateTime.Today.AddDays(-21), "Project Management", @"\Development", @"\Alpha");
			AddWorkItem("GABBISA", "Task", "Build a Web Service to create a new blog", "Active", "GABBIDev1", DateTime.Today.AddDays(-24), "Development", @"\Development", @"\Alpha");
			AddWorkItem("GABBISA", "Task", "Create a Web Service to add blog entries", "Active", "GABBIDev1", DateTime.Today.AddDays(-23), "Development", @"\Development", @"\Alpha");
			AddWorkItem("GABBISA", "Task", "Create a Web Service to return an entire blog as XML", "Active", "GABBIDev2", DateTime.Today.AddDays(-23), "Development", @"\Development", @"\Alpha");
			AddWorkItem("GABBISA", "Task", "Implement Web Service as a project", "Active", "GABBIDev1", DateTime.Today.AddDays(-24), "Development", @"\Development", @"\Alpha");
			AddWorkItem("GABBISA", "Task", "Implement Web Service as a project", "Active", "GABBIDev2", DateTime.Today.AddDays(-24), "Development", @"\Development", @"\Alpha");
			AddWorkItem("GABBISA", "Task", "Implement the GABBI Web site", "Active", "GABBIDev2", DateTime.Today.AddDays(-23), "Development", @"\Development", @"\Alpha");
			AddWorkItem("GABBISA", "Task", "Associate GABBI Web service with GABBI Web site", "Active", "GABBISA", DateTime.Today.AddDays(-23), "Development", @"\Development", @"\Alpha");
			AddWorkItem("GABBISA", "Scenario", "User visits GABBI Web site", "Active", "GABBIDev2", DateTime.Today.AddDays(-25), "Development", @"\Development", @"\Alpha");

			for (int i = 1; i < 6; i++)
			{
				AddWorkItem("PM1", "Task", "Run unit tests on GABBI", "Active", "Dev" + i.ToString(), DateTime.Today.AddDays(-10), "Development", @"\Development", @"\Alpha");
				AddWorkItem("PM1", "Task", "Perform code coverage analyis on GABBI", "Active", "Dev" + i.ToString(), DateTime.Today.AddDays(-10), "Development", @"\Development", @"\Alpha");
			}
			for (int i = 1; i < 4; i++)
			{
				AddWorkItem("PM1", "Task", "Run unit tests on GABBI", "Active", "Test" + i.ToString(), DateTime.Today.AddDays(-10), "Development", @"\Development", @"\Alpha");
				AddWorkItem("PM1", "Task", "Perform code coverage analyis on GABBI", "Active", "Test" + i.ToString(), DateTime.Today.AddDays(-10), "Development", @"\Development", @"\Alpha");
			}

			AddWorkItem("PM1", "Task", "Create the GABBI Logical Datacenter Diagram", "Active", "IA1", DateTime.Today.AddDays(-10), "Development", @"\Architecture\Infrastructure", @"\Alpha");
			AddWorkItem("PM1", "Task", "Create the GABBI Application Diagram", "Active", "SA1", DateTime.Today.AddDays(-10), "Development", @"\Development", @"\Alpha");
			// AddWorkItem("PM1", "Task", "Create the GABBI Deployment Diagram", "Active", "IA1", DateTime.Today.AddDays(-10), "Development", @"\Architecture", @"\Alpha");

			for (int i = 1; i < 6; i++)
			{
				AddWorkItem("SA1", "Task", "GABBI fails code analysis test. Please investigate", "Active", "Dev" + i.ToString(), DateTime.Today.AddDays(-10), "Development", @"\Development", @"\Alpha");
			}
			for (int i = 1; i < 4; i++)
			{
				AddWorkItem("SA1", "Task", "Conduct a load test of GABBI (using the exiting BlogObjectsLoadTest)", "Active", "Test" + i.ToString(), DateTime.Today.AddDays(-10), "Development", @"\Development", @"\Alpha");
			}

			// Done

			Console.Write("Press ENTER to continue ...");
			Console.ReadLine();
		}

		private static void AddWorkItem(string AssignedBy,string type,string title, string state, string assignedTo, DateTime createdDate, string disciplineOrType, string areaPath, string iterationPath)
		{

			// Attempting

			Console.Write("{0}, <{1}>, {2} ... ",type,title.Substring(0,10),assignedTo);

			// TFS

			TeamFoundationServer tfs = new TeamFoundationServer("wbserver",
				new System.Net.NetworkCredential(AssignedBy, "P@ssw0rd", "WOODGROVE"));
			string project = "GABBI";
			WorkItemStore store = (WorkItemStore)tfs.GetService(typeof(WorkItemStore));

			// Add Work Item

			WorkItemType taskType = store.Projects[project].WorkItemTypes[type];
			WorkItem item = new WorkItem(store, taskType);
			item.Title = title;
			item.State = state;
			item.Fields["Assigned To"].Value = assignedTo;
			item.Fields["Created Date"].Value = createdDate.ToShortDateString();
			if (type.ToUpper() != "SCENARIO")
			{
				if (type.ToUpper() == "QUALITY OF SERVICE REQUIREMENT")
				{
					item.Fields["Quality of Service Type"].Value = disciplineOrType;
				}
					else
				{
					item.Fields["Discipline"].Value = disciplineOrType;
				}
			}
			item.Fields["Area Path"].Value = areaPath;
			item.Fields["Iteration Path"].Value = iterationPath;

			// Save and report

			item.Save();
			Console.WriteLine("Success! #{0}", item.Id);
		}
	}
}
