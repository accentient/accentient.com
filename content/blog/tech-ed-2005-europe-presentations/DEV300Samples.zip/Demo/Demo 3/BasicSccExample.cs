//*************************************************************************************************
// BasicPolicySample.cs
//
// Shows some basic operations of the Team Foundation Source Control Object model.  This sample
// will connect to the server, create a new workspace, populate the workspace with files from the
// server, add some files to the server, modify those files, delete all files in the server, 
// and clean up the workspace.
//
// WARNING: This sample deletes all files from the server when it cleans up at the end.
// You probably don't want to run this against a machine that you are sharing with others.
//
// To Build: Add this file to a C# console application and add references to the following assemblies:
//    * %Program Files%\Visual Studio 8\common7\ide\PrivateAssemblies\Microsoft.VisualStudio.Hatteras.Client.dll
//    * %Program Files%\Visual Studio 8\common7\ide\PrivateAssemblies\Microsoft.VisualStudio.TeamFoundation.Client.dll
//
// The application should compile normally at that time.
//
// Copyright(c) Microsoft Corporation. All rights reserved.
//*************************************************************************************************

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Microsoft.VisualStudio.Hatteras.Client;
using Microsoft.VisualStudio.TeamFoundation.Client;
 

namespace BasicSccExample
{
    class Example
    {
        static void Main(string[] args)
        {
            // Verify that we have the arguments we require.  In this case, we require one argument
			// which is the name of the Team Foundation Server to which we are connecting.
            if (args.Length < 1)
            {
                Console.Error.WriteLine("Usage: app tfsName");
                Environment.Exit(1);
            }
 
            // Get a reference to our Team Foundation Server from the TeamFoundationServerFactory.
            String tfsName = args[0];
            TeamFoundationServer tfs = TeamFoundationServerFactory.GetServer(tfsName);
 
            // Get a reference to the Source Control service.
            SourceControl sourceControl = (SourceControl) tfs.GetService(typeof(SourceControl));
 
            // Register for the Source Control events.  These events will be raised through
			// the normal execution of the source control client.  The events are as follows:
			//   OnGetting - This event is raised for each file that is retrieved during
			//               a 'get' operation.
			//   NewPendingChange - This event is raised as files are checked out
			//   OnNonFatalError - certain error conditions not deemed fatal will cause this
			//                     event to be raised.  You might want to display the enclosed
			//                     error text to the user.
			//   BeforeCheckinPendingChange - This event is raised as files are uploaded to
			//                                be checked in.
            sourceControl.Getting += Example.OnGetting;
			sourceControl.NewPendingChange += Example.OnNewPendingChange;
			sourceControl.NonFatalError += Example.OnNonFatalError;
			sourceControl.BeforeCheckinPendingChange += Example.OnBeforeCheckinPendingChange;
 
            // Create a workspace.  
            Workspace workspace = sourceControl.CreateWorkspace("BasicSccExample", sourceControl.AuthenticatedUser);
 
            try
            {
                // Create a mapping.  This mapping will associate a path on the server with
				// a local path on disk.  When we perform a "get" operation, the source will
				// be written to this location on disk.
                workspace.CreateMapping("$/", @"c:\temp\BasicSccExample");
 
                // Get the files from the repository.
                workspace.Get();
 
                // Create a directory and a file.
                String topDir = Path.Combine(workspace.Folders[0].LocalItem, "sub");
                Directory.CreateDirectory(topDir);
                String fileName = Path.Combine(topDir, "basic.cs");
                using (StreamWriter sw = new StreamWriter(fileName))
                {
                    sw.WriteLine("revision 1 of basic.cs");
                }
 
                // Now add the directory and file to source control.
                workspace.PendAdd(topDir, true);
 
                // Show our pending changes.
                PendingChange[] pendingChanges = workspace.GetPendingChanges();
                Console.WriteLine("Your current pending changes:");
                foreach (PendingChange pendingChange in pendingChanges)
                {
                    Console.WriteLine("  path: " + pendingChange.LocalItem +
                                      ", change: " + PendingChange.ChangeTypeToString(pendingChange.ChangeType));
                }
 
                // Checkin the items we added creating a new changeset.
                int changesetNumber = workspace.CheckIn(pendingChanges, "Sample changes");
                Console.WriteLine("Checked in changeset " + changesetNumber);
 
                // Checkout and modify the file.
                workspace.PendEdit(fileName);
                using (StreamWriter sw = new StreamWriter(fileName))
                {
                    sw.WriteLine("revision 2 of basic.cs");
                }
 
                // Get the pending change and check in the new revision.
                pendingChanges = workspace.GetPendingChanges();
                changesetNumber = workspace.CheckIn(pendingChanges, "Modified basic.cs");
                Console.WriteLine("Checked in changeset " + changesetNumber);
            }
            finally
            {
                // Delete the items that we previously added to source control.
				// Warning: As written, this will delete everything in your repository.
				// Don't run this on a production repository.
                workspace.PendDelete("$/*", RecursionType.Full);
                PendingChange[] pendingChanges = workspace.GetPendingChanges();
                if (pendingChanges.Length > 0)
                {
                    workspace.CheckIn(pendingChanges, "Clean up!");
                }
 
                // Delete the workspace that was created earlier.
                workspace.Delete();
            }
        }
 
        internal static void OnNonFatalError(Object sender, ExceptionEventArgs e)
        {
            if (e.Exception != null)
            {
                Console.Error.WriteLine("Non-fatal exception: " + e.Exception.Message);
            }
            else
            {
                Console.Error.WriteLine("Non-fatal failure: " + e.Failure.Message);
            }
        }
 
        internal static void OnGetting(Object sender, GettingEventArgs e)
        {
            Console.WriteLine("Getting: " + e.TargetLocalItem + ", status: " + e.Status);
        }
 
        internal static void OnBeforeCheckinPendingChange(Object sender, PendingChangeEventArgs e)
        {
            Console.WriteLine("Checking in " + e.PendingChange.LocalItem);
        }
 
        internal static void OnNewPendingChange(Object sender, PendingChangeEventArgs e)
        {
            Console.WriteLine("Pending " + PendingChange.ChangeTypeToString(e.PendingChange.ChangeType) + 
                              " on " + e.PendingChange.LocalItem);
        }
    }
}

