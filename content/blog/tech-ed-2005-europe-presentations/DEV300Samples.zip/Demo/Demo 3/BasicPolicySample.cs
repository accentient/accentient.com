//*************************************************************************************************
// BasicPolicySample.cs
//
// Illustrates a basic checkin policy that prompts the user to decide whether they think they
// should be allowed to install.
//
// How to Build:  Create a new C# class library project called BasicPolicySample in Visual 
// Studio 2005.  Add to that project a reference to Microsoft.VisualStudio.Hatteras.Client.dll
// which can be found in %ProgramFiles%\Visual Studio 8\Common7\IDE\PrivateAssemblies.
// Copy the contents of this file and paste it code in the BasicPolicySample.cs that 
// you were given when you created the C# project.  Build.
//
// How to Install:  You need to place a single registry key that points to the location
// of the .dll created when you compiled.  The following registry key works for this policy
// on my machine:
//    [HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Hatteras\Checkin Policies]
//    "BasicPolicySample"="C:\\src\\BasicPolicySample\\BasicPolicySample\\bin\\debug\\BasicPolicySample.dll"
// If you choose to change the name of the assembly, it is very important that the key name
// matches the assembly name with the .dll extension.
//
// Copyright(c) Microsoft Corporation. All rights reserved.
//*************************************************************************************************
 

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.Hatteras.Client;
using System.Windows.Forms;

namespace BasicPolicySample
{
	[Serializable]
	public class BasicPolicySample: IPolicyDefinition, IPolicyEvaluation
	{

		#region IPolicyDefinition Members

		// This is the description of a defined policy that is displayed in the UI.
		public string Description
		{
			get { return "Prompt the user to decide if they are in compliance with the policy."; }
		}

		// This method is invoked by the policy framework when the user creates a new checkin
		// policy or edits an existing checkin policy.  We can use this as an opportunity to
		// display UI specific to this policy type allowing the user to change the parameters
		// of the policy.
		public bool Edit(System.Windows.Forms.IWin32Window parent, IServiceProvider serviceProvider)
		{
			if (MessageBox.Show(parent, "Do you want to turn on the Prompt Policy?", "Prompt Policy", 
				MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				return true;
			}
			return false;
		}

		// This is a string that is stored with the policy definition on the source
		// control server.  If a user does not have our policy plugin installed, this string
		// will be displayed.  We can use this as an opportunity to explain to the user
		// how they might go about installing our policy plugin.
		public string InstallationInstructions
		{
			get { return "To install this policy, follow the instructions in BasicPolicySample.cs."; }
		}

		// This string is the type of our policy.  It will be displayed to the user in a list
		// of all installed policy types when they are creating a new policy.
		public string Type
		{
			get { return "Prompt Policy"; }
		}

		// This string is a description of the type of our policy.  It will be displayed to the
		// user when they select our policy type in the list of policies installed on the system
		// as mentioned above.
		public string TypeDescription
		{
			get { return "This policy will prompt the user to decide whether or not they should be allowed to check in."; }
		}

		#endregion

		#region IPolicyEvaluation Members

		// This method performs the actual evaluation.  It is called by the policy framework at various points in time
		// when policy should be evaluated.  In this example, we invoke this method ourselves when various asyc
		// events occur that may have invalidated the current list of failures.
		public PolicyFailure[] Evaluate()
		{
			if (MessageBox.Show("Should we let you checkin?", "Evaluate", MessageBoxButtons.YesNo) == DialogResult.Yes)
				return m_noFailures;
			else
			{
				PolicyFailure[] toReturn = new PolicyFailure[1];
				toReturn[0] = new PolicyFailure("You told us not to let you checkin.", this);
				return toReturn;
			}
		}

		// This method is called by the policy framework when the plugin is instantiated.
		// This gives us an opportunity to capture the pendingCheckin object and register
		// for notification of changes in the set of pending changes being checked in.
		public void Initialize(IPendingCheckin pendingCheckin)
		{
			m_pendingCheckin = pendingCheckin;
			m_pendingCheckin.PendingChanges.CheckedPendingChangesChanged += new EventHandler(PendingChanges_CheckedPendingChangesChanged);
		}

		// This method is called as our policy object is being discarded.  We'll unregister for
		// events that were registered in the Initialize() method.
		public void Dispose()
		{
			m_pendingCheckin.PendingChanges.CheckedPendingChangesChanged -= new EventHandler(PendingChanges_CheckedPendingChangesChanged);
			m_pendingCheckin = null;
		}
		
		// This is the event handler for changes in the selected source files being checked in.
		// As the user checks and unchecks files for checkin from the pending checkin tool window
		// or checkin dialog, this event handler will be invoked giving the plugin an opportunity
		// to update the policy failures.
		private void PendingChanges_CheckedPendingChangesChanged(Object sender, EventArgs e)
		{
			OnPolicyStateChanged(Evaluate());
		}

		// This event is subscribed to by the policy framework and gives us a mechanism to
		// notify the framework when things happen asynchronously that affect policy compliance.
		public event PolicyStateChangedHandler PolicyStateChanged;

		// This method will notify the policy framework that policy compliance has
		// changed and needs to be updated in the UI.
		private void OnPolicyStateChanged(PolicyFailure[] failures)
		{
			{
				PolicyStateChangedHandler temp = PolicyStateChanged;
				if (temp != null)
				{
					temp(this, new PolicyStateChangedEventArgs(failures, this));
				}
			}
		}

		// This method is called if the user double-clicks on a policy failure in the UI.
		// We can handle this as we please, potentially prompting the user to perform
		// some activity that would eliminate the policy failure.
		public void Activate(PolicyFailure failure)
		{
			MessageBox.Show("Next time we ask, you might want to say \"Yes.\"", "How to fix your policy failure");
		}

		// This method is called if the user presses F1 when a policy failure is active in the UI.
		// We can handle this as we please, displaying help in whatever format is appropriate.
		// For this example, we'll just pop up a dialog.
		public void DisplayHelp(PolicyFailure failure)
		{
			MessageBox.Show("This policy lets you decide if you are in compliance.  To make your life easier, choose \"yes\" when prompted whether we should let you checkin.", "Prompt Policy Help");
		}

		[NonSerialized]
		public static readonly PolicyFailure[] m_noFailures = new PolicyFailure[0];
		private IPendingCheckin m_pendingCheckin = null;

		#endregion
}
}
