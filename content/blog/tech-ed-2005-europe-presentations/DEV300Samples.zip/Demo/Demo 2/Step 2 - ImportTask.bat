c:
cd\Program Files\Microsoft Visual Studio 8\Common7\IDE\PrivateAssemblies
witimport /f c:\demo\SecureTask.xml /t vstsb2 /p AdventureWorks
cd\demo
