c:
cd\demo\tools
xcopy witimport.* "c:\Program Files\Microsoft Visual Studio 8\Common7\IDE\PrivateAssemblies" /Y
xcopy witexport.* "c:\Program Files\Microsoft Visual Studio 8\Common7\IDE\PrivateAssemblies" /Y
xcopy glimport.* "c:\Program Files\Microsoft Visual Studio 8\Common7\IDE\PrivateAssemblies" /Y
xcopy glexport.* "c:\Program Files\Microsoft Visual Studio 8\Common7\IDE\PrivateAssemblies" /Y
cd\demo
