c:
cd\Program Files\Microsoft Visual Studio 8\Common7\IDE\PrivateAssemblies
witexport /f c:\demo\Task.xml /t vstsb2 /p AdventureWorks /n "Task"
cd\demo
