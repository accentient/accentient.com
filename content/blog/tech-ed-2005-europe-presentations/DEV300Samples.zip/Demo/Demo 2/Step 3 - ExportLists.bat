c:
cd\Program Files\Microsoft Visual Studio 8\Common7\IDE\PrivateAssemblies
glexport /f c:\demo\GlobalLists.xml /t vstsb2
cd\demo
