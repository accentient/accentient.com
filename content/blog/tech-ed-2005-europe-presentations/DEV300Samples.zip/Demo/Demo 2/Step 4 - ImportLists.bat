c:
cd\Program Files\Microsoft Visual Studio 8\Common7\IDE\PrivateAssemblies
glimport /f c:\demo\GlobalLists.xml /t vstsb2
cd\demo
