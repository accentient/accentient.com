<%@ Page language="c#" Codebehind="connStrDPAPI.aspx.cs" AutoEventWireup="false" Inherits="DataProtectionTest.connStrDPAPI" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>default</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="FlowLayout">
		<form id="Form1" method="post" runat="server">
			<P><FONT face="Verdana"> Connection String / DPAPI&nbsp;Example</FONT></P>
			<P>
				<asp:TextBox id="txtDataToEncrypt" runat="server" Width="384px">server=(local);database=northwind;integrated security=SSPI</asp:TextBox>&nbsp;
				<asp:Button id="btnEncrypt" runat="server" Text="Encrypt and Save to Registry" Width="192px"></asp:Button></P>
			<P>
				<asp:TextBox id="txtEncryptedData" runat="server" Width="664px" TextMode="MultiLine" Height="72px"></asp:TextBox></P>
			<P>
				<asp:Button id="btnDecrypt" runat="server" Text="Read from Registry, Deccrypt, and Connect!"
					Width="288px"></asp:Button></P>
			<P>
				<asp:TextBox id="txtDecryptedData" runat="server" Width="664px" TextMode="MultiLine" Height="72px"></asp:TextBox>
				<asp:Label id="Label1" runat="server">Label</asp:Label></P>
		</form>
	</body>
</HTML>
