using Microsoft.Win32;
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using DataProtection;

namespace DataProtectionTest
{

	public class connStrDPAPI : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox txtEncryptedData;
		protected System.Web.UI.WebControls.Button btnDecrypt;
		protected System.Web.UI.WebControls.TextBox txtDecryptedData;
		protected System.Web.UI.WebControls.TextBox txtDataToEncrypt;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Button btnEncrypt;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnEncrypt.Click += new System.EventHandler(this.btnEncrypt_Click);
			this.btnDecrypt.Click += new System.EventHandler(this.btnDecrypt_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnEncrypt_Click(object sender, System.EventArgs e)
		{

			DataProtector dp = new DataProtector( 
				DataProtector.Store.USE_MACHINE_STORE );
			try
			{
				byte[] dataToEncrypt = 
					Encoding.ASCII.GetBytes(txtDataToEncrypt.Text);
				// Not passing optional entropy in this example
				// Could pass random value (stored by the application) for added
				// security when using DPAPI with the machine store.
				txtEncryptedData.Text =
					Convert.ToBase64String(dp.Encrypt(dataToEncrypt,null));

				// Save to registry

				RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\ASPNetApp\Identity\ASPNET_SETREG",true);
				key.SetValue("connStr",txtEncryptedData.Text);
			}
			catch(Exception ex)
			{
				Response.Write("Exception.<br>" + ex.Message);
				return;
			}
		}

		private void btnDecrypt_Click(object sender, System.EventArgs e)
		{

			// Read from registry
 
			RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\ASPNetApp\Identity\ASPNET_SETREG");
			string encryptedConnStr = (string)key.GetValue("connStr");

			DataProtector dp = new 
				DataProtector(DataProtector.Store.USE_MACHINE_STORE);
			try
			{
				byte[] dataToDecrypt = 
					Convert.FromBase64String(encryptedConnStr);
				// Optional entropy parameter is null. 
				// If entropy was used within the Encrypt method, the same entropy
				// parameter must be supplied here
				string decryptedConnStr = 
					Encoding.ASCII.GetString(dp.Decrypt(dataToDecrypt,null));

				txtDecryptedData.Text = decryptedConnStr;
				System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(decryptedConnStr);

				System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("SELECT System_User",conn);
				
				conn.Open();
				Label1.Text = cmd.ExecuteScalar().ToString();
				conn.Close();

			}
			catch(Exception ex)
			{
				Response.Write("Exception.<br>" + ex.Message);
				return;
			}

		}
	}
}
