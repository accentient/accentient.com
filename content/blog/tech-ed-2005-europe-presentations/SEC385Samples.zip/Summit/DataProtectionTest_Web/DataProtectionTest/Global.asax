<%@ Application Codebehind="Global.asax.cs" Inherits="DataProtectionTest.Global" %>
