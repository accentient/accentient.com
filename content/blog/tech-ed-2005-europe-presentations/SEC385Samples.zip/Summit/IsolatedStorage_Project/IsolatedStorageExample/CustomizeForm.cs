// File     : CustomizeForm.cs
// Author   : J.S.White
// Modified : 13/09/02
// Purpose  : User-customize form (dialog) for Isolated Storage example

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace IsolatedStorageExample
{
	/// <summary>
	/// Summary description for CustomizeForm.
	/// </summary>
	public class CustomizeForm : System.Windows.Forms.Form
	{
		public System.Windows.Forms.TextBox txtMessage;
		public System.Windows.Forms.CheckBox cbMinimize;
		public System.Windows.Forms.CheckBox cbMaximize;
		public System.Windows.Forms.CheckBox cbTaskBar;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		public System.Windows.Forms.Button bnColor;
		private System.Windows.Forms.Button bnApply;
		private System.Windows.Forms.Button bnCancel;
		private System.Windows.Forms.ColorDialog colorDialog;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public CustomizeForm(string message, bool minBox, bool maxBox, bool taskBar, Color formColor)
		{
			InitializeComponent();

			// Setup the form controls...
			txtMessage.Text    = message;
			cbMinimize.Checked = minBox;
			cbMaximize.Checked = maxBox;
			cbTaskBar.Checked  = taskBar;
			bnColor.BackColor  = formColor;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtMessage = new System.Windows.Forms.TextBox();
			this.cbMinimize = new System.Windows.Forms.CheckBox();
			this.cbMaximize = new System.Windows.Forms.CheckBox();
			this.cbTaskBar = new System.Windows.Forms.CheckBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.bnColor = new System.Windows.Forms.Button();
			this.bnApply = new System.Windows.Forms.Button();
			this.bnCancel = new System.Windows.Forms.Button();
			this.colorDialog = new System.Windows.Forms.ColorDialog();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// txtMessage
			// 
			this.txtMessage.Location = new System.Drawing.Point(16, 24);
			this.txtMessage.Name = "txtMessage";
			this.txtMessage.Size = new System.Drawing.Size(240, 20);
			this.txtMessage.TabIndex = 0;
			this.txtMessage.Text = "";
			// 
			// cbMinimize
			// 
			this.cbMinimize.Location = new System.Drawing.Point(16, 24);
			this.cbMinimize.Name = "cbMinimize";
			this.cbMinimize.TabIndex = 1;
			this.cbMinimize.Text = "Minimize Box";
			// 
			// cbMaximize
			// 
			this.cbMaximize.Location = new System.Drawing.Point(16, 48);
			this.cbMaximize.Name = "cbMaximize";
			this.cbMaximize.TabIndex = 2;
			this.cbMaximize.Text = "Maximize Box";
			// 
			// cbTaskBar
			// 
			this.cbTaskBar.Location = new System.Drawing.Point(16, 72);
			this.cbTaskBar.Name = "cbTaskBar";
			this.cbTaskBar.Size = new System.Drawing.Size(112, 24);
			this.cbTaskBar.TabIndex = 3;
			this.cbTaskBar.Text = "Show In Task Bar";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.txtMessage);
			this.groupBox1.Location = new System.Drawing.Point(8, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(272, 64);
			this.groupBox1.TabIndex = 4;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Message";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.cbTaskBar);
			this.groupBox2.Controls.Add(this.cbMinimize);
			this.groupBox2.Controls.Add(this.cbMaximize);
			this.groupBox2.Controls.Add(this.bnColor);
			this.groupBox2.Location = new System.Drawing.Point(8, 80);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(272, 112);
			this.groupBox2.TabIndex = 5;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Settings";
			// 
			// bnColor
			// 
			this.bnColor.Location = new System.Drawing.Point(144, 32);
			this.bnColor.Name = "bnColor";
			this.bnColor.Size = new System.Drawing.Size(104, 56);
			this.bnColor.TabIndex = 6;
			this.bnColor.Text = "Set Background Color";
			this.bnColor.Click += new System.EventHandler(this.bnColor_Click);
			// 
			// bnApply
			// 
			this.bnApply.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.bnApply.Location = new System.Drawing.Point(56, 224);
			this.bnApply.Name = "bnApply";
			this.bnApply.TabIndex = 6;
			this.bnApply.Text = "Apply";
			this.bnApply.Click += new System.EventHandler(this.bnApply_Click);
			// 
			// bnCancel
			// 
			this.bnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.bnCancel.Location = new System.Drawing.Point(152, 224);
			this.bnCancel.Name = "bnCancel";
			this.bnCancel.TabIndex = 7;
			this.bnCancel.Text = "Cancel";
			this.bnCancel.Click += new System.EventHandler(this.bnCancel_Click);
			// 
			// CustomizeForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.Add(this.bnCancel);
			this.Controls.Add(this.bnApply);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Name = "CustomizeForm";
			this.Text = "CustomizeForm";
			this.Load += new System.EventHandler(this.CustomizeForm_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void bnColor_Click(object sender, System.EventArgs e)
		{
			colorDialog.Color = bnColor.BackColor;
			if (colorDialog.ShowDialog(this) == DialogResult.OK)
			{
				bnColor.BackColor = colorDialog.Color;
			}

		}

		private void bnCancel_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void CustomizeForm_Load(object sender, System.EventArgs e)
		{
			this.Text = "Customize for " + SystemInformation.UserName;
		}

		private void bnApply_Click(object sender, System.EventArgs e)
		{
		
		}
	}
}
