// File     : MainForm.cs
// Author   : J.S.White
// Modified : 13/09/02
// Purpose  : Main form for Isolated Storage example

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.IO.IsolatedStorage;

namespace IsolatedStorageExample
{
	/// <summary>
	/// Summary description for MainForm.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		const string MessageLabel    = "Message: ";
		const string CustomizedLabel = "Last Customized: ";
		const string UserConfigFile  = "StorageExample.txt";

		private System.Windows.Forms.Label lblMessage;
		private System.Windows.Forms.Label lblLastCustomized;
		private System.Windows.Forms.Button bnCustomize;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblMessage = new System.Windows.Forms.Label();
			this.lblLastCustomized = new System.Windows.Forms.Label();
			this.bnCustomize = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblMessage
			// 
			this.lblMessage.BackColor = System.Drawing.Color.White;
			this.lblMessage.Location = new System.Drawing.Point(8, 16);
			this.lblMessage.Name = "lblMessage";
			this.lblMessage.Size = new System.Drawing.Size(272, 23);
			this.lblMessage.TabIndex = 0;
			this.lblMessage.Text = "Message: No Message";
			// 
			// lblLastCustomized
			// 
			this.lblLastCustomized.BackColor = System.Drawing.Color.White;
			this.lblLastCustomized.Location = new System.Drawing.Point(8, 48);
			this.lblLastCustomized.Name = "lblLastCustomized";
			this.lblLastCustomized.Size = new System.Drawing.Size(272, 23);
			this.lblLastCustomized.TabIndex = 1;
			this.lblLastCustomized.Text = "Last Customized: Not Yet Customized";
			// 
			// bnCustomize
			// 
			this.bnCustomize.BackColor = System.Drawing.Color.Yellow;
			this.bnCustomize.Location = new System.Drawing.Point(208, 136);
			this.bnCustomize.Name = "bnCustomize";
			this.bnCustomize.TabIndex = 2;
			this.bnCustomize.Text = "Customize";
			this.bnCustomize.Click += new System.EventHandler(this.bnCustomize_Click);
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 166);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.bnCustomize,
																		  this.lblLastCustomized,
																		  this.lblMessage});
			this.Name = "MainForm";
			this.Text = "Isolated Storage Example";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MainForm());
		}

		private void bnCustomize_Click(object sender, System.EventArgs e)
		{
			CustomizeForm customizeDialog 
				= new CustomizeForm(lblMessage.Text.Substring(MessageLabel.Length), this.MinimizeBox, 
									this.MaximizeBox, this.ShowInTaskbar, this.BackColor);

			if (customizeDialog.ShowDialog(this) == DialogResult.OK)
			{
				// Read the new custom settings from the customize dialog...
				lblMessage.Text        = MessageLabel + customizeDialog.txtMessage.Text;
				lblLastCustomized.Text = CustomizedLabel + DateTime.Now.ToString();
				this.MinimizeBox       = customizeDialog.cbMinimize.Checked;
				this.MaximizeBox       = customizeDialog.cbMaximize.Checked;
				this.ShowInTaskbar     = customizeDialog.cbTaskBar.Checked;
				this.BackColor         = customizeDialog.bnColor.BackColor;

				// Write using Isolated Storage...
				WriteCustomUserSettings();
			}

			// Close the Customize dialog...
			customizeDialog.Dispose();

		}

		private void WriteCustomUserSettings()
		{
			IsolatedStorageFileStream userConfigFile = 
				new IsolatedStorageFileStream(UserConfigFile, FileMode.Create);

			// create a writer to the stream...
			StreamWriter writeStream = new StreamWriter(userConfigFile);

			// write the form configuration to the file...
			writeStream.WriteLine(lblMessage.Text.Substring(MessageLabel.Length));
			writeStream.WriteLine(lblLastCustomized.Text.Substring(CustomizedLabel.Length));
			writeStream.WriteLine(this.MinimizeBox);
			writeStream.WriteLine(this.MaximizeBox);
			writeStream.WriteLine(this.ShowInTaskbar);
			writeStream.WriteLine(this.BackColor.ToArgb());

			// clean up...
			writeStream.Flush();
			writeStream.Close();
			userConfigFile.Close();
		}

		private void ReadCustomUserSettings()
		{
			try
			{
				IsolatedStorageFileStream userConfigFile = 
					new IsolatedStorageFileStream(UserConfigFile, FileMode.Open);

				// create a reader to the stream...
				StreamReader readStream = new StreamReader(userConfigFile);

				// read each setting from the file...
				lblMessage.Text        = MessageLabel + readStream.ReadLine();
				lblLastCustomized.Text = CustomizedLabel + readStream.ReadLine();
				this.MinimizeBox       = readStream.ReadLine().Equals(Boolean.TrueString);
				this.MaximizeBox       = readStream.ReadLine().Equals(Boolean.TrueString);
				this.ShowInTaskbar     = readStream.ReadLine().Equals(Boolean.TrueString);
				this.BackColor         = Color.FromArgb(System.Int32.Parse(readStream.ReadLine()));

				// clean up...
				readStream.Close();
				userConfigFile.Close();
			}
			catch (System.IO.FileNotFoundException)
			{
				// Warn the user that no user configuration file has been found
				// and the default settings will therefore be used...
				MessageBox.Show("This application has not yet been user-customized.\n\n" +
					"Default settings will be applied.\n\n",
					"Isolated Storage Example");
			}
		}

		private void MainForm_Load(object sender, System.EventArgs e)
		{
			ReadCustomUserSettings();
		}
	}
}
