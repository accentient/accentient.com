<%@ Page language="c#" Codebehind="simpleDPAPI.aspx.cs" AutoEventWireup="false" Inherits="DataProtectionTest.simpleDPAPI" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>default</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="FlowLayout">
		<form id="Form1" method="post" runat="server">
			<P><FONT face="Verdana"> DPAPI&nbsp;Example</FONT></P>
			<P>
				<asp:TextBox id="txtDataToEncrypt" runat="server" Width="384px"></asp:TextBox>&nbsp;
				<asp:Button id="btnEncrypt" runat="server" Text="Encrypt"></asp:Button></P>
			<P>
				<asp:TextBox id="txtEncryptedData" runat="server" Width="664px" TextMode="MultiLine" Height="72px"></asp:TextBox></P>
			<P>
				<asp:Button id="btnDecrypt" runat="server" Text="Decrypt"></asp:Button></P>
			<P>
				<asp:TextBox id="txtDecryptedData" runat="server" Width="664px" TextMode="MultiLine" Height="72px"></asp:TextBox></P>
		</form>
	</body>
</HTML>
