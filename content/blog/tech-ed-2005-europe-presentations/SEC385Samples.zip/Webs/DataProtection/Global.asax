<%@ Application Codebehind="Global.asax.cs" Inherits="DataProtection.Global" %>
