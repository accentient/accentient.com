<%@ Import Namespace="System.Security.Principal.WindowsIdentity" %>
<%@ Import Namespace="Microsoft.Interop.Security.AzRoles" %>
<%@ Import Namespace="System.Security.Cryptography" %>
<%@ Import Namespace="System.Text" %>
<%@ Import Namespace="System.Data.SqlClient" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>

<script runat="server">
	Dim keyString As String = "thisIsASampleKey"
	Dim utf8 As New UTF8Encoding()
	Dim keyBuffer() As Byte = utf8.GetBytes(keyString)
	Dim ivString As String = "abcdefghijklmnop"
	Dim ivBuffer() As Byte = utf8.GetBytes(ivString)
	 
	sub Page_Load
	if Not Page.IsPostBack then
		Dim itemIDs = New ArrayList
		Dim myConnection = "Data Source=localhost;Initial Catalog=2807;User Id=2807access;Password=P@ssw0rd"
		Dim mySelectQuery = "SELECT * FROM inventory"
		Dim myConn As New SqlConnection(myConnection)
		myConn.open()
		Dim myCommand as New SqlCommand(mySelectQuery, myConn)
		Dim myReader as SqlDataReader
		myReader = myCommand.ExecuteReader()
		while myReader.Read()
			itemIDs.Add(myReader.getInt32(0))
		end while
		dd.DataSource = itemIDs
		dd.DataBind()
		myReader.Close()
		myConn.close()
	end if
	
	Dim AzManStore as AzAuthorizationStore
	dim invApp as Object
	Dim clientContext as IAzClientContext
	Dim formOperation As Object
	Dim submitTask As Object
	Dim newline As Byte
	Dim operationID
	Dim Operations(1)
	Dim Results(1)
	
	' Step 3-2
	AzManStore = CreateObject("AzRoles.AzAuthorizationStore")
	AzManStore.Initialize(0, "msldap://CN=AuthStore,DC=adworks,DC=msft")
	invApp = AzManStore.OpenApplication("InventoryWebApplication")
	
	' Step 3-3
	Dim id as System.Security.Principal.WindowsIdentity
	id = User.Identity
	clientContext = invApp.InitializeClientContextFromName(id.name)

	' Step 3-4
	formOperation = invApp.OpenOperation("Change Price")
	operationID = formOperation.operationID
	Operations(0) = operationID
	Results = clientContext.AccessCheck("Change Price", System.DBNull.value, Operations)

	' Step 3-5
	if Not Results(0) = 0 then
		pricePanel.Visible = false
	end if
	end sub

	' Step 1-3
	sub updatePrice(sender As Object, e As System.EventArgs)
		Dim myConnection = "Data Source=localhost;Initial Catalog=2807;User Id=2807access;Password=P@ssw0rd"
		Dim myUpdateQuery = "UPDATE inventory SET price='"& encryptPrice(price.Text) &"' WHERE id= '" & dd.SelectedValue &"'"
		Dim myConn As New SqlConnection(myConnection)
		myConn.open()
		Dim myCommand as New SqlCommand(myUpdateQuery, myConn)
		myCommand.ExecuteNonQuery()
		myConn.close()
	end sub
	
	' Step 1-4
	Function encryptPrice(decryptedPrice As String) as String
		Dim Buffer() As Byte = utf8.GetBytes(decryptedPrice)
		Dim riMan As RijndaelManaged = New RijndaelManaged
		riMan.key = keyBuffer
		riMan.iv = ivBuffer
		
		Dim encryptedString as String = Convert.ToBase64String(riMan.CreateEncryptor().TransformFinalBlock(buffer, 0, buffer.Length))
		return encryptedString
	end Function
	
	' Step 1-2
	Function decryptPrice(encryptedPrice As String) as String
		Dim Buffer() As Byte = Convert.FromBase64String(encryptedPrice)
		Dim riMan As RijndaelManaged = New RijndaelManaged
		riMan.key = keyBuffer
		riMan.iv = ivBuffer
		
		Dim decryptedString as String = utf8.GetString(riMan.CreateDecryptor().TransformFinalBlock(buffer, 0, buffer.Length))
	return decryptedString
	end Function
	

</script>
	<body>
	
		<h1>AdventureWorks Inventory</h1>
		<table width="100%" border=1>
		<tr><td><b>ID</b></td><td><b>Name</b< td></B><td><b>Quantity</b< td></B><td><b>Price ($)</b< td></B></td>
			<%
			Dim myConnection = "Data Source=localhost;Initial Catalog=2807;User Id=2807access;Password=P@ssw0rd"
			Dim mySelectQuery = "SELECT * FROM inventory"
			Dim myConn As New SqlConnection(myConnection)
			myConn.open()
			Dim myCommand as New SqlCommand(mySelectQuery, myConn)
			Dim myReader as SqlDataReader
			myReader = myCommand.ExecuteReader()
			
			' Step 1-1
			while myReader.Read()
				Response.Write("<tr><td>" & myReader.getInt32(0) & "</td><td>" & myReader.getString(1) & "</td><td>" & myReader.getInt32(2) & "</td><td>" & decryptPrice(myReader.getString(3)) & "</td></tr>")
			end while
			%></tr>
		</table>	
		
		<!-- Step 3-1 -->
		<asp:Panel ID="pricePanel" Runat="server">
<H3>Price Update</H3><BR>
<FORM id=Form1 runat="server">
<asp:DropDownList id=dd runat="server" AutoPostBack="True"></asp:DropDownList>
<asp:TextBox id=price runat="server"></asp:TextBox>
<asp:Button id=Button1 onclick=updatePrice Runat="server" text="Update"></asp:Button></FORM>
		</asp:Panel>	
	</body>
</HTML>
