using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.DirectoryServices;

namespace InventoryWebApplicationFormAuthAD
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.TextBox txtDomainName;
		protected System.Web.UI.WebControls.TextBox txtUserName;
		protected System.Web.UI.WebControls.TextBox txtPassword;
		protected System.Web.UI.WebControls.Label lblError;
		protected System.Web.UI.WebControls.Button btnLogon;
		protected System.Web.UI.WebControls.Label Label1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			//Step 1-1
			if (Request.ServerVariables["HTTPS"]== "off") {
				String strSecureURL;
				strSecureURL = "https://" + Request.ServerVariables["SERVER_NAME"] +  Request.ServerVariables["SCRIPT_NAME"];;
				Response.Redirect(strSecureURL);
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnLogon.Click += new System.EventHandler(this.btnLogon_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnLogon_Click(object sender, System.EventArgs e)
		{
			// Step 2-3
			string adPath = "LDAP://localhost/DC=adworks,DC=msft"; 
			LdapAuthentication adAuth = new LdapAuthentication(adPath);

			try
			{
				// Step 2-4
				if(true == adAuth.IsAuthenticated(txtDomainName.Text, 
					txtUserName.Text, 
					txtPassword.Text))
				{
					// Step 2-5
					string groups = adAuth.GetGroups();
					FormsAuthenticationTicket authTicket = 
						new FormsAuthenticationTicket(1,
						txtUserName.Text,
						DateTime.Now, 
						DateTime.Now.AddMinutes(60),
						false, groups);

					//Encrypt the ticket.
					String encryptedTicket = FormsAuthentication.Encrypt(authTicket);

					// Step 2-6
					HttpCookie authCookie = 
						new HttpCookie(FormsAuthentication.FormsCookieName,
						encryptedTicket);
					Response.Cookies.Add(authCookie); 

					// Step 2-7
					Response.Redirect(
						FormsAuthentication.GetRedirectUrl(txtUserName.Text, 
						false));
				}
				else
				{
					lblError.Text = 
						"Authentication failed, check username and password.";
				}
			}
			catch(Exception ex)
			{
				lblError.Text = "Error authenticating. " + ex.Message;
			}

		}
	}
}
