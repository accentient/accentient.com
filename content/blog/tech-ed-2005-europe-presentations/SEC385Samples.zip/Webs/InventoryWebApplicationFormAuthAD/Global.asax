<%@ Application Codebehind="Global.asax.cs" Inherits="InventoryWebApplicationFormAuthAD.Global" %>
