<%@ Page language="c#" Codebehind="Logon.aspx.cs" AutoEventWireup="false" Inherits="InventoryWebApplicationFormAuthAD.WebForm1" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>WebForm1</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<asp:Label id="Label1" style="Z-INDEX: 101; LEFT: 152px; POSITION: absolute; TOP: 64px" runat="server"
				Width="96px" Height="16px">Domain Name:</asp:Label>
			<asp:TextBox id="txtPassword" style="Z-INDEX: 106; LEFT: 272px; POSITION: absolute; TOP: 128px"
				runat="server" Width="144px" TextMode="Password"></asp:TextBox>
			<asp:Label id="Label2" style="Z-INDEX: 102; LEFT: 152px; POSITION: absolute; TOP: 96px" runat="server"
				Width="96px" Height="24px">User name:</asp:Label>
			<asp:Label id="Label3" style="Z-INDEX: 103; LEFT: 152px; POSITION: absolute; TOP: 128px" runat="server"
				Width="96px" Height="16px">Password:</asp:Label>
			<asp:TextBox id="txtDomainName" style="Z-INDEX: 104; LEFT: 272px; POSITION: absolute; TOP: 64px"
				runat="server" Width="144px"></asp:TextBox>
			<asp:TextBox id="txtUserName" style="Z-INDEX: 105; LEFT: 272px; POSITION: absolute; TOP: 96px"
				runat="server" Width="144px"></asp:TextBox>
			<asp:Label id="lblError" style="Z-INDEX: 107; LEFT: 152px; POSITION: absolute; TOP: 200px"
				runat="server" Width="264px" Height="24px" ForeColor="Red"></asp:Label>
			<asp:Button id="btnLogon" style="Z-INDEX: 108; LEFT: 344px; POSITION: absolute; TOP: 160px"
				runat="server" Width="72px" Text="Log On"></asp:Button>
		</form>
	</body>
</HTML>
