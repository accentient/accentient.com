<%@ Page language="c#" Codebehind="Default.aspx.cs" AutoEventWireup="false" Inherits="CustomerService._Default" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>Default</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body>
		<form id="Form1" method="post" runat="server">
			<P>
				<TABLE id="Table2" cellSpacing="1" cellPadding="1" width="500" border="0">
					<TR>
						<TD>Search by Customer ID<BR>
							<asp:TextBox id="textSearch" runat="server"></asp:TextBox>
							<asp:Button id="button1" runat="server" Text="Search"></asp:Button></TD>
						<TD>
							<P align="right">Verify Secret Word<BR>
								<asp:TextBox id="textVerifyWord" runat="server"></asp:TextBox>
								<asp:Button id="verify" runat="server" Text="Verify"></asp:Button></P>
						</TD>
					</TR>
				</TABLE>
			</P>
			<P>
				<asp:Label id="verifyMessage" runat="server">Not Verified</asp:Label></P>
			<P>Customer Information</P>
			<P>
				<TABLE id="Table1" cellSpacing="1" cellPadding="1" width="500" border="0">
					<TR>
						<TD>First</TD>
						<TD>
							<asp:TextBox id="textFirstName" runat="server"></asp:TextBox></TD>
						<TD>&nbsp;&nbsp;&nbsp;
						</TD>
						<TD>Day Phone</TD>
						<TD>
							<asp:TextBox id="textDaytimePhone" runat="server"></asp:TextBox></TD>
					</TR>
					<TR>
						<TD>Middle</TD>
						<TD>
							<asp:TextBox id="textMiddleName" runat="server"></asp:TextBox></TD>
						<TD></TD>
						<TD>Eve Phone</TD>
						<TD>
							<asp:TextBox id="textEveningPhone" runat="server"></asp:TextBox></TD>
					</TR>
					<TR>
						<TD>Last</TD>
						<TD>
							<asp:TextBox id="textLastName" runat="server"></asp:TextBox></TD>
						<TD></TD>
						<TD>Fax</TD>
						<TD>
							<asp:TextBox id="textFax" runat="server"></asp:TextBox></TD>
					</TR>
					<TR>
						<TD>Address</TD>
						<TD>
							<asp:TextBox id="textAddress" runat="server"></asp:TextBox></TD>
						<TD></TD>
						<TD>Email</TD>
						<TD>
							<asp:TextBox id="textEmail" runat="server"></asp:TextBox></TD>
					</TR>
					<TR>
						<TD>City</TD>
						<TD>
							<asp:TextBox id="textCity" runat="server"></asp:TextBox></TD>
						<TD></TD>
						<TD></TD>
						<TD></TD>
					</TR>
					<TR>
						<TD>State</TD>
						<TD>
							<asp:TextBox id="textState" runat="server"></asp:TextBox></TD>
						<TD></TD>
						<TD></TD>
						<TD></TD>
					</TR>
					<TR>
						<TD>Zip</TD>
						<TD>
							<asp:TextBox id="textZipCode" runat="server"></asp:TextBox></TD>
						<TD></TD>
						<TD>
							<asp:Button id="Button2" runat="server" Text="Save Changes"></asp:Button></TD>
						<TD></TD>
					</TR>
				</TABLE>
			</P>
		</form>
	</body>
</HTML>
