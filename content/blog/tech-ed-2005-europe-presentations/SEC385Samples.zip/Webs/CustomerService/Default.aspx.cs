using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace CustomerService
{
	/// <summary>
	/// Summary description for _Default.
	/// </summary>
	public class _Default : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button Button2;
		protected System.Web.UI.WebControls.TextBox textVerifyWord;
		protected System.Web.UI.WebControls.Button verify;
		protected System.Web.UI.WebControls.TextBox textFirstName;
		protected System.Web.UI.WebControls.TextBox textMiddleName;
		protected System.Web.UI.WebControls.TextBox textLastName;
		protected System.Web.UI.WebControls.TextBox textAddress;
		protected System.Web.UI.WebControls.TextBox textCity;
		protected System.Web.UI.WebControls.TextBox textState;
		protected System.Web.UI.WebControls.TextBox textZipCode;
		protected System.Web.UI.WebControls.TextBox textDaytimePhone;
		protected System.Web.UI.WebControls.TextBox textEveningPhone;
		protected System.Web.UI.WebControls.TextBox textFax;
		protected System.Web.UI.WebControls.TextBox textEmail;
		protected System.Web.UI.WebControls.TextBox textSearch;
		protected System.Web.UI.WebControls.Label verifyMessage;
		protected System.Web.UI.WebControls.Button button1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.button1.Click += new System.EventHandler(this.button1_Click);
			this.verify.Click += new System.EventHandler(this.verify_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void button1_Click(object sender, System.EventArgs e)
		{
			//need to add reg expression to check id is numeric only
			if (textSearch.Text == "") 
			{
				verifyMessage.Text="Invalid Customer ID";
				return;
			}
			SqlConnection myConn = new SqlConnection("Server=localhost;Integrated security=SSPI;database=2807");
			try 
			{
				myConn.Open();
			}
			catch (System.Exception ex) 
			{
				verifyMessage.Text=ex.ToString();
			}
		
			string mySelectQuery = "SELECT * FROM customers WHERE id = " + textSearch.Text;
			SqlCommand myCommand = new SqlCommand(mySelectQuery, myConn);
			SqlDataReader myReader;
			myReader = myCommand.ExecuteReader();
			if (myReader.Read())
			{
				textFirstName.Text = myReader.GetString(1);
				textMiddleName.Text = myReader.GetString(2);
				textLastName.Text = myReader.GetString(3);
				textAddress.Text = myReader.GetString(4);
				textCity.Text = myReader.GetString(5);
				textState.Text = myReader.GetString(6);
				textZipCode.Text = myReader.GetString(7);
				textDaytimePhone.Text = myReader.GetString(8);
				textEveningPhone.Text = myReader.GetString(9);
				textFax.Text = myReader.GetString(10);
				textEmail.Text = myReader.GetString(11);
				Session.Add("currentCustomerHashedWord",myReader.GetString(12));
				Session.Add("currentCustomerSalt",myReader.GetString(13));
			}
		}

		private void verify_Click(object sender, System.EventArgs e)
		{
			if (Utility.CompareWordAndHash(textVerifyWord.Text, Session["currentCustomerSalt"].ToString(), Session["currentCustomerHashedWord"].ToString()))
			{
				verifyMessage.BackColor=System.Drawing.Color.Green;
				verifyMessage.Text="The secret word provided is correct.";
			}
			else 
			{
				verifyMessage.BackColor=System.Drawing.Color.Red;
				verifyMessage.Text="The secret word provided is incorrect.";
			}
		}
		}
	}

