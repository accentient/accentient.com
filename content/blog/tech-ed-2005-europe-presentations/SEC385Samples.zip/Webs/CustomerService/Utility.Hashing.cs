using System;
using System.Security.Cryptography;
using System.Web.Security;

namespace CustomerService
{
	/// <summary>
	/// Summary description for Utility.
	/// </summary>
	public class Utility
	{
		public Utility()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		// Step 1-4
		public static string CreateSalt(int size)
		{
			// Generate a cryptographic random number using the cryptographic
			// service provider
			RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
			byte[] buff = new byte[size];
			rng.GetBytes(buff);
			// Return a Base64 string representation of the random number
			return Convert.ToBase64String(buff);
		}

		// Step 1-3
		public static string CreateHash(string word, string salt)
		{
			string saltAndWord = String.Concat(word, salt);
			string hashedWord = 
				FormsAuthentication.HashPasswordForStoringInConfigFile(
				saltAndWord, "SHA1");
			return hashedWord;
		}
	
		// Step 1-2
		public static bool CompareWordAndHash(string word, string salt, string hash)
		{
			string hashedWord = CreateHash(word, salt);
			return (hashedWord == hash);
		}
	}
}
