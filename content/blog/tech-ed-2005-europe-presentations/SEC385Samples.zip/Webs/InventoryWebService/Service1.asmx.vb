Imports System.Web.Services
Imports System.Data.SqlClient
Imports Microsoft.Web.Services2
Imports Microsoft.Web.Services2.Security
Imports Microsoft.Web.Services2.Security.Tokens

<System.Web.Services.WebService(Namespace:="http://lon-dc1/InventoryWebService/Service1")> _
Public Class Service1
    Inherits System.Web.Services.WebService

#Region " Web Services Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Web Services Designer.
        InitializeComponent()

        'Add your own initialization code after the InitializeComponent() call

    End Sub

    'Required by the Web Services Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Web Services Designer
    'It can be modified using the Web Services Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container
    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        'CODEGEN: This procedure is required by the Web Services Designer
        'Do not modify it using the code editor.
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

#End Region

    <WebMethod()> _
    Public Function getQuantity(ByVal productID As Int32) As Int32
        'Step 3-3
        Dim requestContext As SoapContext = RequestSoapContext.Current
        If requestContext Is Nothing Then
            Throw New ApplicationException("Either a non-SOAP request was received or WSE is not properly installed for the Web application hosting the web service.")
        End If
        If Not IsMessageSigned(requestContext) Then
            Throw New ApplicationException("The request is not signed using an acceptable signature.")
        End If

        Dim quantity As Int32
        quantity = -1
        Dim myConnection = "Data Source=localhost;Initial Catalog=2807;User Id=2807access;Password=P@ssw0rd"
        Dim mySelectQuery = "SELECT * FROM inventory WHERE id=" & productID
        Dim myConn As New SqlConnection(myConnection)
        myConn.Open()
        Dim myCommand As New SqlCommand(mySelectQuery, myConn)
        Dim myReader As SqlDataReader
        myReader = myCommand.ExecuteReader()
        While myReader.Read()
            quantity = myReader.GetInt32(2)
        End While
        Return quantity
    End Function

    ' Step 3-4
    Private Function IsMessageSigned(ByVal context As SoapContext) As Boolean
        Dim element As ISecurityElement
        For Each element In context.Security.Elements
            If (TypeOf (element) Is MessageSignature) Then
                ' The SoapContext contains a Signature element. 
                Dim sign As MessageSignature = element
                If ((sign.SignatureOptions And _
                    (SignatureOptions.IncludeSoapBody Or _
                    SignatureOptions.IncludeTo Or _
                    SignatureOptions.IncludeAction Or _
                    SignatureOptions.IncludeMessageId Or _
                    SignatureOptions.IncludeFrom))) Then
                    If TypeOf sign.SigningToken Is KerberosToken Then
                        ' The SOAP message is signed using a Kerberos
                        ' token.
                        Return True
                    End If
                End If
            End If
        Next
        Return False
    End Function

End Class
