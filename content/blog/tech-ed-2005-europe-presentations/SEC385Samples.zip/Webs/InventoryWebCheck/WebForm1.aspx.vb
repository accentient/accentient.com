Imports Microsoft.Web.Services2
Imports Microsoft.Web.Services2.Security
Imports Microsoft.Web.Services2.Security.Tokens

Namespace localhost
    Public Class WebForm1
        Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub
        Protected WithEvents Label1 As System.Web.UI.WebControls.Label
        Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
        Protected WithEvents Button1 As System.Web.UI.WebControls.Button

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        End Sub
        'Step 4-1
        Sub getPriceFromService(ByVal sender As Object, ByVal e As System.EventArgs)
            Dim kerbToken As New KerberosToken("host/lon-dc1")
            Dim svc As New Service1
            Dim requestContext As SoapContext = svc.RequestSoapContext
            requestContext.Security.Tokens.Add(kerbToken)
            Dim sig As New MessageSignature(kerbToken)
            requestContext.Security.Elements.Add(sig)
            requestContext.Security.Timestamp.TtlInSeconds = 60
            Label1.Text = svc.getQuantity(TextBox1.Text)
        End Sub
    End Class
End Namespace