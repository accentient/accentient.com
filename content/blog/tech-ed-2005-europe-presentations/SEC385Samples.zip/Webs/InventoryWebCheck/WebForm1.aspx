<%@ Page Language="vb" AutoEventWireup="false" Codebehind="WebForm1.aspx.vb" Inherits="InventoryWebCheck.localhost.WebForm1"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>WebForm1</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio .NET 7.1">
		<meta name="CODE_LANGUAGE" content="Visual Basic .NET 7.1">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<H1>Inventory Web Check</H1>
		<form id="Form1" method="post" runat="server">
			<asp:Label id="Label1" style="Z-INDEX: 101; LEFT: 40px; POSITION: absolute; TOP: 128px" runat="server"
				Width="176px" Height="24px" Font-Bold="True"></asp:Label>
			<asp:TextBox id="TextBox1" style="Z-INDEX: 102; LEFT: 40px; POSITION: absolute; TOP: 80px" runat="server"
				Width="88px"></asp:TextBox>
			<asp:Button id="Button1" style="Z-INDEX: 103; LEFT: 144px; POSITION: absolute; TOP: 80px" runat="server"
				Width="72px" Text="Check" OnClick="getPriceFromService"></asp:Button>
		</form>
	</body>
</HTML>
