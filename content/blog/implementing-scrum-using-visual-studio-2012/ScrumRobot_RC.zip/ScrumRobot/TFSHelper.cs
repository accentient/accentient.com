﻿using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Xml;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.Server;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.TeamFoundation.ProcessConfiguration.Client; // Microsoft.TeamFoundation.ProjectManagement.dll found in C:\Program Files (x86)\Microsoft Visual Studio 11.0\Common7\IDE\ReferenceAssemblies\v4.5

namespace ScrumRobot
{
  class ScrumBot
  {
    private static Random random = new Random();

    public static void ListTeams(string tpcUri, string teamProject)
    {
      TfsTeamProjectCollection tpc = new TfsTeamProjectCollection(new Uri(tpcUri));
      tpc.EnsureAuthenticated();

      // Get service and hierarchy

      ICommonStructureService4 css = tpc.GetService<ICommonStructureService4>();
      ProjectInfo project = css.GetProjectFromName(teamProject);
      TfsTeamService teamService = tpc.GetService<TfsTeamService>();
      TeamFoundationTeam defaultTeam = teamService.GetDefaultTeam(project.Uri, null);
      Guid teamID = defaultTeam.Identity.TeamFoundationId;

      Console.WriteLine("Team name: {0}", defaultTeam.Name);
      Console.WriteLine("Team ID: {0}", teamID);
      Console.WriteLine("Description: {0}", defaultTeam.Description);
      var properties = defaultTeam.GetProperties();

      foreach (var kvp in properties)
      {
        Console.WriteLine("{0} = {1}", kvp.Key, kvp.Value);
      }

      // Set which iteration paths the team owns
      string[] iterationPaths = { "Tailspin\\Release 1\\Sprint 1", "Tailspin\\Release 1\\Sprint 2", "Tailspin\\Release 1\\Sprint 3", "Tailspin\\Release 1\\Sprint 4" };

      TeamSettingsConfigurationService teamConfigService = tpc.GetService<TeamSettingsConfigurationService>();
      var teamConfigs = teamConfigService.GetTeamConfigurationsForUser(new string[] { project.Uri });

      foreach (TeamConfiguration teamConfig in teamConfigs)
      {
        if (teamConfig.TeamName == "Tailspin Team")
        {
          TeamSettings settings = teamConfig.TeamSettings;
          settings.IterationPaths = iterationPaths;
          teamConfigService.SetTeamSettings(teamID, settings);
          //Console.WriteLine(teamConfig.TeamName);
        }
      }

      //TeamConfiguration teamConfig = (TeamConfiguration)teamConfigs.FirstOrDefault(t => t.TeamId == teamID);

      //TeamConfiguration teamConfig = 

      //defaultTeam.
      //TeamConfiguration config;
      //config.TeamSettings

      //TeamSettings settings = new TeamSettings();
      //defaultTeam.

      //settings.
      //teamConfigService.SetTeamSettings(teamID,
      //Console.WriteLine(teamConfigService.ToString());

      //teamcon
      //var tfsTeamConfigurations = teamConfigurationService.GetTeamConfigurationsForUser(new string[] { projectId });
      //TeamConfiguration tfsTeamConfiguration = tfsTeamConfigurations.FirstOrDefault(t => t.TeamId == teamId);

      //TeamSettings settings = new TeamSettings();


      // TeamSettingsConfigurationService.SetTeamSettings() method.

      //var tfsTeamConfigurations = teamConfigurationService.GetTeamConfigurationsForUser(new string[] { projectId });

      //TeamConfiguration tfsTeamConfiguration = tfsTeamConfigurations.FirstOrDefault(t => t.TeamId == teamId);
      //TeamSettings teamSettings = tfsTeamConfiguration.TeamSettings;

      //The team's iterations are stored under teamSettings.IterationPaths   (System.String[])
      //The areas (scopes) are stored under teamSettings.TeamFieldValues    (Microsoft.TeamFoundation.ProcessConfiguration.Client.TeamFieldValue[])

      //Simply update the properties and call

      //teamConfigurationService.SetTeamSettings(teamId, tfsTeamConfiguration.TeamSettings);

      //to commit everything to the server. 

      //Note1: you’ll need to add a reference to Microsoft.TeamFoundation.ProjectManagement.dll (v11.0)
      //              Note2: GetTeamConfigurationsForUser() will only retrieve configurations for teams that the currently authorized user is a member of!
      //Retrieving and setting iteration dates:

      //http://blog.johnsworkshop.net/tfs11-api-managing-the-team-iteration-schedule/

      //Cheers,
      //Ogy

    }

    public static void RemoveAreas(string tpcUri, string teamProject)
    {
      try
      {
        // Connect

        TfsTeamProjectCollection tpc = new TfsTeamProjectCollection(new Uri(tpcUri));
        tpc.EnsureAuthenticated();

        // Get service and hierarchy

        ICommonStructureService css = tpc.GetService<ICommonStructureService>();
        ProjectInfo project = css.GetProjectFromName(teamProject);
        NodeInfo[] hierarchy = css.ListStructures(project.Uri);
        XmlElement tree = css.GetNodesXml(new string[] { hierarchy[0].Uri }, true);
        string parentUri = tree.FirstChild.Attributes["NodeID"].Value;

        // Enumerate nodes

        if (tree.HasChildNodes)
        {
          XmlNode childrenNode = tree.FirstChild;
          if (childrenNode.HasChildNodes && childrenNode.FirstChild.HasChildNodes)
          {
            string[] nodes = new string[childrenNode.ChildNodes[0].ChildNodes.Count];
            for (int i = 0; i < childrenNode.ChildNodes[0].ChildNodes.Count; i++)
            {
              XmlNode node = childrenNode.ChildNodes[0].ChildNodes[i];
              nodes[i] = node.Attributes["NodeID"].Value;
            }
            css.DeleteBranches(nodes, parentUri);
          }
        }

        // Set the root node to the default for the team

      }
      catch
      {
      }
    }

    public static void RemoveIterations(string tpcUri, string teamProject)
    {
      try
      {
        // Connect

        TfsTeamProjectCollection tpc = new TfsTeamProjectCollection(new Uri(tpcUri));
        tpc.EnsureAuthenticated();

        // Get service and hierarchy

        ICommonStructureService css = tpc.GetService<ICommonStructureService>();
        ProjectInfo project = css.GetProjectFromName(teamProject);
        NodeInfo[] hierarchy = css.ListStructures(project.Uri);
        XmlElement tree = css.GetNodesXml(new string[] { hierarchy[1].Uri }, true);
        string parentUri = tree.FirstChild.Attributes["NodeID"].Value;

        // Enumerate nodes

        if (tree.HasChildNodes)
        {
          XmlNode childrenNode = tree.FirstChild;
          if (childrenNode.HasChildNodes && childrenNode.FirstChild.HasChildNodes)
          {
            string[] nodes = new string[childrenNode.ChildNodes[0].ChildNodes.Count];
            for (int i = 0; i < childrenNode.ChildNodes[0].ChildNodes.Count; i++)
            {
              XmlNode node = childrenNode.ChildNodes[0].ChildNodes[i];
              nodes[i] = node.Attributes["NodeID"].Value;
            }
            css.DeleteBranches(nodes, parentUri);
          }
        }

        // Set the root node to the default for the team

      }
      catch
      {
      }
    }

    public static void AddArea(string tpcUri, string teamProject, string nodeValue, string parentValue = "")
    {
      try
      {
        // Connect

        TfsTeamProjectCollection tpc = new TfsTeamProjectCollection(new Uri(tpcUri));
        tpc.EnsureAuthenticated();

        // Get service and hierarchy

        ICommonStructureService css = tpc.GetService<ICommonStructureService>();
        ProjectInfo project = css.GetProjectFromName(teamProject);
        NodeInfo[] hierarchy = css.ListStructures(project.Uri);
        XmlElement tree;
        tree = css.GetNodesXml(new string[] { hierarchy[0].Uri }, true);

        string parentUri = "";
        if (parentValue == "")
        {
          parentUri = tree.FirstChild.Attributes["NodeID"].Value;
        }
        else
        {
          parentUri = tree.SelectSingleNode("//Children/Node[@Name='" + parentValue + "']").Attributes["NodeID"].Value;
        }
        css.CreateNode(nodeValue, parentUri);
      }
      catch
      {
      }
    }

    public static void AddIterations(string tpcUri, string teamProject, DateTime startDate, int Releases, int SprintsPerRelease, int SprintWeeks, bool ResetSprintsEachRelease = true)
    {
      try
      {
        // Connect

        TfsTeamProjectCollection tpc = new TfsTeamProjectCollection(new Uri(tpcUri));
        tpc.EnsureAuthenticated();

        // Get service and hierarchy

        ICommonStructureService4 css = tpc.GetService<ICommonStructureService4>();
        ProjectInfo project = css.GetProjectFromName(teamProject);
        NodeInfo[] hierarchy = css.ListStructures(project.Uri);
        XmlElement tree;
        tree = css.GetNodesXml(new string[] { hierarchy[1].Uri }, true);
        string parentUri = tree.FirstChild.Attributes["NodeID"].Value;
        int lastSprint = 1;

        for (int release = 1; release <= Releases; release++)
        {
          string releaseUri = css.CreateNode("Release " + release.ToString(), parentUri);
          css.SetIterationDates(releaseUri, startDate, startDate.AddDays(SprintsPerRelease * SprintWeeks * 7 - 1));
          for (int sprint = 1; sprint <= SprintsPerRelease; sprint++)
          {
            string sprintUri;
            if (ResetSprintsEachRelease)
              sprintUri = css.CreateNode("Sprint " + sprint.ToString(), releaseUri);
            else
              sprintUri = css.CreateNode("Sprint " + lastSprint, releaseUri);
            css.SetIterationDates(sprintUri, startDate, startDate.AddDays(SprintWeeks * 7 - 1));
            startDate = startDate.AddDays(SprintWeeks * 7);
            lastSprint++;
          }
        }
      }
      catch { }
    }

    public static void SetPlanningIterations(string tpcUri, string teamProject, string[] iterationPaths)
    {
      // Connect

      TfsTeamProjectCollection tpc = new TfsTeamProjectCollection(new Uri(tpcUri));
      tpc.EnsureAuthenticated();

      // Get services

      ICommonStructureService4 css = tpc.GetService<ICommonStructureService4>();
      ProjectInfo project = css.GetProjectFromName(teamProject);
      TeamSettingsConfigurationService teamConfigService = tpc.GetService<TeamSettingsConfigurationService>();
      var teamConfigs = teamConfigService.GetTeamConfigurationsForUser(new string[] { project.Uri });
      foreach (TeamConfiguration teamConfig in teamConfigs)
      {
        if (teamConfig.IsDefaultTeam)
        {
          TeamSettings settings = teamConfig.TeamSettings;
          settings.IterationPaths = iterationPaths;
          teamConfigService.SetTeamSettings(teamConfig.TeamId, settings);
        }
      }
    }

    public static void DestroyWorkItems(string tpcUri, string teamProject)
    {
      TfsTeamProjectCollection tpc = new TfsTeamProjectCollection(new Uri(tpcUri));
      tpc.EnsureAuthenticated();

      // Get work items

      WorkItemStore store = new WorkItemStore(tpc);
      Project project = store.Projects[teamProject];
      string wiql = "SELECT [System.Id], [System.Title] FROM WorkItems " + "WHERE [System.TeamProject] = '" + teamProject + "'";
      WorkItemCollection collection = store.Query(wiql);

      // Get list of work items to destroy (everything but Sprint)

      Console.Write("Destroying work item: ");
      ArrayList destroyIds = new ArrayList();
      for (int i = 0; i < collection.Count; i++)
      {
        WorkItem wi = collection[i];
        destroyIds.Add(wi.Id);
      }

      if (destroyIds.Count < 1)
      {
        Console.WriteLine("> No work items to destroy.");
        return;
      }

      // Convert to int array

      int[] ids = new int[destroyIds.Count];
      for (int i = 0; i < destroyIds.Count; i++)
      {
        ids[i] = Convert.ToInt32(destroyIds[i]);
        Console.Write("{0}, ", ids[i]);
      }

      // Destroy work items

      IEnumerable<WorkItemOperationError> errors = store.DestroyWorkItems(ids);
      List<WorkItemOperationError> errorList = new List<WorkItemOperationError>(errors);
      if (errorList.Count > 0)
      {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < errorList.Count; i++)
        {
          builder.AppendLine(string.Format("> Error destroying work item {0}, {1}", errorList[i].Id, errorList[i].Exception.Message));
        }
        Console.WriteLine(builder.ToString());
      }
      Console.WriteLine();
    }

    private static int RandomNumber(int max)
    {
      return random.Next(0, max);
    }

    private static int RandomFibonacci()
    {
      int random = RandomNumber(6);
      switch (random)
      {
        case 1: { return 1; }
        case 2: { return 2; }
        case 3: { return 3; }
        case 4: { return 5; }
        case 5: { return 8; }
        case 6: { return 13; }
        default:
          return 5;
      }
    }

    private static int RandomBusinessValue()
    {
      int random = RandomNumber(7);
      switch (random)
      {
        case 1: { return 10; }
        case 2: { return 25; }
        case 3: { return 50; }
        case 4: { return 75; }
        case 5: { return 80; }
        case 6: { return 90; }
        case 7: { return 100; }
        default:
          return 50;
      }
    }

    public static void CreateProductBacklog(string tpcUri, string teamProject, string xmlFile, bool genValueEffort)
    {
      TfsTeamProjectCollection tpc = new TfsTeamProjectCollection(new Uri(tpcUri));
      tpc.EnsureAuthenticated();
      // WorkItemStore store = new WorkItemStore(tpc, WorkItemStoreFlags.BypassRules);
      WorkItemStore store = new WorkItemStore(tpc);
      Project project = store.Projects[teamProject];
      int priority = 1;
      Hashtable workItems = new Hashtable();

      XmlDocument backlog = new XmlDocument();
      backlog.Load(xmlFile);
      XmlNodeList items = backlog.SelectNodes("items/item");

      Console.Write("Adding work item: ");
      foreach (XmlNode item in items)
      {
        WorkItem pbi = new WorkItem(project.WorkItemTypes[item["type"].InnerText]);
        pbi.Title = item["title"].InnerText;
        pbi.Description = item["description"].InnerText;
        if (item["reprosteps"] != null)
        {
          pbi.Fields["Microsoft.VSTS.TCM.ReproSteps"].Value = item["reprosteps"].InnerText;
        }
        if (item["acceptancecriteria"] != null)
        {
          pbi.Fields["Microsoft.VSTS.Common.AcceptanceCriteria"].Value = item["acceptancecriteria"].InnerText;
        }
        pbi.AreaPath = teamProject + item["area"].InnerText;
        pbi.Fields["System.AssignedTo"].Value = item["assignedto"].InnerText;
        if (item["state"].InnerText.ToLower() == "approved")
        {
          if (item["type"].InnerText.ToLower() == "product backlog item")
          {
            if (item["businessvalue"] != null && item["businessvalue"].InnerText != "")
            {
              pbi.Fields["Microsoft.VSTS.Common.BusinessValue"].Value = item["businessvalue"].InnerText;
            }
            if (genValueEffort)
            {
              pbi.Fields["Microsoft.VSTS.Common.BusinessValue"].Value = RandomBusinessValue();
            }
          }
          if (item["effort"] != null && item["effort"].InnerText != "")
          {
            pbi.Fields["Microsoft.VSTS.Scheduling.Effort"].Value = item["effort"].InnerText;
          }
          else
          {
            if (genValueEffort)
            {
              pbi.Fields["Microsoft.VSTS.Scheduling.Effort"].Value = RandomFibonacci();
            }
          }
          pbi.Fields["Microsoft.VSTS.Common.BacklogPriority"].Value = priority++;
        }
        pbi.Save();
        Console.Write("{0}, ", pbi.Id);
        workItems.Add(pbi.Id, pbi.Title.Trim().ToLower());

        // linked items?

        if (item["parent"] != null)
        {
          string parent = item["parent"].InnerText.Trim().ToLower();
          int parentId = 0;
          foreach (DictionaryEntry wi in workItems)
          {
            if (wi.Value.ToString() == parent)
            {
              parentId = Convert.ToInt32(wi.Key);
            }
          }
          if (parentId > 0)
          {

            // lookup child link type

            WorkItemLinkTypeEnd childLink = store.WorkItemLinkTypes.LinkTypeEnds["Parent"];
            pbi.WorkItemLinks.Add(new WorkItemLink(childLink, parentId));
            pbi.Save();
          }
        }

        if (item["state"].InnerText.ToLower() == "approved")
        {
          pbi.State = "Approved";
          pbi.Save();
        }
      }

      //// Add a lot of other PBIs

      //for (int i = 1; i < 500; i++)
      //{
      //  WorkItem pbi = new WorkItem(project.WorkItemTypes["Product Backlog Item"]);
      //  pbi.Title = "Extra PBI # " + i.ToString();
      //  pbi.Fields["System.AssignedTo"].Value = "Paula (Product Owner)";
      //  pbi.Fields["Microsoft.VSTS.Common.BusinessValue"].Value = 10;
      //  pbi.Fields["Microsoft.VSTS.Scheduling.Effort"].Value = 5;
      //  pbi.Fields["Microsoft.VSTS.Common.BacklogPriority"].Value = priority++;
      //  pbi.Save();
      //  Console.Write("{0}, ",pbi.Id);
      //}
    }

    public static void ResetProductBacklog(string tpcUri, string teamProject)
    {
      TfsTeamProjectCollection tpc = new TfsTeamProjectCollection(new Uri(tpcUri));
      tpc.EnsureAuthenticated();

      // Get work items

      WorkItemStore store = new WorkItemStore(tpc);
      Project project = store.Projects[teamProject];
      string wiql = "SELECT [System.Id], [System.Title] FROM WorkItems WHERE [System.TeamProject] = '" +
        teamProject + "' AND [System.WorkItemType] IN ('Product Backlog Item', 'Bug') ORDER BY [Microsoft.VSTS.Common.BacklogPriority] ASC";
      WorkItemCollection collection = store.Query(wiql);

      // Reset state and iteration path

      Console.WriteLine("Reseting Product Backlog Sprints and states");
      for (int i = 0; i < collection.Count; i++)
      {
        WorkItem wi = collection[i];
        wi.Open();
        if (wi.State == "Done")
        {
          wi.State = "Committed";
          wi.Save();
        }
        if (wi.State == "Committed")
        {
          wi.IterationPath = teamProject;
          wi.State = "Approved";
          wi.Save();
        }
      }

      // Delete all tasks

      wiql = "SELECT [System.Id], [System.Title] FROM WorkItems " + "WHERE [System.TeamProject] = '" + teamProject + "' AND [System.WorkItemType] = 'Task'";
      collection = store.Query(wiql);
      ArrayList destroyIds = new ArrayList();
      for (int i = 0; i < collection.Count; i++)
      {
        WorkItem wi = collection[i];
        destroyIds.Add(wi.Id);
      }
      if (destroyIds.Count < 1)
      {
        Console.WriteLine("> No tasks to destroy.");
        return;
      }

      // Convert to int array

      int[] ids = new int[destroyIds.Count];
      for (int i = 0; i < destroyIds.Count; i++)
      {
        ids[i] = Convert.ToInt32(destroyIds[i]);
        Console.WriteLine("> Destroying task {0}", ids[i]);
      }

      // Destroy work items

      IEnumerable<WorkItemOperationError> errors = store.DestroyWorkItems(ids);
      List<WorkItemOperationError> errorList = new List<WorkItemOperationError>(errors);
      if (errorList.Count > 0)
      {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < errorList.Count; i++)
        {
          builder.AppendLine(string.Format("> Error destroying task {0}, {1}", errorList[i].Id, errorList[i].Exception.Message));
        }
        Console.WriteLine(builder.ToString());
      }
    }

    public static void AssignProductBacklogToSprints(string tpcUri, string teamProject, int velocity)
    {
      TfsTeamProjectCollection tpc = new TfsTeamProjectCollection(new Uri(tpcUri));
      tpc.EnsureAuthenticated();

      // Get work items

      WorkItemStore store = new WorkItemStore(tpc);
      Project project = store.Projects[teamProject];
      string wiql = "SELECT [System.Id], [System.Title] FROM WorkItems WHERE [System.TeamProject] = '" +
        teamProject + "' AND [System.WorkItemType] IN ('Product Backlog Item', 'Bug') ORDER BY [Microsoft.VSTS.Common.BacklogPriority] ASC";
      WorkItemCollection collection = store.Query(wiql);

      // Get list of work items

      int points = 0;
      int sprint = 1;

      Console.Write("Assigning PBIs to Sprints: ");
      for (int i = 0; i < collection.Count; i++)
      {
        WorkItem wi = collection[i];
        wi.Open();
        if (wi.State == "Approved")
        {
          Console.Write("{0}, ", wi.Id);
          int effort = Convert.ToInt32(wi.Fields["Effort"].Value);
          if ((points + effort) > velocity)
          {
            sprint++;
            points = 0;
          }
          if (sprint < 7)
          {
            wi.IterationPath = teamProject + @"\Release 1\Sprint " + sprint.ToString();
            wi.State = "Committed";
            wi.Save();
          }

          // move to Done for sprints 1-2

          if (sprint < 3)
          {
            wi.State = "Done";
            wi.Save();
          }
          points += effort;
        }
      }
      Console.WriteLine("");
    }

    public static void AssignTasksToSprints(string tpcUri, string teamProject)
    {
      TfsTeamProjectCollection tpc = new TfsTeamProjectCollection(new Uri(tpcUri));
      tpc.EnsureAuthenticated();

      // Get work items

      WorkItemStore store = new WorkItemStore(tpc);
      Project project = store.Projects[teamProject];
      string wiql = "SELECT [System.Id], [System.Title] FROM WorkItems WHERE [System.TeamProject] = '" +
        teamProject + "' AND [System.WorkItemType] IN ('Product Backlog Item', 'Bug') ORDER BY [Microsoft.VSTS.Common.BacklogPriority] ASC";
      WorkItemCollection collection = store.Query(wiql);

      // lookup child link type

      WorkItemLinkTypeEnd childLink = store.WorkItemLinkTypes.LinkTypeEnds["Parent"];

      // Loads tasks

      XmlDocument taskList = new XmlDocument();
      taskList.Load("tasks.xml");

      // Reset state and iteration path

      Console.Write("Adding tasks to work item: ");
      for (int i = 0; i < collection.Count; i++)
      {
        WorkItem pbi = collection[i];
        pbi.Open();
        // if (pbi.State == "Done" || pbi.State == "Committed")
        if (pbi.State == "Committed")
          {
          Console.Write("{0}, ", pbi.Id);
          XmlNodeList tasks = taskList.SelectNodes("tasks/task");
          foreach (XmlNode task in tasks)
          {
            WorkItem wi = new WorkItem(project.WorkItemTypes["Task"]);
            wi.Title = task["title"].InnerText;
            wi.AreaPath = pbi.AreaPath;
            wi.IterationPath = pbi.IterationPath;
            if (task["hours"] != null && task["hours"].InnerText != "")
            {
              wi.Fields["Microsoft.VSTS.Scheduling.RemainingWork"].Value = task["hours"].InnerText;
            }
            wi.WorkItemLinks.Add(new WorkItemLink(childLink, pbi.Id));
            wi.Save();
            if (pbi.State == "Done")
            {
              wi.Fields["Microsoft.VSTS.Scheduling.RemainingWork"].Value = "0";
              wi.State = "Done";
              wi.Save();
            }
          }
        }
      }
      Console.WriteLine("");
    }
  }
}
