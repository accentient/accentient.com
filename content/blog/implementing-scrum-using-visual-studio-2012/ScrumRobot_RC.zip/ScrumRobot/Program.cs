﻿using System;

namespace ScrumRobot
{
  class Program
  {
    static void Main(string[] args)
    {
      string tpc = "http://vsalm:8080/tfs/scrum";
      string tp = "Tailspin2012";

      // Areas

      //ScrumBot.RemoveAreas(tpc, tp);
      //ScrumBot.AddArea(tpc, tp, "Administration");
      //ScrumBot.AddArea(tpc, tp, "Community");
      //ScrumBot.AddArea(tpc, tp, "Social Media", "Community");
      //ScrumBot.AddArea(tpc, tp, "Customers");
      //ScrumBot.AddArea(tpc, tp, "Marketing");
      //ScrumBot.AddArea(tpc, tp, "Mobile");
      //ScrumBot.AddArea(tpc, tp, "Orders");
      //ScrumBot.AddArea(tpc, tp, "Products");

      // Iterations

      //ScrumBot.RemoveIterations(tpc, tp);
      //ScrumBot.AddIterations(tpc, tp, DateTime.Today.AddDays(-14), 4, 6, 2, true); // TechEd
      //ScrumBot.SetPlanningIterations(tpc, tp, new string[] { tp + "\\Release 1\\Sprint 1", tp + "\\Release 1\\Sprint 2", tp + "\\Release 1\\Sprint 3", tp + "\\Release 1\\Sprint 4" });

      // Create Product Backlog

      //ScrumBot.DestroyWorkItems(tpc, tp);
      //ScrumBot.CreateProductBacklog(tpc, tp, "backlog.xml", true);

      // Add Tasks to Sprint Backlog

      //ScrumBot.AssignTasksToSprints(tpc, tp);

      // Velocity Demo

      //ScrumBot.RemoveIterations(tpc, tp);
      //ScrumBot.AddIterations(tpc, tp, DateTime.Today.AddDays(-42), 4, 6, 2, true); // 3 sprints back
      //ScrumBot.SetPlanningIterations(tpc, tp, new string[] { tp + "\\Release 1\\Sprint 1", tp + "\\Release 1\\Sprint 2", tp + "\\Release 1\\Sprint 3", tp + "\\Release 1\\Sprint 4", tp + "\\Release 1\\Sprint 5", tp + "\\Release 1\\Sprint 6" });
      //ScrumBot.DestroyWorkItems(tpc, tp);
      //ScrumBot.CreateProductBacklog(tpc, tp, "backlog.xml",true);
      //ScrumBot.AssignProductBacklogToSprints(tpc, tp, 18);
    }
  }
}