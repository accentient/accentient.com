using System;
using System.Collections.Generic;
using System.Text;

namespace BulkDataCopy
{
	class MyStopWatch
	{
		private DateTime startTime; 
		private DateTime endTime;
		private TimeSpan elapsedTime = new TimeSpan();
		private Boolean started = false;

		public TimeSpan Elapsed
		{
			get
			{
				return elapsedTime;
			}

		}

		public void Start()
		{
			started = true;
			startTime = DateTime.Now;
		}

		public void Stop()
		{
			if (started)
			{
				endTime = DateTime.Now;
				elapsedTime = endTime.Subtract(startTime);
				started = false;
			}
		}





	}
}
