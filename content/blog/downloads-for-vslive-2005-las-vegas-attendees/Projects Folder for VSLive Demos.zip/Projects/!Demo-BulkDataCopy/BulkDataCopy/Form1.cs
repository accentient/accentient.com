using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;


namespace BulkDataCopy
{
	public partial class Form1 : Form
	{

		//DataSet ds; 
		//SqlConnection sqlConn; //= new SqlConnection("server=(local);database=AdventureWorks;integrated security=SSPI");
		//SqlDataAdapter da; // = new SqlDataAdapter("SELECT * FROM Sales.SalesOrderDetail2 WHERE SalesOrderID < 55000", sqlConn);//

		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			SqlConnection connSource = new SqlConnection("server=(local);database=AdventureWorks;integrated security=SSPI");

			connSource.Open();
			SqlCommand cmd = new SqlCommand("truncate table sales.salesorderdetail3; truncate table sales.salesorderdetail4", connSource);
			cmd.ExecuteNonQuery();
			MessageBox.Show("Done truncating Tables");


		}

		private void button2_Click(object sender, EventArgs e)
		{
			// Create stopwatches to time the insert
			MyStopWatch stopWatch1 = new MyStopWatch();

			// Setup

			 DataSet ds = new DataSet();
			 SqlConnection sqlConn = new SqlConnection("server=(local);database=AdventureWorks;integrated security=SSPI");
			 SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Sales.SalesOrderDetail2 WHERE SalesOrderID < 50000", sqlConn);//
			
			// Use an efficient and modified insert string
			//string insertString = "INSERT INTO [Sales].[SalesOrderDetail3] ([SalesOrderID], [CarrierTrackingNumber], [OrderQty], [ProductID], [SpecialOfferID], [UnitPrice], [UnitPriceDiscount], [rowguid], [ModifiedDate]) VALUES (@p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9)";		

			SqlCommandBuilder cb = new SqlCommandBuilder(da);
			da.InsertCommand = cb.GetInsertCommand();


			// Ensure that the filled DataTable has values set to Added so that the Update will work
			da.AcceptChangesDuringFill = false;

			// Fill the DataSet
			da.Fill(ds, "SalesOrderDetail");

			// Output the size of the table
			textBox1.Text += ds.Tables["SalesOrderDetail"].Rows.Count.ToString() + "\r\n\r\n";

			// Do the Bulk Load

			sqlConn.Open();

			SqlBulkCopy bcp = new SqlBulkCopy(sqlConn);
			bcp.DestinationTableName = "Sales.SalesOrderDetail3";

			// Time the insert
			stopWatch1.Start();

			bcp.WriteToServer(ds.Tables["SalesOrderDetail"]);
			stopWatch1.Stop();

			// Close everything
			bcp.Close();
			sqlConn.Close();

			//Output to textBox
			textBox1.Text += String.Format("Elapsed time for BulkInsert: {0} seconds.\r\n\r\n", stopWatch1.Elapsed.TotalSeconds.ToString());



		}

		private void button3_Click(object sender, EventArgs e)
		{
			// Create two stopwatches to time the inserts
			MyStopWatch stopWatch2 = new MyStopWatch();

			DataSet ds = new DataSet();
			SqlConnection sqlConn = new SqlConnection("server=(local);database=AdventureWorks;integrated security=SSPI");
			SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Sales.SalesOrderDetail3 WHERE SalesOrderID < 44100", sqlConn);//

			// Use an efficient and modified insert string
			//string insertString = "INSERT INTO [Sales].[SalesOrderDetail3] ([SalesOrderID], [CarrierTrackingNumber], [OrderQty], [ProductID], [SpecialOfferID], [UnitPrice], [UnitPriceDiscount], [rowguid], [ModifiedDate]) VALUES (@p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9)";		

			SqlCommandBuilder cb = new SqlCommandBuilder(da);
			da.InsertCommand = cb.GetInsertCommand();

			// Ensure that the filled DataTable has values set to Added so that the Update will work
			da.AcceptChangesDuringFill = false;

			// Fill the DataSet
			da.Fill(ds, "SalesOrderDetail");

			//// or we could use the following AFTER the fill
			//foreach (DataRow dr in ds.Tables[0].Rows)
			//{
			//    dr.SetAdded() = true;
			//}

			// Output the size of the table
			textBox1.Text += ds.Tables["SalesOrderDetail"].Rows.Count.ToString() + "\r\n\r\n";

			// Update with DataAdapter.Update
			SqlCommand cmd = new SqlCommand("truncate table sales.salesorderdetail3", sqlConn);
			sqlConn.Open();
			cmd.ExecuteNonQuery();
			sqlConn.Close();

			// Time the insert
			stopWatch2.Start();
			da.Update(ds, "SalesOrderDetail");
			stopWatch2.Stop();


			// Output to textBox
			textBox1.Text += String.Format("Elapsed time for DataSet Insert: {0} seconds.\r\n\r\n", stopWatch2.Elapsed.TotalSeconds.ToString());

		}

		private void button4_Click(object sender, EventArgs e)
		{
			// Create two stopwatches to time the inserts
			MyStopWatch stopWatch2 = new MyStopWatch();

			DataSet ds = new DataSet();
			SqlConnection sqlConn = new SqlConnection("server=(local);database=AdventureWorks;integrated security=SSPI");
			SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Sales.SalesOrderDetail3 WHERE SalesOrderID < 44100", sqlConn);//

			// Use an efficient and modified insert string
			//string insertString = "INSERT INTO [Sales].[SalesOrderDetail3] ([SalesOrderID], [CarrierTrackingNumber], [OrderQty], [ProductID], [SpecialOfferID], [UnitPrice], [UnitPriceDiscount], [rowguid], [ModifiedDate]) VALUES (@p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9)";		

			SqlCommandBuilder cb = new SqlCommandBuilder(da);
			da.InsertCommand = cb.GetInsertCommand();

			//textBox1.Text = da.InsertCommand.CommandText;


			//// Use an efficient and modified insert string
			//string insertString = "INSERT INTO [Sales].[SalesOrderDetail3] ([SalesOrderID], [CarrierTrackingNumber], [OrderQty], [ProductID], [SpecialOfferID], [UnitPrice], [UnitPriceDiscount], [rowguid], [ModifiedDate]) VALUES (@p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9)";
			//da.InsertCommand = new SqlCommand(insertString, sqlConn);

			// Ensure that the filled DataTable has values set to Added so that the Update will work
			da.AcceptChangesDuringFill = false;

			// Fill the DataSet
			da.Fill(ds, "SalesOrderDetail");

			// Output the size of the table
			textBox1.Text += ds.Tables["SalesOrderDetail"].Rows.Count.ToString() + "\r\n\r\n";

			// Update with DataAdapter.Update (With Batch Size = 50)
			SqlCommand cmd = new SqlCommand("truncate table sales.salesorderdetail3", sqlConn);
			sqlConn.Open();
			cmd.ExecuteNonQuery();
			sqlConn.Close();

			// Time the insert
			stopWatch2.Start();
			da.UpdateBatchSize = 50;
			da.Update(ds, "SalesOrderDetail");
			stopWatch2.Stop();


			// Output to textBox
			textBox1.Text += String.Format("Elapsed time for DataSetInsert (batch of 50): {0} seconds.\r\n\r\n", stopWatch2.Elapsed.TotalSeconds.ToString());

		}
	}
}			







