using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Data;
using System.Data.SqlClient;

[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class Service : System.Web.Services.WebService
{
    public Service () {

    }

	[WebMethod]
	public DataTable GetEmployeesUsingDataTable()
	{

		try
		{

			DataSet ds = new DataSet();
			SqlConnection sqlConn = new SqlConnection("server=(local);database=AdventureWorks;integrated security=SSPI");
			SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM HumanResources.vEmployee WHERE EmployeeID < 25", sqlConn);
			da.Fill(ds, "Employees");
			int x = ds.Tables.Count;
			return ds.Tables["Employees"];
		}
		catch (Exception ex)
		{
			return new DataTable();
			//return ex.Message;
		}

	}

	[WebMethod]
	public DataSet GetEmployeesUsingDataSet()
	{

		try
		{

			DataSet ds = new DataSet();
			SqlConnection sqlConn = new SqlConnection("server=(local);database=AdventureWorks;integrated security=SSPI");
			SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM HumanResources.vEmployee WHERE EmployeeID < 25", sqlConn);
			da.Fill(ds, "Employees");
			int x = ds.Tables.Count;
			return ds;
		}
		catch (Exception ex)
		{
			return new DataSet();
			//return ex.Message;
		}

	}
    
}
