using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DataSetSerialization
{
	public partial class Form1 : Form
	{

		StringBuilder builder;
		String connect = "server=(local);database=AdventureWorks;integrated security=SSPI";
		String SQL = "SELECT * FROM Person.Contact";


		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{

			textBox1.Clear();

			builder = new StringBuilder();
			DataSet ds = new DataSet();

			// create DataAdapter and get a DataSet of rows
			SqlDataAdapter da = new SqlDataAdapter(SQL, connect);
			try
			{
				da.Fill(ds);

				// display details of table in DataSet
				builder.Append(String.Format("DataSet contains a table with {0} rows\r\n\r\n",
											ds.Tables[0].Rows.Count.ToString()));

				// serialize the DataSet to a disk file as XML
				SerializeDataSetContents(ds, "Contacts.xml",
										SerializationFormat.Xml);

				// serialize the DataSet to a disk file in binary format
				SerializeDataSetContents(ds, "Contacts.dat",
												SerializationFormat.Binary);
			}
			catch (Exception ex)
			{
				builder.Append("* ERROR: " + ex.Message);
			}

			// display results
			textBox1.Text = builder.ToString();
		}


		private void SerializeDataSetContents(DataSet ds, String filename,
											  SerializationFormat format)
		{
			String path = "C:\\Projects\\" +filename;
			builder.Append(String.Format("Serializing DataSet contents to {0} as {1} \r\n",
										  path, format.ToString()));

			// specify the remoting format for the DataSet
			ds.RemotingFormat = format;

			// create a BinaryFormatter to serialize the contents
			IFormatter formatter = new BinaryFormatter();
			using (Stream output = new FileStream(path, FileMode.Create,
									  FileAccess.Write, FileShare.None))
			{
				try
				{
					// serialize DataSet, tracking the time taken
					DateTime start = DateTime.Now;
					formatter.Serialize(output, ds);
					TimeSpan span = DateTime.Now.Subtract(start);
					builder.Append(String.Format("Serialization took {0} milliseconds, \r\n",
									span.Milliseconds.ToString()));

					// display resulting file size
					FileInfo fi = new FileInfo(path);
					builder.Append(String.Format("File size is {0} KBytes.\r\n\r\n",
								  (fi.Length / 1024).ToString()));

					output.Close();
				}
				catch (Exception e)
				{
					builder.Append("* ERROR: " + e.Message);
				}
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			textBox1.Clear();

		}
	}
}