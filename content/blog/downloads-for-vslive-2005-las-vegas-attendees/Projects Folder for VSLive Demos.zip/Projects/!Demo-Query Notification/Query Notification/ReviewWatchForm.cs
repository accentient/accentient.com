using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Collections.Generic;

/* =====================================================================

  File:      ReviewWatchForm.cs for Adventure Works Cycles ReviewWatcher Sample
  Summary:   Defines the user interface for displaying new product reviews as they are posted
  Date:	     September 17, 2003

---------------------------------------------------------------------

  This file is part of the Microsoft SQL Server Code Samples.
  Copyright (C) 2003 Microsoft Corporation.  All rights reserved.

This source code is intended only as a supplement to Microsoft
Development Tools and/or on-line documentation.  See these other
materials for detailed information regarding Microsoft code samples.

THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

======================================================= */

namespace Microsoft.Samples.SqlServer
{
	/// <summary>
	/// This class defines the user interface for display new product reviews as they are posted
	/// </summary>
	public class ReviewWatchForm: System.Windows.Forms.Form
	{
		// UI controls for the form
		private System.Windows.Forms.PictureBox pictureBox1;	//The heading decoration
		private System.Windows.Forms.Label ReviewContent;		//The text of the product review selected
		private System.Windows.Forms.ListView ReviewList;		//A table of product review summaries
		private System.Windows.Forms.ColumnHeader reviewerName;	//A column for the review list for the customer's name
		private System.Windows.Forms.ColumnHeader reviewDate;	//A column for the review list for when the review was written
		private System.Windows.Forms.ImageList ratingsImageList;	//A collection of graphical images which represent the various ratings.
		private System.Windows.Forms.ColumnHeader productName;	//A column for the review list which identifies the product reviewed.
		private System.Windows.Forms.ColumnHeader rating;		//The column containing the image which represents the ranking
		private System.ComponentModel.IContainer components;	//Internal to WinForms.
		private System.Windows.Forms.Button ClearButton;		//The control used to empty the table and reset the display.
		private System.Windows.Forms.Label HelpLabel;			//Some information about how to use the application.
		private List<String> commentList = new List<String>();	//The review content pulled from the database.
		private ReviewWatch revWatch;							//The data access component which updates the form when new 
		//product reviews are inserted into the AdventureWorks database.
		//We must retain this so it is not GCed, and thus the 
		//dependency would be GCed as well.
		/// <summary>
		///		This form is used to display new product reviews which have been added to the AdventureWorks database.
		/// </summary>
		public ReviewWatchForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			ReviewList.SmallImageList = ratingsImageList;
			ReviewList.View = View.Details;					//For this application, the only view which is interesting is the detail view.
			revWatch = new ReviewWatch(this);	//Create an instance of the class which will monitor changes to 

			//the ProductReview table.  Provide this form for callbacks.
			revWatch.WatchForReviews();						//Set up the initial SqlDependency class which will begin monitoring of
			//the ProductReview table
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}

			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReviewWatchForm));
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.ReviewList = new System.Windows.Forms.ListView();
			this.rating = new System.Windows.Forms.ColumnHeader();
			this.productName = new System.Windows.Forms.ColumnHeader();
			this.reviewerName = new System.Windows.Forms.ColumnHeader();
			this.reviewDate = new System.Windows.Forms.ColumnHeader();
			this.ReviewContent = new System.Windows.Forms.Label();
			this.ratingsImageList = new System.Windows.Forms.ImageList(this.components);
			this.ClearButton = new System.Windows.Forms.Button();
			this.HelpLabel = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(0, -2);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(906, 49);
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			// 
			// ReviewList
			// 
			this.ReviewList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.rating,
            this.productName,
            this.reviewerName,
            this.reviewDate});
			this.ReviewList.FullRowSelect = true;
			this.ReviewList.GridLines = true;
			this.ReviewList.Location = new System.Drawing.Point(0, 47);
			this.ReviewList.MultiSelect = false;
			this.ReviewList.Name = "ReviewList";
			this.ReviewList.Size = new System.Drawing.Size(538, 537);
			this.ReviewList.TabIndex = 1;
			this.ReviewList.View = System.Windows.Forms.View.Details;
			this.ReviewList.SelectedIndexChanged += new System.EventHandler(this.ReviewList_SelectedIndexChanged);
			// 
			// rating
			// 
			this.rating.Text = "Rating";
			this.rating.Width = 109;
			// 
			// productName
			// 
			this.productName.Text = "Product";
			this.productName.Width = 188;
			// 
			// reviewerName
			// 
			this.reviewerName.Text = "Reviewer";
			this.reviewerName.Width = 122;
			// 
			// reviewDate
			// 
			this.reviewDate.Text = "Date";
			this.reviewDate.Width = 135;
			// 
			// ReviewContent
			// 
			this.ReviewContent.BackColor = System.Drawing.SystemColors.Window;
			this.ReviewContent.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.ReviewContent.Location = new System.Drawing.Point(540, 47);
			this.ReviewContent.Name = "ReviewContent";
			this.ReviewContent.Size = new System.Drawing.Size(364, 332);
			this.ReviewContent.TabIndex = 2;
			// 
			// ratingsImageList
			// 
			this.ratingsImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ratingsImageList.ImageStream")));
			this.ratingsImageList.Images.SetKeyName(0, "reviewrating1.gif");
			this.ratingsImageList.Images.SetKeyName(1, "reviewrating2.gif");
			this.ratingsImageList.Images.SetKeyName(2, "reviewrating3.gif");
			this.ratingsImageList.Images.SetKeyName(3, "reviewrating4.gif");
			this.ratingsImageList.Images.SetKeyName(4, "reviewrating5.gif");
			// 
			// ClearButton
			// 
			this.ClearButton.Location = new System.Drawing.Point(22, 592);
			this.ClearButton.Name = "ClearButton";
			this.ClearButton.Size = new System.Drawing.Size(75, 23);
			this.ClearButton.TabIndex = 3;
			this.ClearButton.Text = "Clear";
			this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
			// 
			// HelpLabel
			// 
			this.HelpLabel.BackColor = System.Drawing.SystemColors.Info;
			this.HelpLabel.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.HelpLabel.Location = new System.Drawing.Point(542, 446);
			this.HelpLabel.Name = "HelpLabel";
			this.HelpLabel.Size = new System.Drawing.Size(360, 69);
			this.HelpLabel.TabIndex = 4;
			this.HelpLabel.Text = "Add a product review using the Adventure Works Cycles Storefront.  A summary of t" +
				"he review should appear in the table to the left.  Select the review to see the " +
				"review comments above.";
			// 
			// ReviewWatchForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(10, 23);
			this.ClientSize = new System.Drawing.Size(905, 619);
			this.Controls.Add(this.HelpLabel);
			this.Controls.Add(this.ClearButton);
			this.Controls.Add(this.ReviewContent);
			this.Controls.Add(this.ReviewList);
			this.Controls.Add(this.pictureBox1);
			this.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Name = "ReviewWatchForm";
			this.Text = "Review Watcher";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			Application.EnableVisualStyles();
			Application.Run(new ReviewWatchForm());
		}
		/// <summary>
		///		The event handler which is called when the user clicks on a row in the ReviewList.
		/// </summary>
		/// <param name="sender">Who sent the event</param>
		/// <param name="e">Additional information about the event</param>
		private void ReviewList_SelectedIndexChanged(object sender,
													 System.EventArgs e)
		{
			if (ReviewList.SelectedIndices.Count > 0)
			{
				ReviewContent.Text = commentList[ReviewList.SelectedIndices[0]];
			}
			else
			{
				ReviewContent.Text = "";
			}
		}
		/// <summary>
		///		The signature of the method for the callback which adds a row to the ReviewList table, and adds
		///		the review content to the commentList collection.
		/// </summary>
		public delegate void AddReviewerRow(int rating, String productName,
											String reviewer,
											String dateOfReview,
											String comments);
		/// <summary>
		///		The method which matches the signature above, and which adds a row to the ReviewList table and adds the 
		///		review content to the commentList collection.
		/// </summary>
		/// <param name="rating">The ranking of the review</param>
		/// <param name="productName">Which product</param>
		/// <param name="reviewer">Who reviewed the product</param>
		/// <param name="dateOfReview">When they reviewed it</param>
		/// <param name="comments">What they had to say about the product</param>
		public void AddRowToList(int rating, String productName,
								 String reviewer, String dateOfReview,
								 String comments)
		{
			ListViewItem test = new ListViewItem(new String[] { "",
																productName,
																reviewer, dateOfReview
			}, rating - 1);

			ReviewList.Items.Add(test);
			commentList.Add(comments);
		}
		/// <summary>
		///		The event handler which is invoked when the user presses the Clear button.  This 
		///     resets the user interface to the empty state.
		/// </summary>
		/// <param name="sender">Who sent the event</param>
		/// <param name="e">Additional information about the event</param>
		private void ClearButton_Click(object sender, System.EventArgs e)
		{
			ReviewList.Items.Clear();
			commentList.Clear();
			ReviewContent.Text = "";
		}
	}
}
