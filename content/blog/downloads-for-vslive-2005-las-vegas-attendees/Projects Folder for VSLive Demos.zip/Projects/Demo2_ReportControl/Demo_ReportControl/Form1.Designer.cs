namespace Demo_ReportControl
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
			this.vEmployeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.AdventureWorksDataSet = new Demo_ReportControl.AdventureWorksDataSet();
			this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
			this.vEmployeeTableAdapter = new Demo_ReportControl.AdventureWorksDataSetTableAdapters.vEmployeeTableAdapter();
			((System.ComponentModel.ISupportInitialize)(this.vEmployeeBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.AdventureWorksDataSet)).BeginInit();
			this.SuspendLayout();
			// 
			// vEmployeeBindingSource
			// 
			this.vEmployeeBindingSource.DataMember = "vEmployee";
			this.vEmployeeBindingSource.DataSource = this.AdventureWorksDataSet;
			// 
			// AdventureWorksDataSet
			// 
			this.AdventureWorksDataSet.DataSetName = "AdventureWorksDataSet";
			// 
			// reportViewer1
			// 
			this.reportViewer1.AccessibleName = "WinReportServiceViewer";
			this.reportViewer1.AllowDrop = true;
			this.reportViewer1.AutoScroll = true;
			this.reportViewer1.BackColor = System.Drawing.Color.White;
			this.reportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
			reportDataSource1.Name = "AdventureWorksDataSet_vEmployee";
			reportDataSource1.Value = this.vEmployeeBindingSource;
			this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
			this.reportViewer1.LocalReport.DisplayName = "Demo_ReportControl.Report1.rdlc";
			this.reportViewer1.LocalReport.ReportEmbeddedResource = "Demo_ReportControl.Report1.rdlc";
			this.reportViewer1.LocalReport.ReportPath = null;
			this.reportViewer1.Location = new System.Drawing.Point(0, 0);
			this.reportViewer1.Name = "reportViewer1";
			this.reportViewer1.ProcessingMode = Microsoft.Reporting.WinForms.ProcessingMode.Local;
			this.reportViewer1.PromptAreaCollapsed = false;
			this.reportViewer1.ShowBackButton = true;
			this.reportViewer1.ShowContextMenu = true;
			this.reportViewer1.ShowCredentialPrompts = true;
			this.reportViewer1.ShowDocumentMap = true;
			this.reportViewer1.ShowDocumentMapButton = true;
			this.reportViewer1.ShowExportButton = true;
			this.reportViewer1.ShowPageNavigationControls = true;
			this.reportViewer1.ShowParameterPrompts = true;
			this.reportViewer1.ShowPrintButton = true;
			this.reportViewer1.ShowProgress = true;
			this.reportViewer1.ShowPromptAreaButton = true;
			this.reportViewer1.ShowRefreshButton = true;
			this.reportViewer1.ShowStopButton = true;
			this.reportViewer1.ShowToolBar = true;
			this.reportViewer1.ShowZoomButton = true;
			this.reportViewer1.Size = new System.Drawing.Size(524, 289);
			this.reportViewer1.TabIndex = 0;
			this.reportViewer1.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.Percent;
			this.reportViewer1.ZoomPercent = 100;
			// 
			// vEmployeeTableAdapter
			// 
			this.vEmployeeTableAdapter.ClearBeforeFill = true;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(524, 289);
			this.Controls.Add(this.reportViewer1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.vEmployeeBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.AdventureWorksDataSet)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
		private AdventureWorksDataSet AdventureWorksDataSet;
		private System.Windows.Forms.BindingSource vEmployeeBindingSource;
		private Demo_ReportControl.AdventureWorksDataSetTableAdapters.vEmployeeTableAdapter vEmployeeTableAdapter;
	}
}

