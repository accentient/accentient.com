using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Data;
using System.Data.SqlClient;

[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class Service : System.Web.Services.WebService
{
    public Service () {

    }

    [WebMethod]
    public DataTable GetEmployees() {

		try
		{

			DataSet ds = new DataSet();
			SqlConnection sqlConn = new SqlConnection("server=(local);database=AdventureWorks;integrated security=SSPI");
			SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM HumanResources.vEmployee", sqlConn);
			da.Fill(ds,"Employees");
			int x = ds.Tables.Count;
			return ds.Tables["Employees"];
		}
		catch (Exception ex)
		{
			return new DataTable();
			//return ex.Message;
		}

    }

	[WebMethod]
	public string GetString()
	{

		try
		{

			DataSet ds = new DataSet();
			SqlConnection sqlConn = new SqlConnection("server=(local);database=AdventureWorks;integrated security=SSPI");
			SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM HumanResources.vEmployee", sqlConn);
			da.Fill(ds);
			int x = ds.Tables.Count;
			return "hello";  //ds.Tables["Employees"];
		}
		catch (Exception ex)
		{
			//return new DataTable();
			return ex.Message;
		}

	}
}
