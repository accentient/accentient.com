﻿namespace Execute
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.txtSQL = new System.Windows.Forms.TextBox();
			this.grdDemo = new System.Windows.Forms.DataGridView();
			this.btnExecuteSynch = new System.Windows.Forms.Button();
			this.lblInfo = new System.Windows.Forms.Label();
			this.btnExecuteHourglass = new System.Windows.Forms.Button();
			this.btnExecuteAsync = new System.Windows.Forms.Button();
			this.btnClear = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.grdDemo)).BeginInit();
			this.SuspendLayout();
			// 
			// txtSQL
			// 
			this.txtSQL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtSQL.Location = new System.Drawing.Point(13, 11);
			this.txtSQL.Name = "txtSQL";
			this.txtSQL.Size = new System.Drawing.Size(707, 27);
			this.txtSQL.TabIndex = 0;
			this.txtSQL.Text = "WAITFOR DELAY \'00:00:05\'; SELECT * FROM Person.Contact WHERE ContactID < 25";
			// 
			// grdDemo
			// 
			this.grdDemo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.grdDemo.Location = new System.Drawing.Point(13, 94);
			this.grdDemo.Name = "grdDemo";
			this.grdDemo.Size = new System.Drawing.Size(707, 191);
			this.grdDemo.TabIndex = 1;
			// 
			// btnExecuteSynch
			// 
			this.btnExecuteSynch.Location = new System.Drawing.Point(13, 48);
			this.btnExecuteSynch.Name = "btnExecuteSynch";
			this.btnExecuteSynch.Size = new System.Drawing.Size(102, 40);
			this.btnExecuteSynch.TabIndex = 2;
			this.btnExecuteSynch.Text = "Execute";
			this.btnExecuteSynch.Click += new System.EventHandler(this.btnExecuteSynch_Click);
			// 
			// lblInfo
			// 
			this.lblInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.lblInfo.AutoSize = true;
			this.lblInfo.Location = new System.Drawing.Point(12, 291);
			this.lblInfo.Name = "lblInfo";
			this.lblInfo.Size = new System.Drawing.Size(59, 24);
			this.lblInfo.TabIndex = 3;
			this.lblInfo.Text = "Ready";
			// 
			// btnExecuteHourglass
			// 
			this.btnExecuteHourglass.Location = new System.Drawing.Point(138, 48);
			this.btnExecuteHourglass.Name = "btnExecuteHourglass";
			this.btnExecuteHourglass.Size = new System.Drawing.Size(105, 40);
			this.btnExecuteHourglass.TabIndex = 4;
			this.btnExecuteHourglass.Text = "Hourglass";
			this.btnExecuteHourglass.Click += new System.EventHandler(this.btnExecuteHourglass_Click);
			// 
			// btnExecuteAsync
			// 
			this.btnExecuteAsync.Location = new System.Drawing.Point(269, 48);
			this.btnExecuteAsync.Name = "btnExecuteAsync";
			this.btnExecuteAsync.Size = new System.Drawing.Size(111, 40);
			this.btnExecuteAsync.TabIndex = 5;
			this.btnExecuteAsync.Text = "Async";
			this.btnExecuteAsync.Click += new System.EventHandler(this.btnExecuteAsync_Click);
			// 
			// btnClear
			// 
			this.btnClear.Location = new System.Drawing.Point(409, 48);
			this.btnClear.Name = "btnClear";
			this.btnClear.Size = new System.Drawing.Size(96, 40);
			this.btnClear.TabIndex = 6;
			this.btnClear.Text = "Clear";
			this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(9, 22);
			this.ClientSize = new System.Drawing.Size(732, 324);
			this.Controls.Add(this.btnClear);
			this.Controls.Add(this.btnExecuteAsync);
			this.Controls.Add(this.btnExecuteHourglass);
			this.Controls.Add(this.lblInfo);
			this.Controls.Add(this.btnExecuteSynch);
			this.Controls.Add(this.grdDemo);
			this.Controls.Add(this.txtSQL);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Name = "Form1";
			this.Text = "Form1";
			((System.ComponentModel.ISupportInitialize)(this.grdDemo)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSQL;
        private System.Windows.Forms.DataGridView grdDemo;
        private System.Windows.Forms.Button btnExecuteSynch;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.Button btnExecuteHourglass;
        private System.Windows.Forms.Button btnExecuteAsync;
        private System.Windows.Forms.Button btnClear;
    }
}

