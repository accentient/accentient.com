using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AddBikeReview
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			SqlConnection conn = new SqlConnection("server=(local);database=AdventureWorks;Integrated Security=SSPI");
			SqlCommand cmd = conn.CreateCommand();

			cmd.CommandText = textBox1.Text;
			conn.Open();

			cmd.ExecuteNonQuery();
		}


	}
}