Module Module1

   Sub Main()

      Dim f As New Hundhausen.Foo
      f.Bar("Hello World")

      Console.ReadLine()

   End Sub

End Module
