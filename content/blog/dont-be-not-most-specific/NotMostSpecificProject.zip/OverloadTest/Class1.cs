using System;

namespace Hundhausen
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class Foo
	{

		public void Bar(string s) {}

		public void Bar(ref string s) {}

	}
}
