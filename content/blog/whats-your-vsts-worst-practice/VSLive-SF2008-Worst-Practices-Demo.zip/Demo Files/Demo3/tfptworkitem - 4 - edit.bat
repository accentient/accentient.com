c:
cd\program files\microsoft team foundation server 2008 power tools

tfpt query "vslive\public\all tasks" /server:vsts
pause

tfpt query /format:"id" "vslive\public\all tasks" /server:vsts
pause

tfpt query /format:"id" "vslive\public\all tasks" /server:vsts | tfpt workitem /update /server:vsts @ /fields:"Assigned To=Toni - Tester"
pause

tfpt query "vslive\public\all tasks" /server:vsts > results.txt
notepad results.txt
