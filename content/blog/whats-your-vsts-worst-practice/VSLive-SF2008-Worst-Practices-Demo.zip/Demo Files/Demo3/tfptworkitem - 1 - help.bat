c:
cd\program files\microsoft team foundation server 2008 power tools

tfpt /?
pause

tfpt workitem /?
pause
