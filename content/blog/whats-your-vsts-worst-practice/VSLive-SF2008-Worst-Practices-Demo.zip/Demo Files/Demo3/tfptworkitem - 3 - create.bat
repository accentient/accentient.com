c:
cd\program files\microsoft team foundation server 2008 power tools

tfpt workitem /new vslive\Bug /server:vsts /fields:"Title=Blue Screen;Assigned To=Dave - Developer"
pause

tfpt query "vslive\public\active bugs" /server:vsts
pause