c:
cd\program files\microsoft team foundation server 2008 power tools

tfpt query "vslive\public\all tasks" /server:vsts
pause

tfpt query "vslive\public\all tasks" /server:vsts > c:\vslive!\demo3\tasks.txt
notepad c:\vslive!\demo3\tasks.txt
