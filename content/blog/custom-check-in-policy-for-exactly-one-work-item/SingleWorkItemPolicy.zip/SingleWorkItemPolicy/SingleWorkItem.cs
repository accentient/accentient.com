﻿using System;
using System.Collections;
using Microsoft.TeamFoundation.VersionControl.Client;
using Microsoft.TeamFoundation.VersionControl.Common;

namespace Accentient
{
  [Serializable]

  public class SingleWorkItemPolicy : IPolicyDefinition, IPolicyEvaluation
  {
    public static readonly PolicyFailure[] NoFailures = new PolicyFailure[0];

    [NonSerialized]
    protected IPendingCheckin m_pendingCheckin;

    [NonSerialized]
    protected bool m_disposed = false;

    public virtual void Activate(PolicyFailure failure) { }

    public virtual event PolicyStateChangedHandler PolicyStateChanged;

    protected virtual void OnPolicyStateChanged(PolicyFailure[] failures)
    {
      PolicyStateChangedHandler handler = PolicyStateChanged;
      if (handler != null)
      {
        handler(this, new PolicyStateChangedEventArgs(failures, this));
      }
    }

    private void pendingCheckin_CheckedPendingChangesChanged(Object sender, EventArgs e)
    {
      if (!m_disposed)
      {
        OnPolicyStateChanged(Evaluate());
      }
    }

    public void Initialize(IPendingCheckin pendingCheckin)
    {
      if (m_pendingCheckin != null)
      {
        throw new InvalidOperationException("Policy already initialized.");
      }

      if (m_disposed)
      {
        throw new ObjectDisposedException(null);
      }
      m_pendingCheckin = pendingCheckin;
      pendingCheckin.PendingChanges.CheckedPendingChangesChanged += new EventHandler(pendingCheckin_CheckedPendingChangesChanged);
    }

    public bool Edit(IPolicyEditArgs policyEditArgs)
    {
      return true;
    }

    public void Dispose()
    {
      if (!m_disposed)
      {
        m_pendingCheckin.PendingChanges.CheckedPendingChangesChanged -= new EventHandler(pendingCheckin_CheckedPendingChangesChanged);

        // Mark us as disposed.

        m_disposed = true;

        // Stop firing events.

        PolicyStateChanged = null;
      }
    }

    public PolicyFailure[] Evaluate()
    {
      if (m_disposed)
      {
        throw new ObjectDisposedException(null);
      }
      ArrayList failures = new ArrayList();

      try
      {
        // How many work items are associated?
        IPendingCheckinWorkItems workItems = m_pendingCheckin.WorkItems;
        if (workItems.CheckedWorkItems.Length != 1)
        {
          string message = String.Format("You must associate with exactly one work item.");
          failures.Add(new PolicyFailure(message, this));
        }
      }
      catch (Exception ex)
      {
        string message = String.Format("Exception thrown in policy: {0}", ex.Message);
        failures.Add(new PolicyFailure(message, this));
      }

      // Return the (possibly empty) list of failures.

      return (PolicyFailure[])failures.ToArray(typeof(PolicyFailure));
    }

    public String Type
    {
      get { return "Single Work Item Policy"; }
    }

    public String TypeDescription
    {
      get { return "This policy requires exactly one work item be associated with every check-in."; }
    }

    public String Description
    {
      get { return "Ensures that exactly one work item is associated."; }
    }

    public virtual String InstallationInstructions
    {
      get { return "This policy is missing from your computer. Please contact your TFS Administrator for assistance. In the meantime, please only associate your check-in with one work item."; }
    }

    public virtual bool CanEdit
    {
      get { return false; }
    }

    public void DisplayHelp(PolicyFailure failure)
    {
      // Open appropriate help documentation here
    }
  }
}