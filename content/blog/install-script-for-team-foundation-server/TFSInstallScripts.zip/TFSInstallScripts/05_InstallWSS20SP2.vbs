'*******************************************************************************
'*
'* File:           05_InstallWSS20SP2.vbs
'* Purpose:        
'* Usage:          [CScript | WScript] 05_InstallWSS20SP2.vbs
'* Version:        1.0 
'* Technology:     VBSCRIPT WMI 
'* Requirements:   Windows 2000, Windows XP, Windows Server 2003 
'*                 Windows Script Host 5.6 - CSCRIPT.EXE OR WSCRIPT.EXE
'* 
'* Created by:     Etienne Tremblay, Sr Consultant, EDS, Team System MVP 
'* 
'*******************************************************************************

On Error Resume Next

'*******************************************************************************
'*
'* Main Logic
'*
'*******************************************************************************

strCmdLine = GetCurrentDirectory() & "\WSS_2.0_SP2\STSV2.EXE /C:""setupsts.exe /remoteSql=yes /provision=no /q""" 
strWorkDir2 = "C:\inetpub\adminscripts"
strCmdLine2 = "cscript " & strWorkDir2 & "\adsutil.vbs set w3svc/1/NTAuthenticationProviders  ""NTLM"""
Const TIMEOUT = 5
Const MINIMIZED_WINDOW = 2
Const FINAL_DELAY_INSEC = 240  'seconds
Const MAXNUM_RETRY = 3 
Const RETRY_DELAY_INSEC = 10  'seconds 
SetupFile = GetCurrentDirectory() & "\WSS_2.0_SP2\STSV2.EXE"

Set objWshShell = WScript.CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")

WScript.Echo "Installing WSS SP2 on the Server ..."

While not objFSO.FileExists(SetupFile)
    if objWshShell.Popup("Please Copy STSV2.EXE in " & GetCurrentDirectory() & "\WSS_2.0_SP2 ...", 0, "Windows Sharepoint Services", 65) = 2 then
        WScript.Quit 5
    end if
wend

Set objWshShell = WScript.CreateObject("WScript.Shell")
strCmdLine = "%comspec% /C " & strCmdLine
strCmdLine2 = "%comspec% /C " & strCmdLine2
intRCode = ObjWshShell.Run((strCmdLine), MINIMIZED_WINDOW, True)
intRCode = ObjWshShell.Run((strCmdLine), MINIMIZED_WINDOW, True)

WScript.Echo "Done installing WSS SP2 on the Server."

If intRCode = 0 Then
   WScript.Quit 0
Else
   WScript.Quit 1
End if

'*******************************************************************************
'*
'* GetCurrentDirectory
'*
'*******************************************************************************
Function GetCurrentDirectory()
    Set objFSOCD = CreateObject("Scripting.FileSystemObject")
    GetCurrentDirectory = objFSOCD.GetAbsolutePathName(".")
    set objFSOCD = nothing
End Function
