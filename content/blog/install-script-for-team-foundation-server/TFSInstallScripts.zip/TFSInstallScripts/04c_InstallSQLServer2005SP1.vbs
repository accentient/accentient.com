'*******************************************************************************
'*
'* File:           04c_InstallSQLServer2005HotFix.vbs
'* Purpose:        
'* Usage:          [CScript | WScript] 04c_InstallSQLServer2005HotFix.vbs
'* Version:        1.0 
'* Technology:     VBSCRIPT WMI 
'* Requirements:   Windows Server 2003 
'*                 Windows Script Host 5.6 - CSCRIPT.EXE OR WSCRIPT.EXE
'* 
'* Created by:     Etienne Tremblay, Sr Consultant, EDS, Team System MVP 
'* 
'*******************************************************************************

On Error Resume Next

'*******************************************************************************
'*
'* Main Logic
'*
'*******************************************************************************

strCmdLine = GetCurrentDirectory() & "\SQL_2K5_SP1\SQLServer2005SP1-KB913090-x86-ENU.exe /quiet /allinstances" 
Const TIMEOUT = 5
Const MINIMIZED_WINDOW = 2
Const FINAL_DELAY_INSEC = 240  'seconds
Const MAXNUM_RETRY = 3 
Const RETRY_DELAY_INSEC = 10  'seconds 
SetupFile = GetCurrentDirectory() & "\SQL_2K5_SP1\SQLServer2005SP1-KB913090-x86-ENU.exe"

WScript.Echo "Installing SQL Server 2005 SP1 ..."

Set objWshShell = WScript.CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")

SQLBrowerService "stop"

While not objFSO.FileExists(CDDriveLetter & SetupFile)
    if objWshShell.Popup("Please Copy SQLServer2005SP1-KB913090-x86-ENU.exe in " & GetCurrentDirectory() & "\SQL_2K5_SP1 ...", 0, "SQL Server 2005 SP1", 65) = 2 then
        WScript.Quit 5
    end if
wend

strCmdLine = "%comspec% /C " & CDDriveLetter & strCmdLine
intRCode = ObjWshShell.Run((strCmdLine), MINIMIZED_WINDOW, True)

SQLBrowerService "change"
SQLBrowerService "start"

WScript.Echo "Done Installing SQL Server 2005 SP1 ..."

If intRCode = 0 Then
   WScript.Quit 0
Else
   WScript.Quit 1
End if

'*******************************************************************************
'*
'* SQLBrowerService(action)
'*
'*******************************************************************************
Sub SQLBrowerService(action)
    errReturn = 0
    strComputer = "."
    Set objWMIService = GetObject("winmgmts:{impersonationLevel=impersonate}!\\" & strComputer & "\root\cimv2")

    Set colServiceList = objWMIService.ExecQuery("Select * from Win32_Service Where Name = 'SQLBrowser'")

    For Each objService in colServiceList
         if objService.Name = "SQLBrowser" then
            if action = "stop" then
                errReturn = objService.StopService
            elseif action = "start" then
                errReturn = objService.StartService
            elseif action = "change" then
                errReturn = objService.ChangeStartMode("Automatic")
            end if
         end if
    Next
End Sub

'*******************************************************************************
'*
'* GetCurrentDirectory
'*
'*******************************************************************************
Function GetCurrentDirectory()
    Set objFSOCD = CreateObject("Scripting.FileSystemObject")
    GetCurrentDirectory = objFSOCD.GetAbsolutePathName(".")
    set objFSOCD = nothing
End Function