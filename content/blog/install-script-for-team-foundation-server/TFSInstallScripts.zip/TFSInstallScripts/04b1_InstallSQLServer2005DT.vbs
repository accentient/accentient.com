'*******************************************************************************
'*
'* File:           04b1_InstallSQLServer2005DT.vbs
'* Purpose:        
'* Usage:          [CScript | WScript] 04b1_InstallSQLServer2005DT.vbs <PIDKEY> | <blank>
'* Version:        1.0 
'* Technology:     VBSCRIPT WMI 
'* Requirements:   Windows Server 2003 
'*                 Windows Script Host 5.6 - CSCRIPT.EXE OR WSCRIPT.EXE
'* 
'* Created by:     Etienne Tremblay, Sr Consultant, EDS, Team System MVP 
'* 
'*******************************************************************************

On Error Resume Next

'*******************************************************************************
'*
'* Main Logic
'*
'*******************************************************************************

strCmdLine = ":\Servers\setup.exe /qb /settings " & GetCurrentDirectory() & "\04b1_InstallSQLServer2005DT.txt PIDKEY=" 
Const TIMEOUT = 5
Const MINIMIZED_WINDOW = 2
Const FINAL_DELAY_INSEC = 240  'seconds
Const MAXNUM_RETRY = 3 
Const RETRY_DELAY_INSEC = 10  'seconds 
Const SetupFile = ":\servers\setup.exe"

WScript.Echo "Installing SQL Server 2005 on the Server for DT ..."

Set objWshShell = WScript.CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")

set objArgs = WScript.Arguments
ArgsCount = objArgs.Count
CDDriveLetter = objArgs.Item(0)

if ArgsCount > 2 then
   WScript.Echo "Usage: [CScript | WScript] 04b1_InstallSQLServer2005DT.vbs <CDDriveLetter> <PIDKEY> | <blank>"
   WScript.Quit 1
end if

While not objFSO.FileExists(CDDriveLetter & SetupFile)
    if objWshShell.Popup("Please Insert/Capture the SQL Server 2005 Install Disk...", 0, "SQL Server 2005", 65) = 2 then
        WScript.Quit 5
    end if
wend

PIDKEY = objArgs.Item(1)

if PIDKEY = "" then
    strCmdLine = "%comspec% /C " & CDDriveLetter & strCmdLine
else
    strCmdLine = "%comspec% /C " & CDDriveLetter & strCmdLine & PIDKEY
end if
intRCode = ObjWshShell.Run((strCmdLine), MINIMIZED_WINDOW, True)

WScript.Echo "Done installing SQL Server 2005 on the Server for DT."

If intRCode = 0 Then
   WScript.Quit 0
Else
   WScript.Quit 1
End if

'*******************************************************************************
'*
'* GetCurrentDirectory
'*
'*******************************************************************************
Function GetCurrentDirectory()
    Set objFSOCD = CreateObject("Scripting.FileSystemObject")
    GetCurrentDirectory = objFSOCD.GetAbsolutePathName(".")
    set objFSOCD = nothing
End Function