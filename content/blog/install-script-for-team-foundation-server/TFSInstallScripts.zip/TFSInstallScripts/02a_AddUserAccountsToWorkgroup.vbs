'*******************************************************************************
'*
'* File:           02a_AddUserAccountsToWorkgroup.vbs
'* Purpose:        
'* Usage:          Usage: [CScript | WScript] 02a_AddUserAccountsToWorkgroup.vbs <DomainName> <SetupUser> <SetupPassword> <ServiceUser> <ServicePassword> <ReportUser> <ReportPassword>
'* Version:        1.0 
'* Technology:     VBSCRIPT WMI 
'* Requirements:   Windows 2000, Windows XP, Windows Server 2003 
'*                 Windows Script Host 5.6 - CSCRIPT.EXE OR WSCRIPT.EXE
'* 
'* Created by:     Etienne Tremblay, Sr Consultant, EDS, Team System MVP 
'* 
'*******************************************************************************

On Error Resume Next

'*******************************************************************************
'*
'* Main Logic
'*
'*******************************************************************************

strCmdLine_I = "ntrights -u <User> +r SeInteractiveLogonRight"

Const TIMEOUT = 5
Const MINIMIZED_WINDOW = 2
Const FINAL_DELAY_INSEC = 240  'seconds
Const MAXNUM_RETRY = 3 
Const RETRY_DELAY_INSEC = 10  'seconds 
Const ADS_UF_DONT_EXPIRE_PASSWD = &h10000
Const ADS_UF_PASSWD_CANT_CHANGE = &H0040 

WScript.Echo "Creating users on the Workgroup ..."

Set objFSO = CreateObject("Scripting.FileSystemObject")
Set objWshShell = WScript.CreateObject("WScript.Shell")
Set WshNetwork = WScript.CreateObject("WScript.Network")

set objArgs = WScript.Arguments
ArgsCount = objArgs.Count

if ArgsCount = 0 then
   WScript.Echo "Usage: [CScript | WScript] 02a_AddUserAccountsToWorkgroup.vbs <DomainName> <SetupUser> <SetupPassword> <ServiceUser> <ServicePassword> <ReportUser> <ReportPassword>"
   WScript.Quit 1
end if

' Setup User
CreateUser objArgs.Item(0), objArgs.Item(1), objArgs.Item(2)
AddUserToGroup WshNetwork.ComputerName, objArgs.Item(1), "Administrators"

' Service User
CreateUser objArgs.Item(0), objArgs.Item(3), objArgs.Item(4)
strCmdLine1 = Replace(strCmdLine_I, "<User>", objArgs.Item(1), 1)
strCmdLine1 = "%comspec% /C " & strCmdLine1
intRCode = ObjWshShell.Run((strCmdLine1), MINIMIZED_WINDOW, True)

' Report User
CreateUser objArgs.Item(0), objArgs.Item(5), objArgs.Item(6)
strCmdLine1 = Replace(strCmdLine_I, "<User>", objArgs.Item(1), 1)
strCmdLine1 = "%comspec% /C " & strCmdLine1
intRCode = ObjWshShell.Run((strCmdLine1), MINIMIZED_WINDOW, True)

WScript.Echo "Done creating users on the Workgroup ..."

If intRCode = 0 Then
   WScript.Quit 0
Else
   WScript.Quit 1
End if

objUser.SetInfo

'*******************************************************************************
'*
'* CreateUser(strDomain, strUser, strPassword)
'*
'*******************************************************************************
Sub CreateUser(strDomain, strUser, strPassword)
    Dim Computer
    Dim User
	
	on error resume next
	
    Set Computer = GetObject("WinNT://" & strDomain)
	
	Set User = GetObject("WinNT://" & strDomain & "/" & strUser & ",user")
	if User is nothing then
		Set User = Computer.create("User", strUser)
		User.fullname = strUser
		User.Description = strUser
        Set UserFlags = User.Get("UserFlags")
        PasswordExpirationFlag = UserFlags OR ADS_UF_DONT_EXPIRE_PASSWD OR ADS_UF_PASSWD_CANT_CHANGE
        call User.Put("userFlags", objPasswordExpirationFlag) 
		call User.SetPassword(strPassword)
		call User.setinfo
		
		Set User = Nothing
		Set Computer = Nothing
	end if
End Sub

'*******************************************************************************
'*
'* AddUserToGroup(strDomain,strUser,strGroup)
'*
'*******************************************************************************
Sub AddUserToGroup(strDomain,strUser,strGroup)
	Dim User
	Dim Group

	Set User = GetObject("WinNT://" & strDomain & "/" & strUser & ",user")
	if not User is nothing then
		Set Group = GetObject("WinNT://" & strDomain & "/" & strGroup & ",group")
		if Not Group is nothing then
			call Group.Add(User.ADsPath)
			call Group.Setinfo
			Set Group = nothing
		end if
		Set User = nothing
	end if
	
End Sub
