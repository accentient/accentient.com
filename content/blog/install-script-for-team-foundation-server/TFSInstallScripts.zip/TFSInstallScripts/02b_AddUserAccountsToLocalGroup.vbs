'*******************************************************************************
'*
'* File:           02b_AddUserAccountsToLocalGroup.vbs
'* Purpose:        
'* Usage:          Usage: [CScript | WScript] 02b_AddUserAccountsToLocalGroup.vbs <SetupUser> <ServiceUser> <ReportUser>
'* Version:        1.0 
'* Technology:     VBSCRIPT WMI 
'* Requirements:   Windows 2000, Windows XP, Windows Server 2003 
'*                 Windows Script Host 5.6 - CSCRIPT.EXE OR WSCRIPT.EXE
'* 
'* Created by:     Etienne Tremblay, Sr Consultant, EDS, Team System MVP 
'* 
'*******************************************************************************

On Error Resume Next

'*******************************************************************************
'*
'* Main Logic
'*
'*******************************************************************************

strCmdLine_I = "ntrights -u <User> +r SeInteractiveLogonRight"

Const TIMEOUT = 5
Const MINIMIZED_WINDOW = 2
Const FINAL_DELAY_INSEC = 240  'seconds
Const MAXNUM_RETRY = 3 
Const RETRY_DELAY_INSEC = 10  'seconds 

WScript.Echo "Started adding users to Local Server Security Groups ..."

Set objFSO = CreateObject("Scripting.FileSystemObject")
Set objWshShell = WScript.CreateObject("WScript.Shell")
Set WshNetwork = WScript.CreateObject("WScript.Network")

set objArgs = WScript.Arguments
ArgsCount = objArgs.Count

if ArgsCount = 0 then
   WScript.Echo "Usage: [CScript | WScript] 02b_AddUserAccountsToLocalGroup.vbs <SetupUser> <ServiceUser> <ReportUser>"
   WScript.Quit 1
end if

' Setup User
AddUserToGroup WshNetwork.ComputerName, objArgs.Item(0), "Administrators"

' Service User
strCmdLine1 = Replace(strCmdLine_I, "<User>", objArgs.Item(1), 1)
strCmdLine1 = "%comspec% /C " & strCmdLine1
intRCode = ObjWshShell.Run((strCmdLine1), MINIMIZED_WINDOW, True)

' Report User
strCmdLine1 = Replace(strCmdLine_I, "<User>", objArgs.Item(2), 1)
strCmdLine1 = "%comspec% /C " & strCmdLine1
intRCode = ObjWshShell.Run((strCmdLine1), MINIMIZED_WINDOW, True)

WScript.Echo "Done adding users to Local Server Security Groups ..."

If intRCode = 0 Then
   WScript.Quit 0
Else
   WScript.Quit 1
End if

'*******************************************************************************
'*
'* AddUserToGroup(strDomain,strUser,strGroup)
'*
'*******************************************************************************
Sub AddUserToGroup(strDomain,strUser,strGroup)
	Dim User
	Dim Group

	Set User = GetObject("WinNT://" & strDomain & "/" & strUser & ",user")
	if not User is nothing then
		Set Group = GetObject("WinNT://" & strDomain & "/" & strGroup & ",group")
		if Not Group is nothing then
			call Group.Add(User.ADsPath)
			call Group.Setinfo
			Set Group = nothing
		end if
		Set User = nothing
	end if
	
End Sub
