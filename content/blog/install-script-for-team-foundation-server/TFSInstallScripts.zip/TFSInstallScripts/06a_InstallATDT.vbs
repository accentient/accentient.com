'*******************************************************************************
'*
'* File:           06a_InstallATDT.vbs
'* Purpose:        
'* Usage:          [CScript | WScript] 06a_InstallATDT.vbs <CDDriveLetter>
'* Version:        1.0 
'* Technology:     VBSCRIPT WMI 
'* Requirements:   Windows Server 2003 
'*                 Windows Script Host 5.6 - CSCRIPT.EXE OR WSCRIPT.EXE
'* 
'* Created by:     Etienne Tremblay, Sr Consultant, EDS, Team System MVP 
'* 
'*******************************************************************************

On Error Resume Next

'*******************************************************************************
'*
'* Main Logic
'*
'*******************************************************************************

strCmdLine = ":\atdt\setup.exe" 
Const ForWriting = 2
Const ForReading = 1
Const TIMEOUT = 5
Const MINIMIZED_WINDOW = 2
Const FINAL_DELAY_INSEC = 240  'seconds
Const MAXNUM_RETRY = 3 
Const RETRY_DELAY_INSEC = 10  'seconds 
Const SetupFile = ":\atdt\setup.exe"

WScript.Echo "Installing ATDT on the Server ..."

Set objWshShell = WScript.CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")

set objArgs = WScript.Arguments
ArgsCount = objArgs.Count
CDDriveLetter = objArgs.Item(0)

if ArgsCount > 1 then
   WScript.Echo "Usage: [CScript | WScript] 06a_InstallATDT.vbs <CDDriveLetter>"
   WScript.Quit 1
end if

While not objFSO.FileExists(CDDriveLetter & SetupFile)
    if objWshShell.Popup("Please Insert/Capture the Team Fondation Server Install Disk...", 0, "Team Foundation Server 2005", 65) = 2 then
        WScript.Quit 5
    end if
wend

strCmdLine = "%comspec% /C " & CDDriveLetter & strCmdLine
intRCode = ObjWshShell.Run((strCmdLine), MINIMIZED_WINDOW, True)

WScript.Echo "Done installing ATDT on the Server."

If intRCode = 0 Then
   WScript.Quit 0
Else
   WScript.Quit 1
End if