'*******************************************************************************
'*
'* File:           03_InstallIIS.vbs
'* Purpose:        
'* Usage:          [CScript | WScript] 03_InstallIIS.vbs
'* Version:        1.0 
'* Technology:     VBSCRIPT WMI 
'* Requirements:   Windows Server 2003 
'*                 Windows Script Host 5.6 - CSCRIPT.EXE OR WSCRIPT.EXE
'* 
'* Created by:     Etienne Tremblay, Sr Consultant, Team System MVP 
'* 
'*******************************************************************************

On Error Resume Next

'*******************************************************************************
'*
'* Main Logic
'*
'*******************************************************************************

strCmdLine1 = "Sysocmgr.exe /i:sysoc.inf /u:""" & GetCurrentDirectory() & "\03_InstallIIS.txt"""
strCmdLine2 = "%WinDir%\Microsoft.NET\Framework\v2.0.50727\aspnet_regiis.exe -i"
Const TIMEOUT = 5
Const MINIMIZED_WINDOW = 2
Const FINAL_DELAY_INSEC = 240  'seconds
Const MAXNUM_RETRY = 3 
Const RETRY_DELAY_INSEC = 10  'seconds 

WScript.Echo "Installing IIS on the Server ..."

Set objWshShell = WScript.CreateObject("WScript.Shell")

strCmdLine1 = "%comspec% /C " & strCmdLine1
intRCode = ObjWshShell.Run((strCmdLine1), MINIMIZED_WINDOW, True)

WScript.Echo "Done installing IIS on the server."

WScript.Echo "Configuring ASPNET 2.0 on the Server ..."

Set objWshShell = WScript.CreateObject("WScript.Shell")

strCmdLine2 = "%comspec% /C " & strCmdLine2
intRCode = ObjWshShell.Run((strCmdLine2), MINIMIZED_WINDOW, True)

WScript.Echo "Done Configuring ASPNET 2.0 on the server."

If intRCode = 0 Then
   WScript.Quit 0
Else
   WScript.Quit 1
End if

'*******************************************************************************
'*
'* GetCurrentDirectory
'*
'*******************************************************************************
Function GetCurrentDirectory()
    Set objFSOCD = CreateObject("Scripting.FileSystemObject")
    GetCurrentDirectory = objFSOCD.GetAbsolutePathName(".")
    set objFSOCD = nothing
End Function
