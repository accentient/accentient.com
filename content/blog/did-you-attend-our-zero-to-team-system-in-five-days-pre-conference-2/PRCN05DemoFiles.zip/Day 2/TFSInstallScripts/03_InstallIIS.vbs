'*******************************************************************************
'*
'* File:           03_InstallIIS.vbs
'* Purpose:        
'* Usage:          [CScript | WScript] 03_InstallIIS.vbs
'* Version:        1.0 
'* Technology:     VBSCRIPT WMI 
'* Requirements:   Windows Server 2003 
'*                 Windows Script Host 5.6 - CSCRIPT.EXE OR WSCRIPT.EXE
'* 
'* Created by:     Etienne Tremblay, Sr Consultant, Team System MVP 
'* 
'*******************************************************************************

On Error Resume Next

'*******************************************************************************
'*
'* Main Logic
'*
'*******************************************************************************

strCmdLine = "Sysocmgr.exe /i:sysoc.inf /u:" & GetCurrentDirectory() & "\03_InstallIIS.txt"
Const TIMEOUT = 5
Const MINIMIZED_WINDOW = 2
Const FINAL_DELAY_INSEC = 240  'seconds
Const MAXNUM_RETRY = 3 
Const RETRY_DELAY_INSEC = 10  'seconds 

WScript.Echo "Installing IIS on the Server ..."

Set objWshShell = WScript.CreateObject("WScript.Shell")

strCmdLine = "%comspec% /C " & strCmdLine
intRCode = ObjWshShell.Run((strCmdLine), MINIMIZED_WINDOW, True)

WScript.Echo "Done installing IIS on the server."

If intRCode = 0 Then
   WScript.Quit 0
Else
   WScript.Quit 1
End if

'*******************************************************************************
'*
'* GetCurrentDirectory
'*
'*******************************************************************************
Function GetCurrentDirectory()
    Set objFSOCD = CreateObject("Scripting.FileSystemObject")
    GetCurrentDirectory = objFSOCD.GetAbsolutePathName(".")
    set objFSOCD = nothing
End Function
