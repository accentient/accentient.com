'*******************************************************************************
'*
'* File:           06c_InstallTFSSP1.vbs
'* Purpose:        
'* Usage:          [CScript | WScript] 06c_InstallTFSSP1.vbs
'* Version:        1.0 
'* Technology:     VBSCRIPT WMI 
'* Requirements:   Windows Server 2003 
'*                 Windows Script Host 5.6 - CSCRIPT.EXE OR WSCRIPT.EXE
'* 
'* Created by:     Etienne Tremblay, Sr Consultant, Team System MVP 
'* 
'*******************************************************************************

On Error Resume Next

'*******************************************************************************
'*
'* Main Logic
'*
'*******************************************************************************

strCmdLine1 = GetCurrentDirectory() & "\TFS_SP1\VS80-KB919156-X86.exe /q" 
strCmdLine2 = GetCurrentDirectory() & "\TFS_SP1\VS80sp1-KB926738-X86-ENU.exe /q" 
Const TIMEOUT = 5
Const MINIMIZED_WINDOW = 2
Const FINAL_DELAY_INSEC = 240  'seconds
Const MAXNUM_RETRY = 3 
Const RETRY_DELAY_INSEC = 10  'seconds 
SetupFile1 = GetCurrentDirectory() & "\TFS_SP1\VS80-KB919156-X86.exe"
SetupFile2 = GetCurrentDirectory() & "\TFS_SP1\VS80sp1-KB926738-X86-ENU.exe"

WScript.Echo "Installing TFS Server 2005 SP1 ..."

Set objWshShell = WScript.CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")

set objArgs = WScript.Arguments
ArgsCount = objArgs.Count

if ArgsCount > 0 then
    AdditionalComponent = objArgs.Item(0)
else
    AdditionalComponent = ""
end if

While not (objFSO.FileExists(CDDriveLetter & SetupFile1) and objFSO.FileExists(CDDriveLetter & SetupFile2))
    if objWshShell.Popup("Please Copy VS80-KB919156-X86.exe and VS80sp1-KB926738-X86-ENU.exe in " & GetCurrentDirectory() & "\TFS_SP1 ...", 0, "TFS Server 2005 SP1", 65) = 2 then
        WScript.Quit 5
    end if
wend

if AdditionalComponent = "TP" or AdditionalComponent = "" then
    strCmdLine1 = "%comspec% /C " & strCmdLine1
    intRCode = ObjWshShell.Run((strCmdLine1), MINIMIZED_WINDOW, True)
end if
strCmdLine2 = "%comspec% /C " & strCmdLine2
intRCode = ObjWshShell.Run((strCmdLine2), MINIMIZED_WINDOW, True)

WScript.Echo "Done Installing TFS Server 2005 SP1 ..."

If intRCode = 0 Then
   WScript.Quit 0
Else
   WScript.Quit 1
End if

'*******************************************************************************
'*
'* GetCurrentDirectory
'*
'*******************************************************************************
Function GetCurrentDirectory()
    Set objFSOCD = CreateObject("Scripting.FileSystemObject")
    GetCurrentDirectory = objFSOCD.GetAbsolutePathName(".")
    set objFSOCD = nothing
End Function