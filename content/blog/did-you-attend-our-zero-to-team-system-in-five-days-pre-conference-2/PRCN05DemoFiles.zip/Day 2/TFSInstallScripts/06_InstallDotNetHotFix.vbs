'*******************************************************************************
'*
'* File:           06_InstallDotNetHotFix.vbs
'* Purpose:        
'* Usage:          [CScript | WScript] 06_InstallDotNetHotFix.vbs <CDDriveLetter>
'* Version:        1.0 
'* Technology:     VBSCRIPT WMI 
'* Requirements:   Windows Server 2003 
'*                 Windows Script Host 5.6 - CSCRIPT.EXE OR WSCRIPT.EXE
'* 
'* Created by:     Etienne Tremblay, Sr Consultant, Team System MVP 
'* 
'*******************************************************************************

On Error Resume Next

'*******************************************************************************
'*
'* Main Logic
'*
'*******************************************************************************

strCmdLine = ":\KB913393\NDP20-KB913393-X86.exe /q" 
Const TIMEOUT = 5
Const MINIMIZED_WINDOW = 2
Const FINAL_DELAY_INSEC = 240  'seconds
Const MAXNUM_RETRY = 3 
Const RETRY_DELAY_INSEC = 10  'seconds 
Const SetupFile = ":\KB913393\NDP20-KB913393-X86.exe"

WScript.Echo "Installing .NET Hotfix on AT ..."

Set objWshShell = WScript.CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")

set objArgs = WScript.Arguments
ArgsCount = objArgs.Count
CDDriveLetter = objArgs.Item(0)

if ArgsCount > 1 then
   WScript.Echo "Usage: [CScript | WScript] 06_InstallDotNetHotFix.vbs <CDDriveLetter>"
   WScript.Quit 1
end if

While not objFSO.FileExists(CDDriveLetter & SetupFile)
    if objWshShell.Popup("Please Insert/Capture the Team Fondation Server Install Disk...", 0, "Team Foundation Server 2005", 65) = 2 then
        WScript.Quit 5
    end if
wend

strCmdLine = "%comspec% /C " & CDDriveLetter & strCmdLine
intRCode = ObjWshShell.Run((strCmdLine), MINIMIZED_WINDOW, True)

WScript.Echo "Done Installing .NET Hotfix on AT ..."

If intRCode = 0 Then
   WScript.Quit 0
Else
   WScript.Quit 1
End if