- Please read the TFS Install Guide this is not a replacement to that guide
- These are a set of automated steps to help you speed up your TFS install
- Copy the files to a directory which a short path name like c:\temp\TFSInstallScripts for example
- Make sure you download a the necessary pre-requirements in the proper folder.  There is a txt file in each sub-folder with the link to the proper download files.  Do this prior to starting your install.
- To start the process double click on "Team Sytem Install.hta"
- Read the instructions on application screen as you go through the steps.

- If you find any errors or problems please email to me @ tegaaa@videotron.ca
- I hope you find those useful I know they have saved me countless hours.
- These script work best when installing on a brand new environment.

- Please note that these script are given "as is". Use at your own risk. Always make backups before trying to install on a server that already as data.  
