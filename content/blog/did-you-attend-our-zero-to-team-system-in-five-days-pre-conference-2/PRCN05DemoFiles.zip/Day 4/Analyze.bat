"C:\Program Files\Microsoft Visual Studio 8\Common7\IDE\VSSConverter.exe" Analyze D:\Labs\Lab01\AnalysisSettings.xml
pause