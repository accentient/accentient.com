"C:\Program Files\Microsoft Visual Studio 8\Common7\IDE\VSSConverter.exe" Migrate D:\Labs\Lab01\MigrationSettings.xml
pause