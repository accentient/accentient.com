"C:\Program Files\Microsoft Visual Studio 8\Common7\IDE\VSSConverter.exe" /?
pause