// Author: Richard Hundhausen, Solid Quality Learning, Dec 2006
// Contact: richard@solidqualitylearning.com

using System;
using System.IO;
using System.Xml;
using RDLDeploy.SQLRSWS;
using System.Windows.Forms;

namespace RDLDeploy
{
    public partial class frmMain : Form
    {
        private void DeployReports()
        {
            try
            {
                string status;
                string reportName = System.IO.Path.GetFileNameWithoutExtension(txtRDL.Text);

                // Clear old status messages

                foreach (DataGridViewRow row in grdServers.Rows)
                {
                    row.Cells[2].Value = "";
                }

                // Load report

                Byte[] rdl = null;
                FileStream stream = File.OpenRead(txtRDL.Text);
                rdl = new Byte[stream.Length];
                stream.Read(rdl, 0, (int)stream.Length);
                stream.Close();

                // Create WS proxy

                ReportingService2005 ws = new ReportingService2005();

                // Loop through RS servers in grid

                foreach (DataGridViewRow row in grdServers.Rows)
                {
                    status = "";
                    if (Convert.ToString(row.Cells[0].Value) == "True")
                    {
                        // Determine URL

                        string url = Convert.ToString(row.Cells[1].Value);
                        if (!url.ToUpper().Contains("REPORTSERVICE2005.ASMX"))
                        {
                            url += @"/reportservice2005.asmx";
                        }

                        // Set URL and Credentials

                        ws.Url = url;
                        ws.Credentials = System.Net.CredentialCache.DefaultCredentials;

                        // Set folder properties

                        Property folderProperty = new Property();
                        folderProperty.Name = "Description";
                        folderProperty.Value = txtFolderDescription.Text; // May want to prompt for this
                        Property[] folderProperties = new Property[1];
                        folderProperties[0] = folderProperty;

                        // Attempt to create folder

                        try
                        {
                            ws.CreateFolder(txtFolder.Text, txtParent.Text, folderProperties);
                            status += "Folder created";
                        }
                        catch (Exception ex)
                        {
                            if (ex.Message.Contains("already exists"))
                            {
                                status += "Folder exists";
                            }
                            else
                            {
                                status += "Create folder failed (" + ex.Message + ")";
                                if (!chkContinue.Checked)
                                {
                                    row.Cells[2].Value = status;
                                    return;
                                }
                            }
                        }

                        // Set report properties

                        Property reportProperty = new Property();
                        reportProperty.Name = "Description";
                        reportProperty.Value = txtRDLDescription.Text; // May want to prompt for this
                        Property[] reportProperties = new Property[1];
                        reportProperties[0] = reportProperty;

                        // Upload report

                        try
                        {
                            Warning[] warnings = null;
                            warnings = ws.CreateReport(reportName, txtParent.Text + txtFolder.Text, true, rdl, reportProperties);
                            status += ", report uploaded";
                        }
                        catch (Exception ex)
                        {
                            status += ", upload failed (" + ex.Message + ")";
                            if (!chkContinue.Checked)
                            {
                                row.Cells[2].Value = status;
                                return;
                            }
                        }

                        // Show status

                        row.Cells[2].Value = status;
                        this.Refresh();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Deployment Failed!");
            }
        }

        private void LoadServers()
        {
            try
            {
                XmlDocument xml = new XmlDocument();
                xml.Load("RDLDeploy.xml");
                XmlNodeList servers = xml.GetElementsByTagName("server");
                foreach (XmlNode server in servers)
                {
                    DataGridViewRow row = new DataGridViewRow();
                    DataGridViewCheckBoxCell deployCell = new DataGridViewCheckBoxCell();
                    DataGridViewTextBoxCell serverCell = new DataGridViewTextBoxCell();
                    DataGridViewTextBoxCell statusCell = new DataGridViewTextBoxCell();
                    deployCell.Value = true;
                    serverCell.Value = server.InnerText;
                    row.Cells.Add(deployCell);
                    row.Cells.Add(serverCell);
                    row.Cells.Add(statusCell);
                    grdServers.Rows.Add(row);
                }
                statusStrip1.Items[0].Text = "Loaded Report Server list from RDLDeploy.xml";
            }
            catch (Exception ex)
            {
                statusStrip1.Items[0].Text = "Failed to load Report Server list from RDLDeploy.xml (" + ex.Message + ")";
            }
        }

        private void SaveServers()
        {
            try
            {
                string servers = "";
                foreach (DataGridViewRow row in grdServers.Rows)
                {
                    if (Convert.ToString(row.Cells[1].Value).Trim().Length > 0)
                    {
                        servers += "<server>" + row.Cells[1].Value + "</server>";
                    }
                }
                System.Xml.XmlDocument xml = new System.Xml.XmlDocument();
                xml.LoadXml("<servers>" + servers + "</servers>");
                xml.Save("RDLDeploy.xml");
                statusStrip1.Items[0].Text = "Saved Report Server list to RDLDeploy.xml";
            }
            catch (Exception ex)
            {
                statusStrip1.Items[0].Text = "Failed to saved Report Server list to RDLDeploy.xml (" + ex.Message + ")";
            }
        }

        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            // Set some defaults; remove these later

            txtRDL.Text = @"C:\rptCustomers.rdl";
            txtRDLDescription.Text = "New Report";
            txtFolder.Text = @"Test Folder";
            txtFolderDescription.Text = "New Folder";
            txtParent.Text = @"/";

            LoadServers();
        }

        private void btnRDL_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = txtRDL.Text;
            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "RDL files (*.rdl)|*.rdl|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtRDL.Text = openFileDialog1.FileName;
            }
        }

        private void btnDeploy_Click(object sender, EventArgs e)
        {
            DeployReports();
            if (chkSave.Checked)
            {
                SaveServers();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}