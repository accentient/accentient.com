using System;
using System.IO;
using System.Xml;
using System.Collections;

namespace ScrubDasBlog
{
  class Program
  {
    static ArrayList blackList = new ArrayList();

    static void ProcessFile(string file)
    {
      int trackbackCount = 0, commentCount = 0, badCommentCount = 0;
      ArrayList toBeDeleted = new ArrayList();

      // Load XML file

      Console.Write(System.IO.Path.GetFileName(file));
      XmlDocument xml = new XmlDocument();
      xml.Load(file);

      // Remove Trackback elements

      XmlNodeList tracking = xml.GetElementsByTagName("Tracking");
      trackbackCount = tracking.Count;
      while (tracking.Count > 0)
      {
        tracking[0].ParentNode.RemoveChild(tracking[0]);
        tracking = xml.GetElementsByTagName("Tracking");
      }

      // Remove spam comments

      if (blackList.Count > 0)
      {
        XmlNodeList comments = xml.GetElementsByTagName("Comment");
        commentCount = comments.Count;
        foreach (XmlNode node in comments)
        {

          XmlDocument searchXml = new XmlDocument();
          searchXml.LoadXml(node.OuterXml);
          XmlNamespaceManager nsmgr = new XmlNamespaceManager(searchXml.NameTable);
          nsmgr.AddNamespace("db", "urn:newtelligence-com:dasblog:runtime:data");
          XmlNode authorHomepageNode = searchXml.SelectSingleNode("//db:AuthorHomepage", nsmgr);
          if (authorHomepageNode != null)
          {
            if (blackList.Contains(authorHomepageNode.InnerText.ToLower()))
            {
              toBeDeleted.Add(node);
              badCommentCount++;
            }
          }
        }

        // Remove spam comments

        if (toBeDeleted.Count > 0)
        {
          foreach (XmlNode node in toBeDeleted)
          {
            node.ParentNode.RemoveChild(node);
          }
        }
      }
      xml.Save(file);
      Console.WriteLine("... Removed {0} trackbacks, Left {1}/{2} comments", trackbackCount, commentCount - badCommentCount, commentCount);
    }

    static void ProcessFiles(string path)
    {
      try
      {
        string[] files = System.IO.Directory.GetFiles(path, "*dayfeedback.xml");
        if (files.Length < 1)
        {
          ShowHelp();
          Console.WriteLine("");
          Console.WriteLine("Error: No *dayfeedback.xml files found at {0}", path);
          return;
        }
        foreach (string f in files)
        {
          ProcessFile(f);
        }
      }
      catch (Exception ex)
      {
        ShowHelp();
        Console.WriteLine("Error: {0}", ex.Message);
        return;
      }
    }

    static void LoadBlackList(string path)
    {
      string[] blackListArray;
      try
      {
        StreamReader SR = new StreamReader(path);
        blackListArray = SR.ReadToEnd().Split(Environment.NewLine.ToCharArray());
        SR.Close();
        blackList = ArrayList.Adapter(blackListArray);
      }
      catch (Exception ex)
      {
        ShowHelp();
        Console.WriteLine("Error: {0}", ex.Message);
        return;
      }
    }

    static void ShowHelp()
    {
      Console.WriteLine("");
      Console.WriteLine("ScrubDasBlog - Removes <Tracking> elements from *dayfeedback.xml files and SPAM comments");
      Console.WriteLine("ScrubDasBlog.exe PathToXmlFiles [BlackListFile]");
      Console.WriteLine("");
    }

    static void Main(string[] args)
    {
      if (args.Length == 2)
      {
        LoadBlackList(args[1]);
      }
      else
        if (args.Length != 1)
        {
          ShowHelp();
          return;
        }
      ProcessFiles(args[0]);
    }
  }
}
